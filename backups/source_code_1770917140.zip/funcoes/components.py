import discord, requests, zipfile, os, shutil, gc
from PIL import Image, ImageDraw, ImageSequence, ImageChops
from github import Github, UnknownObjectException
from settings import check
from settings import emojis
from settings import imagenspainel
from settings.ids import ChannelIDs, UserIDs, RoleIDs, GithubConfig
from dispie import SelectPrompt
from deep_translator import GoogleTranslator
from io import BytesIO
import asyncio
import re
import math
import time
from dotenv import load_dotenv
load_dotenv()

API_SECRET = os.getenv("SIGHTENGINE_SECRET")
API_USER = os.getenv("SIGHTENGINE_USER")
emoji_dl = emojis.download
share = emojis.share
favorite = emojis.favorite
troca = emojis.troca
boosters = {}
boostera = {}
clicksa = {}
clicksfa = {}
clickss = {}
clicksfs = {}
clicksms = {}
clicksma = {}

processing_semaphore = asyncio.Semaphore(1)

def download_image_to_disk(url, path):
    response = requests.get(url, stream=True)
    if response.status_code == 200:
        with open(path, 'wb') as f:
            shutil.copyfileobj(response.raw, f)
    else:
        raise Exception(f"Failed to download image: {response.status_code}")

async def analyze_image(url):
    """
    Simula uma verificação de NSFW.
    Retorna: "SAFE", "NSFW" ou "UNSURE".
    """
    if not API_USER or not API_SECRET:
        print("⚠️ [IA] API_USER ou API_SECRET não configurados.")
        return "UNSURE"

    try:
        loop = asyncio.get_running_loop()
        
        def check_sightengine():
            gtoken = os.getenv("GTOKEN")
            headers = {"Authorization": f"token {gtoken}"} if gtoken else {}
            
            # Baixa a imagem (suporta repositórios privados se GTOKEN estiver configurado)
            img_response = requests.get(url, headers=headers)
            if img_response.status_code != 200:
                img_response = requests.get(url) # Tenta sem auth
            
            if img_response.status_code != 200:
                print(f"❌ [IA] Erro ao baixar imagem: {img_response.status_code} | URL: {url}")
                return None
                
            params = {'models': 'nudity', 'api_user': API_USER, 'api_secret': API_SECRET}
            files = {'media': ('image.png', img_response.content)}
            return requests.post('https://api.sightengine.com/1.0/check.json', data=params, files=files).json()

        output = await loop.run_in_executor(None, check_sightengine)

        if output:
            if output['status'] == 'success':
                nudity = output['nudity']
                print(f"✅ [IA] Análise concluída: Safe={nudity['safe']:.2f}, Raw={nudity['raw']:.2f}")
                
                if nudity['safe'] < 0.15 or nudity['raw'] > 0.8:
                    return "NSFW"
                return "SAFE"
            else:
                error_msg = output.get('error', {}).get('message', 'Erro desconhecido')
                print(f"⚠️ [IA] Erro na API Sightengine: {error_msg}")
        else:
            print("⚠️ [IA] Falha ao conectar com a API.")

    except Exception as e:
        print(f"❌ [IA] Exceção: {e}")
    return "UNSURE"

async def upload_to_github(file_content: bytes, file_name: str, repo_path: str, interaction: discord.Interaction):
    """
    Faz upload de um arquivo para o repositório do GitHub e retorna a URL raw.
    """
    gtoken = os.getenv("GTOKEN")
    repo_name = os.getenv("FIST_REPO")
    branch = os.getenv("FIST_REPO_BRANCH", "main")

    if not gtoken or not repo_name:
        print("Configuração do GitHub (GTOKEN, FIST_REPO) não encontrada.")
        await interaction.followup.send("O bot não está configurado para usar o GitHub. Contate um administrador.", ephemeral=True)
        return None

    try:
        github = Github(gtoken)
        repo = github.get_repo(repo_name)
        
        full_path = f"{repo_path}/{file_name}"
        
        repo.create_file(
            path=full_path,
            message=f"feat: Adiciona {file_name} por {interaction.user.name}",
            content=file_content,
            branch=branch
        )
        
        raw_url = f"https://raw.githubusercontent.com/{repo_name}/{branch}/{full_path}"
        return raw_url

    except Exception as e:
        print(f"Erro no upload para o GitHub: {e}")
        await interaction.followup.send(f"Houve um erro ao fazer o upload para o GitHub: {e}", ephemeral=True)
        return None

async def atualizarmsg(interaction: discord.Interaction, embed):
    try:
        await interaction.edit_original_response(embed=embed)
    except:
        await asyncio.sleep(10)
        await interaction.edit_original_response(embed=embed)

class SFW(discord.ui.Button):
    def __init__(self):
        super().__init__(label="SFW", style=discord.ButtonStyle.green, custom_id="sfw", row=2)

    async def callback(self, interaction: discord.Interaction):
        adm = interaction.user.name
        adm = adm.split("#")[0]
        channel = interaction.guild.get_channel(ChannelIDs.FIST)
        user = ""
        embeds = []
        ButtonDL = discord.ui.View()

        for embedm in interaction.message.embeds:
            embed = discord.Embed.from_dict(embedm.to_dict())
            embeds.append(embed)
            if "Fist compartilhada por: " in embedm.description:
                user = str(embed.description)

        for botao in interaction.message.components:
            for botao2 in botao.children:
                if botao2.label not in ["SFW", "NSFW"] and botao2.custom_id != "FavoriteShare":
                    ButtonDL.add_item(discord.ui.Button(label=botao2.label, emoji=botao2.emoji, url=botao2.url, row=1))

        ButtonDL.add_item(Favorite_Share())
        user_check = interaction.guild.get_member(int(re.search(r'\d+', user).group()))
        await interaction.response.edit_message(content=f"Verificado por: {interaction.user.mention}. Não foi detectado Conteúdo NSFW nela.",view=None)
        await interaction.followup.send(f"Certo {interaction.user.mention}, compartilharei essa fist.",ephemeral=True)
        msg_check = await channel.send(embeds=embeds, view=ButtonDL)
        try:
            await user_check.send(content=f"Nosso admin {adm} não detectou NSFW na sua fist, então compartilhei ela para você.\n・{msg_check.jump_url}")
        except:
            return

class NSFW(discord.ui.Button):
    def __init__(self):
        super().__init__(label="NSFW", style=discord.ButtonStyle.red, custom_id="nsfw", row=2)

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.edit_message(content=f"Verificado por: {interaction.user.mention}. Foi detectado Conteúdo NSFW nela.", view=None)
        await interaction.followup.send(f"Certo {interaction.user.mention}, não compartilharei essa fist.",ephemeral=True)
        user = ""

        for embed in interaction.message.embeds:
            if "Fist compartilhada por: " in embed.description:
                user = str(embed.description)

        user_check = interaction.guild.get_member(int(re.search(r'\d+', user).group()))
        try:
            await user_check.send(content=f"Nossos admins detectaram conteúdo NSFW na sua fist.")
        except:
            return
        
class ConfirmNSFW(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        
        self.add_item(SFW())
        self.add_item(NSFW())

async def animatedr(interaction: discord.Interaction, imagem: discord.Attachment):
    user_id = interaction.user.id
    embedl = boostera[user_id]["embed"]
    embedl.title = "Criando a fist animada com moldura redonda!ㅤㅤ ㅤ ㅤ"
    embedl.description = "-** Coletando os dados da sua imagem**\nCriando... |ㅤ ㅤ ㅤ ㅤ ㅤ ㅤ |  **0%**"
    embedl.colour = 0x383d42
    await atualizarmsg(interaction, embedl)
    user = interaction.user
    user = str(user.id)[-4:]
    
    temp_input = f"temp_input_{user_id}_{int(time.time())}.gif"
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, lambda: download_image_to_disk(imagem.url, temp_input))
    gif = Image.open(temp_input)

    moldura_url = imagenspainel.frame_without_shadow
    response = requests.get(moldura_url)
    moldura = Image.open(BytesIO(response.content)).convert('RGBA')

    if boostera[user_id]["verificação"] == "1":
        txd_url = imagenspainel.txd_deddosouru_round
    else:
        txd_url = imagenspainel.txd_default_round

    responsetxd = requests.get(txd_url)
    txdfile = BytesIO(responsetxd.content)

    png_url = imagenspainel.fist_png
    responsepng = requests.get(png_url)
    png_img = BytesIO(responsepng.content)

    #tuto_url = "https://cdn.discordapp.com/attachments/1105606086628757654/1108504555794223245/Tutorial_OnlyGoldmods.html"
    #responsetuto = requests.get(tuto_url)
    #tuto = BytesIO(responsetuto.content)

    ini_url = imagenspainel.settings_ini
    response = requests.get(ini_url)
    ini_template = response.text

    luac_url = imagenspainel.aniframe_fix_luac
    response = requests.get(luac_url)
    luacfile = BytesIO(response.content)

    centro_espaco_verde = (28, 23)
    raio_espaco_verde = 228

    embedl.title = "Criando a fist animada com moldura redonda!ㅤㅤ ㅤ ㅤ"
    embedl.description = "-** Separando os frames**\nCriando... |=ㅤㅤㅤ ㅤ ㅤ ㅤ |  **8%**"
    embedl.colour = 0x383d42
    await atualizarmsg(interaction, embedl)
    
    temp_dir = f"temp_r_{user_id}_{int(time.time())}"
    os.makedirs(temp_dir, exist_ok=True)
    frame_paths = []

    for i, frame in enumerate(ImageSequence.Iterator(gif)):
        if i % 5 == 0: await asyncio.sleep(0)
        if i % 2 == 0:
            img = frame.convert('RGBA')
            img = crop_to_square(img)
            diametro = raio_espaco_verde * 2
            proporcao = max(diametro / img.width, diametro / img.height)
            nova_larg = int(img.width * proporcao)
            nova_altura = int(img.height * proporcao)
            img_redimensionada = img.resize((nova_larg, nova_altura), resample=Image.LANCZOS)
            mascara = Image.new('L', (diametro, diametro), 0)
            draw = ImageDraw.Draw(mascara)
            draw.ellipse((0, 0, diametro, diametro), fill=255)
            if img_redimensionada.size != mascara.size:
                mascara = mascara.resize(img_redimensionada.size, resample=Image.LANCZOS)
            img_circular = Image.new('RGBA', (diametro, diametro), (0, 0, 0, 0))
            img_circular.paste(img_redimensionada, ((diametro - nova_larg) // 2, (diametro - nova_altura) // 2),mask=mascara)
            nova_imagem = Image.new('RGBA', moldura.size, (0, 0, 0, 0))
            posicao_colagem = (centro_espaco_verde[0] - raio_espaco_verde + nova_larg // 2,
                            centro_espaco_verde[1] - raio_espaco_verde + nova_altura // 2)
            nova_imagem.paste(img_circular, posicao_colagem)

            fpath = os.path.join(temp_dir, f"{len(frame_paths)}.png")
            nova_imagem.save(fpath)
            frame_paths.append(fpath)

    ini_content = ini_template.replace("frames=", f"frames={len(frame_paths)}")

    embedl.title = "Criando a fist animada com moldura redonda!ㅤㅤ ㅤ ㅤ"
    embedl.description = "-** Criando arquivo zip com os arquivos e frames**\nCriando... |==ㅤ ㅤ ㅤ ㅤ  ㅤ |  **24%**"
    embedl.colour = 0x383d42
    await atualizarmsg(interaction, embedl)
    with zipfile.ZipFile(f"fist animatedr ({user}).zip", "w", compression=zipfile.ZIP_BZIP2) as zip:
        zip.writestr("moonloader/config/deddosouru_animated_fist_settings.ini", ini_content)
        for i, fpath in enumerate(frame_paths):
            nome_arquivo = f"{i}.png"
            caminho_arquivo = f"moonloader/resource/txd/{nome_arquivo}"
            zip.write(fpath, caminho_arquivo)
            
        #zip.writestr("Tutorial OnlyGoldᵐᵒᵈˢ.html", tuto.getvalue())
        zip.writestr("models/fist.png", png_img.getvalue())
        zip.writestr("moonloader/resource/txd/deddosouru.txd", txdfile.getvalue())
        zip.writestr("moonloader/aniframe_fix.luac", luacfile.getvalue())

    embedl.title = "Criando a fist animada com moldura redonda!ㅤㅤ ㅤ ㅤ"
    embedl.description = "-** Criando o preview com moldura redonda**\nCriando... |===ㅤㅤ ㅤ ㅤ ㅤ |   **32%**"
    embedl.colour = 0x383d42
    await atualizarmsg(interaction, embedl)
    preview = gerar_preview_from_disk(frame_paths, moldura, gif.info.get('duration', 100))
    
    gif.close()
    os.remove(temp_input)
    
    shutil.rmtree(temp_dir)
    gc.collect()

    embedl.title = "Criando a fist animada com moldura redonda!ㅤㅤ ㅤ ㅤ"
    embedl.description = "-** Fazendo ajustes finais**\nCriando... |=====ㅤㅤ ㅤ ㅤ  |   **40%**"
    embedl.colour = 0x383d42
    await atualizarmsg(interaction, embedl)

    preview_bytes = preview
    zip_path = f"fist animatedr ({user}).zip"
    with open(zip_path, "rb") as f:
        zip_bytes = f.read()

    os.remove(zip_path)

    timestamp = int(time.time())
    
    gif_filename = f"{timestamp}_{interaction.user.id}_animated_round.gif"
    zip_filename = f"{timestamp}_{interaction.user.id}_animated_round.zip"

    gif_url = await upload_to_github(preview_bytes, gif_filename, "fists/previews", interaction)
    zip_url = await upload_to_github(zip_bytes, zip_filename, "fists/zips", interaction)

    if not gif_url or not zip_url:
        return None, None, None

    return zip_url, gif_url, preview_bytes

def gerar_preview_from_disk(frame_paths, moldura, duration):
    frames = []
    # Pula frames para manter o total abaixo de ~30 para economizar RAM
    step = max(1, len(frame_paths) // 30)
    for i in range(0, len(frame_paths), step):
        path = frame_paths[i]
        with Image.open(path) as img:
            img = img.convert("RGBA")
            frame = Image.alpha_composite(img, moldura)
            frame.thumbnail((150, 150), Image.Resampling.LANCZOS)
            frames.append(frame)
            
    if not frames: return None
    
    output = BytesIO()
    # optimize=False economiza muita RAM durante o salvamento
    frames[0].save(output, format="GIF", save_all=True, append_images=frames[1:], optimize=False, duration=duration * step, loop=0)
    
    del frames
    gc.collect()
    return output.getvalue()

def crop_to_square(img):
    width, height = img.size
    if width == height:
        return img
    elif width > height:
        left = (width - height) // 2
        right = left + height
        return img.crop((left, 0, right, height))
    else:
        top = (height - width) // 2
        check.Bottom = top + width
        return img.crop((0, top, width, check.Bottom))

async def animatedq(interaction: discord.Interaction, imagem: discord.Attachment):
    user_id = interaction.user.id
    embedl = boostera[user_id]["embed"]
    embedl.title = "Criando a fist animada com moldura quadrada!ㅤㅤㅤㅤ"
    embedl.description = "-** Coletando os dados da sua imagem**\nCriando... |=======ㅤㅤㅤㅤ|   **48%**"
    embedl.colour = 0x383d42
    await atualizarmsg(interaction, embedl)
    user = interaction.user
    user = str(user.id)[-4:]
    
    temp_input = f"temp_input_{user_id}_{int(time.time())}.gif"
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, lambda: download_image_to_disk(imagem.url, temp_input))
    gif = Image.open(temp_input)

    moldura_url = imagenspainel.frame_square
    response = requests.get(moldura_url)
    moldura = Image.open(BytesIO(response.content)).convert('RGBA')

    if boostera[user_id]["verificação"] == "1":
        txd_url = imagenspainel.txd_deddosouru_square
    else:
        txd_url = imagenspainel.txd_default_square

    responsetxd = requests.get(txd_url)
    txdfile = BytesIO(responsetxd.content)
    

    png_url = imagenspainel.fist_png
    responsepng = requests.get(png_url)
    png_img = BytesIO(responsepng.content)

    #tuto_url = "https://cdn.discordapp.com/attachments/1105606086628757654/1108504555794223245/Tutorial_OnlyGoldmods.html"
    #responsetuto = requests.get(tuto_url)
    #tuto = BytesIO(responsetuto.content)

    luac_url = imagenspainel.aniframe_fix_luac
    response = requests.get(luac_url)
    luacfile = BytesIO(response.content)

    centro_espaco_verde = (67, 67)
    raio_espaco_verde = 0
    
    embedl.title = "Criando a fist animada com moldura quadrada!ㅤㅤㅤㅤ"
    embedl.description = "-** Separando os frames**\nCriando... |========ㅤㅤ ㅤ |   **56%**"
    embedl.colour = 0x383d42
    await atualizarmsg(interaction, embedl)
    
    temp_dir = f"temp_q_{user_id}_{int(time.time())}"
    os.makedirs(temp_dir, exist_ok=True)
    frame_paths = []

    for i, frame in enumerate(ImageSequence.Iterator(gif)):
        if i % 5 == 0: await asyncio.sleep(0)
        if i % 2 == 0:
            img = frame.convert('RGBA')
            img_cropped = crop_to_square(img)
            img_redimensionada = img_cropped.resize((379, 379), resample=Image.LANCZOS)
            nova_imagem = Image.new('RGBA', moldura.size, (0, 0, 0, 0))
            posicao_colagem = (centro_espaco_verde[0] - raio_espaco_verde,
                            centro_espaco_verde[1] - raio_espaco_verde)
            nova_imagem.paste(img_redimensionada, posicao_colagem)
            
            fpath = os.path.join(temp_dir, f"{len(frame_paths)}.png")
            nova_imagem.save(fpath)
            frame_paths.append(fpath)

    zip_name = f"fist animatedq ({user}).zip"
    ini_url = imagenspainel.settings_ini
    response = requests.get(ini_url)
    ini_content = response.text
    ini_content = ini_content.replace("frames=", f"frames={len(frame_paths)}")

    embedl.title = "Criando a fist animada com moldura quadrada!ㅤㅤㅤㅤ"
    embedl.description = "-** Criando arquivo zip com os arquivos e frames**\nCriando... |=========ㅤㅤㅤ|   **64%**"
    embedl.colour = 0x383d42
    await atualizarmsg(interaction, embedl)
    with zipfile.ZipFile(zip_name, "w", compression=zipfile.ZIP_BZIP2) as zip:
        for i, fpath in enumerate(frame_paths):
            nome_arquivo = f"{i}.png"
            zip.write(fpath, f"moonloader/resource/txd/{nome_arquivo}") 
        #zip.writestr("Tutorial OnlyGoldᵐᵒᵈˢ.html", tuto.getvalue())
        zip.writestr("models/fist.png", png_img.getvalue())
        zip.writestr("moonloader/config/deddosouru_animated_fist_settings.ini", ini_content)
        zip.writestr("moonloader/resource/txd/deddosouru.txd", txdfile.getvalue())
        zip.writestr("moonloader/aniframe_fix.luac", luacfile.getvalue())

    embedl.title = "Criando a fist animada com moldura quadrada!ㅤㅤㅤㅤ"
    embedl.description = "-** Criando o preview com moldura quadrada**\nCriando... |==========ㅤㅤ  |   **72%**"
    embedl.colour = 0x383d42
    await atualizarmsg(interaction, embedl)
    preview = gerar_preview_from_disk(frame_paths, moldura, gif.info.get('duration', 100))
    
    gif.close()
    os.remove(temp_input)
    
    shutil.rmtree(temp_dir)
    gc.collect()

    embedl.title = "Criando a fist animada com moldura quadrada!ㅤㅤㅤㅤ"
    embedl.description = "-** Fazendo ajustes finais**\nCriando... |===========ㅤㅤ|   **80%**"
    embedl.colour = 0x383d42
    await atualizarmsg(interaction, embedl)

    preview_bytes = preview
    with open(zip_name, "rb") as f:
        zip_bytes = f.read()

    os.remove(zip_name)

    timestamp = int(time.time())
    
    gif_filename = f"{timestamp}_{interaction.user.id}_animated_square.gif"
    zip_filename = f"{timestamp}_{interaction.user.id}_animated_square.zip"

    gif_url = await upload_to_github(preview_bytes, gif_filename, "fists/previews", interaction)
    zip_url = await upload_to_github(zip_bytes, zip_filename, "fists/zips", interaction)

    if not gif_url or not zip_url:
        return None, None, None

    return zip_url, gif_url, preview_bytes

def crop_to_square(image):
    width, height = image.size
    if width == height:
        return image
    elif width > height:
        left = (width - height) // 2
        right = left + height
        return image.crop((left, 0, right, height))
    else:
        top = (height - width) // 2
        check.Bottom = top + width
        return image.crop((0, top, width, check.Bottom))

def process_preview_gif(redonda_bytes, quadrada_bytes):
    """
    Processa e combina os GIFs de preview de forma otimizada para economizar RAM.
    """
    combined_frames = []
    target_height = 150 # Reduzir altura para economizar memória (Preview não precisa ser 512px)
    duration = 100

    with Image.open(BytesIO(redonda_bytes)) as redonda_img, Image.open(BytesIO(quadrada_bytes)) as quadrada_img:
        duration = redonda_img.info.get('duration', 100)
        
        for frame_r, frame_q in zip(ImageSequence.Iterator(redonda_img), ImageSequence.Iterator(quadrada_img)):
            fr = frame_r.convert('RGBA')
            fq = frame_q.convert('RGBA')
            
            # Redimensiona se for maior que o alvo para evitar OOM (Out of Memory)
            if fr.height > target_height:
                ratio = target_height / fr.height
                fr = fr.resize((int(fr.width * ratio), target_height), Image.Resampling.LANCZOS)
                
            if fq.height > target_height:
                ratio = target_height / fq.height
                fq = fq.resize((int(fq.width * ratio), target_height), Image.Resampling.LANCZOS)
                
            w = fr.width + fq.width
            h = max(fr.height, fq.height)
            
            new_image = Image.new('RGBA', (w, h), (0, 0, 0, 0))
            new_image.paste(fq, (0, 0))
            new_image.paste(fr, (fq.width, 0))
            combined_frames.append(new_image)
        
    output_data = BytesIO()
    if combined_frames:
        combined_frames[0].save(output_data, format='GIF', save_all=True, append_images=combined_frames[1:], duration=duration, loop=0, optimize=False)
    output_data.seek(0)
    
    del combined_frames
    gc.collect()
    return output_data

async def staticr(interaction: discord.Interaction, imagem: discord.Attachment):
    user_id = interaction.user.id

    if boosters[user_id]["verificação"] == "1":
        moldura_url = imagenspainel.frame_with_shadow
    else:
        moldura_url = imagenspainel.frame_default_static

    response = requests.get(moldura_url)
    moldura = Image.open(BytesIO(response.content))
    
    # Download para disco e resize imediato para economizar RAM
    temp_input = f"temp_static_r_{user_id}_{int(time.time())}.png"
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, lambda: download_image_to_disk(imagem.url, temp_input))
    
    img = Image.open(temp_input)
    if img.width > 1024 or img.height > 1024:
        img.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
        
    tamanho_corte = min(img.width, img.height)
    img = img.crop(((img.width - tamanho_corte) // 2, (img.height - tamanho_corte) // 2, (img.width + tamanho_corte) // 2, (img.height + tamanho_corte) // 2))

    raio_espaco_verde = 230

    diametro = raio_espaco_verde * 2
    proporcao = max(diametro / img.width, diametro / img.height)
    nova_larg = int(img.width * proporcao)
    nova_altura = int(img.height * proporcao)
    img_redimensionada = img.resize((nova_larg, nova_altura), resample=Image.LANCZOS)
    mascara = Image.new('L', (diametro, diametro), 0)
    draw = ImageDraw.Draw(mascara)
    draw.ellipse((0, 0, diametro, diametro), fill=255)

    if img_redimensionada.size != mascara.size:
        mascara = mascara.resize(img_redimensionada.size, resample=Image.LANCZOS)

    img_circular = Image.new('RGBA', (diametro, diametro), (0, 0, 0, 0))
    img_circular.paste(img_redimensionada, ((diametro - nova_larg) // 2, (diametro - nova_altura) // 2 - 5), mask=mascara)

    if img_circular.size != moldura.size:
        nova_imagem = Image.new('RGBA', moldura.size, (0, 0, 0, 0))
        nova_imagem.paste(img_circular, ((moldura.width - img_circular.width) // 2, (moldura.height - img_circular.height) // 2))
        img_circular = nova_imagem

    imagem_com_moldura = Image.alpha_composite(img_circular, moldura)
    imagem_com_moldura.thumbnail((256, 256))
    imagem_com_moldura = imagem_com_moldura.resize((512, 512))

    img.close()
    if os.path.exists(temp_input):
        os.remove(temp_input)

    return imagem_com_moldura

async def staticq(interaction: discord.Interaction, imagem: discord.Attachment):
    user_id = interaction.user.id
    
    if boosters[user_id]["verificação"] == "1":
        moldura_url = imagenspainel.frame_square
    else:
        moldura_url = imagenspainel.frame_default_square

    moldura_resposta = requests.get(moldura_url)
    moldura = Image.open(BytesIO(moldura_resposta.content))
    
    # Download para disco e resize imediato
    temp_input = f"temp_static_q_{user_id}_{int(time.time())}.png"
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(None, lambda: download_image_to_disk(imagem.url, temp_input))
    
    imagem = Image.open(temp_input)
    if imagem.width > 1024 or imagem.height > 1024:
        imagem.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
        
    if imagem.width > imagem.height:
        proporcao = moldura.width / imagem.width
        nova_altura = int(imagem.height * proporcao)
        imagem = imagem.resize((moldura.width, nova_altura))
    else:
        proporcao = moldura.height / imagem.height
        nova_largura = int(imagem.width * proporcao)
        imagem = imagem.resize((nova_largura, moldura.height))
    tamanho_minimo = min(imagem.width, imagem.height)
    imagem = imagem.crop(((imagem.width - tamanho_minimo) // 2,
                          (imagem.height - tamanho_minimo) // 2,
                          (imagem.width + tamanho_minimo) // 2,
                          (imagem.height + tamanho_minimo) // 2))
    imagem = imagem.resize((384, 384))
    imagem_com_moldura = Image.new('RGBA', (512, 512), (0, 0, 0, 0))
    espaco_vazio_x = (512 - imagem.width) // 2
    espaco_vazio_y = (512 - imagem.height) // 2
    posicao_inicio = (espaco_vazio_x, espaco_vazio_y)
    imagem_com_moldura.paste(imagem, posicao_inicio)
    imagem_com_moldura.paste(moldura, (0, 0), moldura)
    imagem_com_moldura.thumbnail((512, 512))

    imagem.close()
    if os.path.exists(temp_input):
        os.remove(temp_input)

    return imagem_com_moldura

class ButtonDLShare(discord.ui.View):
    def __init__(self, img1, img2):
        super().__init__(timeout=None)
        self.add_item(discord.ui.Button(label="Quadrada", emoji=emoji_dl, url=img1))
        self.add_item(discord.ui.Button(label="Redonda", emoji=emoji_dl, url=img2))

class FavoriteShare(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(Favorite_Share())

class Favorite_Share(discord.ui.Button):
    def __init__(self):
        super().__init__(emoji=favorite, style=discord.ButtonStyle.red, custom_id="FavoriteShare", row=1)

    async def callback(self, interaction: discord.Interaction):
        mensagem = await interaction.channel.fetch_message(interaction.message.id)
        
        img = mensagem.embeds[0].image.url
        img1 = mensagem.components[0].children[0].url
        img2 = mensagem.components[0].children[1].url
        mention = mensagem.embeds[0].description

        gif = False

        if img.endswith('.gif'):
            gif = True
        
        embed = discord.Embed(description=mention, colour=0x383d42)
        embed.set_author(name="Privacyᵐᵒᵈˢ", icon_url=interaction.guild.icon.url)
        embed.set_image(url=img)
        embed.set_footer(text="© Privacyᵐᵒᵈˢ, 2026. All Rights Reserved.")

        user = interaction.user
        user = str(user.id)[-4:]
        channel = interaction.channel
        favorite = None

        async def download_image(url):
            response = requests.get(url)
            return Image.open(BytesIO(response.content))

        async def compare_images(image1, image2):
            if image1.size != image2.size:
                return False

            diff = ImageChops.difference(image1, image2)
            diff = diff.convert('L')
            return not any(diff.getdata())

        for thread in channel.threads:
            if f"({user})" in thread.name:
                await interaction.response.send_message("Aguarde um instante...", ephemeral=True)

                imagemcriada = await download_image(img)
                found_same_image = False

                async for message in thread.history(limit=None):
                    if len(message.embeds) > 0:
                        image_url = message.embeds[0].image.url
                        if gif == False:
                            if image_url.endswith(('.png', '.jpeg', '.jpg')):
                                imgembed = await download_image(image_url)

                                if await compare_images(imgembed, imagemcriada):
                                    await thread.add_user(interaction.user)
                                    await interaction.edit_original_response(content=f"Você já favoritou essa fist anteriormente! | {message.jump_url}")
                                    found_same_image = True
                                    break

                        if gif == True:
                            if image_url.endswith('.gif'):
                                imgembed = await download_image(image_url)
                                if await compare_images(imgembed, imagemcriada):
                                    await thread.add_user(interaction.user)
                                    await interaction.edit_original_response(content=f"Você já favoritou essa fist anteriormente! | {message.jump_url}")
                                    found_same_image = True
                                    break

                if found_same_image is False:
                    messagee = await thread.send(embed=embed, view=ButtonDLShare(img1, img2))
                    await thread.add_user(interaction.user)
                    await interaction.edit_original_response(content=f"Sua fist foi enviada para a sua aba de favoritos! | {messagee.jump_url}")
                return

        if favorite == None:
            favorite = await channel.create_thread(name=f"❤・{interaction.user.display_name} ({user})", type=discord.ChannelType.private_thread, auto_archive_duration=10080)
            await favorite.add_user(interaction.user)

        messagef= await favorite.send(embed=embed, view=ButtonDLShare(img1, img2))
        await interaction.response.send_message(f"Sua fist foi enviada para a sua aba de favoritos! | {messagef.jump_url}", ephemeral=True)

async def static(interaction: discord.Interaction, imagem: discord.Attachment, ver):
    user_id = interaction.user.id

    if ver == "nova":
        clicksms[user_id] = 0
        await interaction.response.send_message("**Aguarde uns instantes...**", ephemeral=True)
        has_role = any(role.id == RoleIDs.BOOSTER for role in interaction.user.roles)
        boosters[user_id] =  {"booster": has_role if user_id != 446713006848475138 else True, "imagem": imagem, "previews": {"preview1": "", "dl1_1": "", "dl2_1": "", "preview2": "", "dl1_2":"", "dl2_2": ""}, "verificação": "1"}
        clickss[user_id] = 0
        clicksfs[user_id] = 0

    else:
        await interaction.response.edit_message(content="**Aguarde uns instantes...**", embed=None, view=None)
        
    async def generate_and_upload_images():
        async with processing_semaphore:
            imagem_com_moldura1 = await staticq(interaction, imagem)
            imagem_com_moldura2 = await staticr(interaction, imagem)

            imagem_preview = Image.new('RGBA', (imagem_com_moldura1.width + imagem_com_moldura2.width, max(imagem_com_moldura1.height, imagem_com_moldura2.height)))
            imagem_preview.paste(imagem_com_moldura1, (0, 0))
            imagem_preview.paste(imagem_com_moldura2, (imagem_com_moldura1.width, 0))

            with BytesIO() as bio:
                imagem_com_moldura1.save(bio, format='PNG')
                img_bytes1 = bio.getvalue()
            with BytesIO() as bio:
                imagem_com_moldura2.save(bio, format='PNG')
                img_bytes2 = bio.getvalue()
            with BytesIO() as bio:
                imagem_preview.save(bio, format='PNG')
                img_bytes3 = bio.getvalue()

            timestamp = int(time.time())
            user_id = interaction.user.id
            
            url1 = await upload_to_github(img_bytes1, f"{timestamp}_{user_id}_static_square.png", "fists/raw_static", interaction)
            url2 = await upload_to_github(img_bytes2, f"{timestamp}_{user_id}_static_round.png", "fists/raw_static", interaction)
            url3 = await upload_to_github(img_bytes3, f"{timestamp}_{user_id}_static_combined.png", "fists/previews", interaction)

            return url1, url2, url3

    user = interaction.user.mention
    channelnsfw = check.Bot.get_channel(ChannelIDs.NSFW)

    class SimButton(discord.ui.Button):
        def __init__(self, has_role):
            super().__init__(emoji=share, style=discord.ButtonStyle.blurple)
            self.has_role = has_role
            if clickss[user_id] > 0:
                self.disabled = True

        async def callback(self, interaction: discord.Interaction):
            has_role = self.has_role
            user_id = interaction.user.id
            if user_id not in clickss:
                clickss[user_id] = 0

            if clickss[user_id] > 0:
                await interaction.response.send_message("Você já compartilhou esta fist.", ephemeral=True)
                return

            clickss[user_id] += 1
            await interaction.response.defer()

            status = await analyze_image(url_preview)
            
            if status == "NSFW":
                await interaction.followup.send("Conteúdo NSFW detectado automaticamente. Sua fist foi recusada.", ephemeral=True)
                return
            
            if status == "SAFE":
                await interaction.edit_original_response(embed=embed, view=ButtonShareDL(has_role))
                
                channel_fist = interaction.guild.get_channel(ChannelIDs.FIST)
                if channel_fist:
                    await channel_fist.send(embed=embeds, view=ButtonShareDL(False))
                
                await interaction.followup.send(f"Sua fist foi verificada automaticamente e aprovada! Os botões de download foram liberados.", ephemeral=True)
                return

            # UNSURE (Análise Manual)
            await interaction.edit_original_response(embed=embed, view=ButtonShare(has_role))
            await interaction.followup.send("**・Sua fist passará por uma analise da adminsitração**, se não detectarmos nada, sua fist será compartilhada.\nAgradecemos pela compreeção :)", ephemeral=True)
            await channelnsfw.send(f"Verifiquem a fist do usuário: {interaction.user.mention}.", embed=embeds, view=ConfirmNSFWStatic())
    
    class ButtonFavorite(discord.ui.Button):
        def __init__(self, has_role):
            super().__init__(emoji=favorite, style=discord.ButtonStyle.red, disabled=False)
            self.has_role = has_role
            self.value=None
            if clicksfs[user_id] > 0:
                self.disabled = True

        async def callback(self, interaction: discord.Interaction):
            has_role = self.has_role
            user_id = interaction.user.id
            if user_id not in clicksfs:
                clicksfs[user_id] = 0

            clicksfs[user_id] +=1
            await interaction.response.edit_message(embed=embed, view=ButtonShare(has_role))

            self.value = True
            user = interaction.user
            user = str(user.id)[-4:]
            channel = check.Bot.get_channel(ChannelIDs.FIST)
            favorite = None

            class ButtonShareInFavorite(discord.ui.View):
                def __init__(self):
                    super().__init__(timeout=None)
                    self.add_item(discord.ui.Button(label="Quadrada", emoji=emoji_dl, url=boosters[user_id]["previews"]["dl1_1"] if boosters[user_id]["verificação"] == "1" else boosters[user_id]["previews"]["dl1_2"]))
                    self.add_item(discord.ui.Button(label="Redonda", emoji=emoji_dl, url=boosters[user_id]["previews"]["dl2_1"] if boosters[user_id]["verificação"] == "1" else boosters[user_id]["previews"]["dl2_2"]))

            async def download_image(url):
                response = requests.get(url)
                return Image.open(BytesIO(response.content))

            async def compare_images(image1, image2):
                if image1.size != image2.size:
                    return False

                diff = ImageChops.difference(image1, image2)
                diff = diff.convert('L')
                return not any(diff.getdata())

            for thread in channel.threads:
                if f"({user})" in thread.name:
                    msg = await interaction.followup.send("Aguarde um instante...", ephemeral=True)

                    imagemcriada = await download_image(url_preview)
                    found_same_image = False

                    async for message in thread.history(limit=None):
                        if len(message.embeds) > 0:
                            image_url = message.embeds[0].image.url
                            if image_url.endswith(('.png', '.jpeg', '.jpg')):
                                imgembed = await download_image(image_url)

                                if await compare_images(imgembed, imagemcriada):
                                    msg = await thread.send(f"{interaction.user.mention}")
                                    await msg.delete()
                                    await interaction.followup.edit_message(msg.id, content=f"Você já favoritou essa fist anteriormente! | {message.jump_url}")
                                    found_same_image = True
                                    break
                            elif image_url.endswith('.gif'):

                                continue

                    if not found_same_image:
                        messagee = await thread.send(embed=embed, view=ButtonShareInFavorite())
                        msgmention = await thread.send(f"{interaction.user.mention}")
                        await msgmention.delete()
                        await interaction.followup.edit_message(msg.id, content=f"Sua fist foi enviada para a sua aba de favoritos! | {messagee.jump_url}")

                    return

            if favorite == None:
                favorite = await channel.create_thread(name=f"❤・{interaction.user.display_name} ({user})", type=discord.ChannelType.private_thread)
                msg = await favorite.send(f"{interaction.user.mention}")
                await msg.delete()

            messagef= await favorite.send(embed=embed, view=ButtonShareInFavorite())
            await interaction.followup.send(f"Sua fist foi enviada para a sua aba de favoritos! | {messagef.jump_url}", ephemeral=True)

    class AltMoldura(discord.ui.Button):
        def __init__(self, has_role):
            super().__init__(label="Trocar Moldura (Sem Marca)" if boosters[user_id]["verificação"] == "1" else "Trocar Moldura (Com Marca)", emoji=troca, style=discord.ButtonStyle.gray, row=2)
            self.has_role = has_role

        async def callback(self, interaction: discord.Interaction):
            has_role = self.has_role
            user_id = interaction.user.id
            imagem = boosters[user_id]["imagem"]

            if clicksms[user_id] == 0:
                clicksms[user_id] += 1
                boosters[user_id]["verificação"] = "2"
                ver = "moldura"
                await static(interaction, imagem, ver)
                return

            if clicksms[user_id] == 1:
                if boosters[user_id]["verificação"] == "2":
                    boosters[user_id]["verificação"] = "1"
                else:
                    boosters[user_id]["verificação"] = "2"
                    
                embed = discord.Embed(description=f"{interaction.user.mention} | Aqui está um preview de suas fists no formato quadrado e redondo:", colour=0x383d42)
                embed.set_author(name="Privacyᵐᵒᵈˢ", icon_url=interaction.guild.icon.url)
                embed.set_image(url=boosters[user_id]["previews"]["preview1"] if boosters[user_id]["verificação"] == "1" else boosters[user_id]["previews"]["preview2"])
                embed.set_footer(text="© Privacyᵐᵒᵈˢ, 2026. All Rights Reserved.")

                await interaction.response.edit_message(embed=embed, view=ButtonShare(has_role))
                return

    class ButtonShareDL(discord.ui.View):
        def __init__(self, has_role):
            super().__init__(timeout=None)
            self.add_item(discord.ui.Button(label="Quadrada", emoji=emoji_dl, url=boosters[user_id]["previews"]["dl1_1"] if boosters[user_id]["verificação"] == "1" else boosters[user_id]["previews"]["dl1_2"]))
            self.add_item(discord.ui.Button(label="Redonda", emoji=emoji_dl, url=boosters[user_id]["previews"]["dl2_1"] if boosters[user_id]["verificação"] == "1" else boosters[user_id]["previews"]["dl2_2"]))
            self.add_item(ButtonFavorite(has_role))
            if has_role:
                self.add_item(AltMoldura(has_role))

    class ButtonShare(discord.ui.View):
        def __init__(self, has_role):
            super().__init__(timeout=None)
            self.add_item(ButtonFavorite(has_role))
            self.add_item(SimButton(has_role))
            if has_role:
                self.add_item(AltMoldura(has_role))

    class ConfirmNSFWStatic(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=None)
            
            self.add_item(discord.ui.Button(label="Quadrada", emoji=emoji_dl, url=boosters[user_id]["previews"]["dl1_1"] if boosters[user_id]["verificação"] == "1" else boosters[user_id]["previews"]["dl1_2"], row=1))
            self.add_item(discord.ui.Button(label="Redonda", emoji=emoji_dl, url=boosters[user_id]["previews"]["dl2_1"] if boosters[user_id]["verificação"] == "1" else boosters[user_id]["previews"]["dl2_2"], row=1))
            self.add_item(SFW())
            self.add_item(NSFW())

    url_quadrada, url_redonda, url_preview = await generate_and_upload_images()
    if not url_quadrada or not url_redonda or not url_preview:
        await interaction.edit_original_response(content="Ocorreu um erro durante o upload. Tente novamente.", embed=None, view=None)
        return

    embeds = discord.Embed(description=f"Fist compartilhada por: {user}", colour=0x383d42)
    embeds.set_author(name="Privacyᵐᵒᵈˢ", icon_url=interaction.guild.icon.url)
    embeds.set_image(url=url_preview)
    embed = discord.Embed(description=f"{interaction.user.mention} | Aqui está um preview de suas fists no formato quadrado e redondo:", colour=0x383d42)
    embed.set_author(name="Privacyᵐᵒᵈˢ", icon_url=interaction.guild.icon.url)
    embed.set_image(url=url_preview)
    embed.set_footer(text="© Privacyᵐᵒᵈˢ, 2026. All Rights Reserved.")
    
    has_role = boosters[user_id]["booster"]

    if boosters[user_id]["verificação"] == "1":
        boosters[user_id]["previews"]["preview1"] = url_preview
        boosters[user_id]["previews"]["dl1_1"] = url_quadrada
        boosters[user_id]["previews"]["dl2_1"] = url_redonda

    if boosters[user_id]["verificação"] == "2":
        boosters[user_id]["previews"]["preview2"] = url_preview
        boosters[user_id]["previews"]["dl1_2"] = url_quadrada
        boosters[user_id]["previews"]["dl2_2"] = url_redonda

    message = await interaction.edit_original_response(content="", embed=embed, view=ButtonShare(has_role))

async def animated(interaction: discord.Interaction, imagem: discord.Attachment, ver):
    embedl = discord.Embed(title="Aguarde um instante...", description="", colour=0x383d42)
    embedl.set_thumbnail(url=interaction.guild.icon.url)
    user_id = interaction.user.id

    if ver == "nova":
        clicksma[user_id] = 0
        await interaction.response.send_message(embed=embedl, ephemeral=True)
        has_role = any(role.id == RoleIDs.BOOSTER for role in interaction.user.roles)
        boostera[user_id] =  {"booster": has_role if user_id != 446713006848475138 else True, "imagem": imagem, "previews": {"preview1": "", "dl1_1": "", "dl2_1": "", "preview2": "", "dl1_2":"", "dl2_2": ""}, "embed": "", "verificação": "1"}
        clicksa[user_id] = 0
        clicksfa[user_id] = 0

    else:
        await interaction.response.edit_message(content="", embed=embedl, view=None)

    boostera[user_id]["embed"] = embedl
    userg = interaction.user
    userg = str(userg.id)[-4:]
    
    zip_name = f"fist animatedq ({userg}).zip"
    gif_name = f"fist animatedq ({userg}).gif"
    async def generate_image_files():
        async with processing_semaphore:
            redonda = await animatedr(interaction, imagem)
            if redonda == (None, None, None):
                return None, None, None
            embedl.title = "Criando a fist animada!ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤ"
            embedl.description = "-** Aguardando para fazer a fist quadrada**\nCriando... |======ㅤㅤㅤㅤ  |   **43%**"
            embedl.colour = 0x383d42
            await atualizarmsg(interaction, embedl)

            quadrada = await animatedq(interaction, imagem)
            if quadrada == (None, None, None):
                return None, None, None
            embedl.title = "Criando a fist animada!ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤ"
            embedl.description = "-** Aguardando para fazer o preview**\nCriando... |============ ㅤ |   **88%**"
            embedl.colour = 0x383d42
            await atualizarmsg(interaction, embedl)

            redonda_gif = redonda[1]
            redonda_zip = redonda[0]
            quadrada_gif = quadrada[1]
            quadrada_zip = quadrada[0]
            
            redonda_bytes = redonda[2]
            quadrada_bytes = quadrada[2]

            embedl.title = "Criando o preview!ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤ ㅤ ㅤㅤ ㅤ "
            embedl.description = "-** Criando o preview final**\nCriando... |=============ㅤ|   **96%**"
            embedl.colour = 0x383d42
            await atualizarmsg(interaction, embedl)
            
            # Processamento pesado em executor com redimensionamento
            loop = asyncio.get_running_loop()
            output_data = await loop.run_in_executor(None, process_preview_gif, redonda_bytes, quadrada_bytes)

            embedl.title = "Pronto!ㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤㅤ ㅤ ㅤ ㅤ "
            embedl.description = "-** Mandando os arquivos**\nPronto |===============|  **100%**"
            embedl.colour = 0x383d42
            await atualizarmsg(interaction, embedl)

            timestamp = int(time.time())
            user_id = interaction.user.id
            preview_filename = f"{timestamp}_{user_id}_animated_combined.gif"
            
            preview_url = await upload_to_github(output_data.getvalue(), preview_filename, "fists/previews", interaction)

            if not preview_url:
                return None, None, None

            return preview_url, redonda_zip, quadrada_zip
    
    user = interaction.user.mention
    channelnsfw = check.Bot.get_channel(ChannelIDs.NSFW)

    class SimButton(discord.ui.Button):
        def __init__(self, has_role):
            super().__init__(emoji=share, style=discord.ButtonStyle.blurple)
            self.has_role = has_role
            if clicksa[user_id] > 0:
                self.disabled = True

        async def callback(self, interaction: discord.Interaction):
            has_role = self.has_role
            user_id = interaction.user.id
            if user_id not in clicksa:
                clicksa[user_id] = 0

            if clicksa[user_id] > 0:
                await interaction.response.send_message("Você já compartilhou esta fist.", ephemeral=True)
                return

            clicksa[user_id] += 1
            await interaction.response.defer()

            status = await analyze_image(link_preview)
            
            if status == "NSFW":
                await interaction.followup.send("Conteúdo NSFW detectado automaticamente. Sua fist foi recusada.", ephemeral=True)
                return
            
            if status == "SAFE":
                await interaction.edit_original_response(embed=embed, view=ButtonShareDL(has_role))
                
                channel_fist = interaction.guild.get_channel(ChannelIDs.FIST)
                if channel_fist:
                    await channel_fist.send(embed=embeds, view=ButtonShareDL(False))
                
                await interaction.followup.send(f"Sua fist foi verificada automaticamente e aprovada! Os botões de download foram liberados.", ephemeral=True)
                return

            # UNSURE (Análise Manual)
            await interaction.edit_original_response(embed=embed, view=ButtonShare(has_role))
            await interaction.followup.send("**・Sua fist passará por uma analise da adminsitração**, se não detectarmos nada, sua fist será compartilhada.\nAgradecemos pela compreeção. 😉", ephemeral=True)
            await channelnsfw.send(f"Verifiquem a fist do usuário: {interaction.user.mention}.", embed=embeds, view=ConfirmNSFWAnimated())
    
    class ButtonFavorite(discord.ui.Button):
        def __init__(self, has_role):
            super().__init__(emoji=favorite, style=discord.ButtonStyle.red, disabled=False)
            self.has_role = has_role
            self.value=None
            if clicksfa[user_id] > 0:
                self.disabled = True

        async def callback(self, interaction: discord.Interaction):
            has_role = self.has_role
            user_id = interaction.user.id
            if user_id not in clicksfa:
                clicksfa[user_id] = 0

            clicksfa[user_id] +=1
            await interaction.response.edit_message(embed=embed, view=ButtonShare(has_role))

            self.value = True
            user = interaction.user
            user = str(user.id)[-4:]
            channel = check.Bot.get_channel(ChannelIDs.FIST)
            favorite = None

            class ButtonShareInFavorite(discord.ui.View):
                def __init__(self):
                    super().__init__(timeout=None)
                    self.add_item(discord.ui.Button(label="Quadrada", emoji=emoji_dl, url=boostera[user_id]["previews"]["dl1_1"] if boostera[user_id]["verificação"] == "1" else boostera[user_id]["previews"]["dl1_2"]))
                    self.add_item(discord.ui.Button(label="Redonda", emoji=emoji_dl, url=boostera[user_id]["previews"]["dl2_1"] if boostera[user_id]["verificação"] == "1" else boostera[user_id]["previews"]["dl2_2"]))

            async def download_image(url):
                response = requests.get(url)
                return Image.open(BytesIO(response.content))

            async def compare_images(image1, image2):
                if image1.size != image2.size:
                    return False

                diff = ImageChops.difference(image1, image2)
                diff = diff.convert('L')
                return not any(diff.getdata())

            for thread in channel.threads:
                if f"({user})" in thread.name:
                    msg = await interaction.followup.send("Aguarde um instante...", ephemeral=True)

                    imagemcriada = await download_image(link_preview)
                    found_same_image = False

                    async for message in thread.history(limit=None):
                        if len(message.embeds) > 0:
                            image_url = message.embeds[0].image.url
                            if image_url.endswith('.gif'):
                                imgembed = await download_image(image_url)

                                if await compare_images(imgembed, imagemcriada):
                                    msg = await thread.send(f"{interaction.user.mention}")
                                    await msg.delete()
                                    await interaction.followup.edit_message(msg.id, content=f"Você já favoritou essa fist anteriormente! | {message.jump_url}")
                                    found_same_image = True
                                    break
                            else:
                                continue

                    if not found_same_image:
                        messagee = await thread.send(embed=embed, view=ButtonShareInFavorite())
                        msgmention = await thread.send(f"{interaction.user.mention}")
                        await msgmention.delete()
                        await interaction.followup.edit_message(msg.id, content=f"Sua fist foi enviada para a sua aba de favoritos! | {messagee.jump_url}")

                    return

            if favorite == None:
                favorite = await channel.create_thread(name=f"❤・{interaction.user.display_name} ({user})", type=discord.ChannelType.private_thread)
                msg = await favorite.send(f"{interaction.user.mention}")
                await msg.delete()

            messagef= await favorite.send(embed=embed, view=ButtonShareInFavorite())
            await interaction.followup.send(f"Sua fist foi enviada para a sua aba de favoritos! | {messagef.jump_url}", ephemeral=True)
            
    class AltMoldura(discord.ui.Button):
        def __init__(self, has_role):
            super().__init__(label="Trocar Moldura (Sem Marca)" if boostera[user_id]["verificação"] == "1" else "Trocar Moldura (Com Marca)", emoji=troca, style=discord.ButtonStyle.gray, row=2)
            self.has_role = has_role

        async def callback(self, interaction: discord.Interaction):
            has_role = self.has_role
            user_id = interaction.user.id
            imagem = boostera[user_id]["imagem"]

            if clicksma[user_id] == 0:
                clicksma[user_id] += 1
                boostera[user_id]["verificação"] = "2"
                ver = "moldura"
                await animated(interaction, imagem, ver)
                return

            if clicksma[user_id] == 1:
                if boostera[user_id]["verificação"] == "2":
                    boostera[user_id]["verificação"] = "1"
                else:
                    boostera[user_id]["verificação"] = "2"
                    
                embed = discord.Embed(description=f"{interaction.user.mention} | Aqui está um preview de suas fists no formato quadrado e redondo:", colour=0x383d42)
                embed.set_author(name="Privacyᵐᵒᵈˢ", icon_url=interaction.guild.icon.url)
                embed.set_image(url=boostera[user_id]["previews"]["preview1"] if boostera[user_id]["verificação"] == "1" else boostera[user_id]["previews"]["preview2"])
                embed.set_footer(text="© Privacyᵐᵒᵈˢ, 2026. All Rights Reserved.")

                await interaction.response.edit_message(embed=embed, view=ButtonShare(has_role))
                return

    class ButtonShareDL(discord.ui.View):
        def __init__(self, has_role):
            super().__init__(timeout=None)
            self.add_item(discord.ui.Button(label="Quadrada", emoji=emoji_dl, url=boostera[user_id]["previews"]["dl1_1"] if boostera[user_id]["verificação"] == "1" else boostera[user_id]["previews"]["dl1_2"]))
            self.add_item(discord.ui.Button(label="Redonda", emoji=emoji_dl, url=boostera[user_id]["previews"]["dl2_1"] if boostera[user_id]["verificação"] == "1" else boostera[user_id]["previews"]["dl2_2"]))
            self.add_item(ButtonFavorite(has_role))
            if has_role:
                self.add_item(AltMoldura(has_role))

    class ButtonShare(discord.ui.View):
        def __init__(self, has_role):
            super().__init__(timeout=None)
            self.add_item(ButtonFavorite(has_role))
            self.add_item(SimButton(has_role))
            if has_role:
                self.add_item(AltMoldura(has_role))

    class ConfirmNSFWAnimated(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=None)
            
            self.add_item(discord.ui.Button(label="Quadrada", emoji=emoji_dl, url=boostera[user_id]["previews"]["dl1_1"] if boostera[user_id]["verificação"] == "1" else boostera[user_id]["previews"]["dl1_2"], row=1))
            self.add_item(discord.ui.Button(label="Redonda", emoji=emoji_dl, url=boostera[user_id]["previews"]["dl2_1"] if boostera[user_id]["verificação"] == "1" else boostera[user_id]["previews"]["dl2_2"], row=1))
            self.add_item(SFW())
            self.add_item(NSFW())

    link_preview, redonda_zip, quadrada_zip = await generate_image_files()
    if link_preview is None:
        await interaction.edit_original_response(content="Ocorreu um erro durante o upload. Tente novamente.", embed=None, view=None)
        return

    embeds = discord.Embed(description=f"Fist compartilhada por: {user}", colour=0x383d42)
    embeds.set_author(name="Privacyᵐᵒᵈˢ", icon_url=interaction.guild.icon.url)
    embeds.set_image(url=link_preview)
    embed = discord.Embed(description=f"{interaction.user.mention} | Aqui está um preview de suas fists no formato quadrado e redondo:", colour=0x383d42)
    embed.set_author(name="Privacyᵐᵒᵈˢ", icon_url=interaction.guild.icon.url)
    embed.set_image(url=link_preview)
    embed.set_footer(text="© Privacyᵐᵒᵈˢ, 2026. All Rights Reserved.")

    has_role = boostera[user_id]["booster"]

    if boostera[user_id]["verificação"] == "1":
        boostera[user_id]["previews"]["preview1"] = link_preview
        boostera[user_id]["previews"]["dl1_1"] = quadrada_zip
        boostera[user_id]["previews"]["dl2_1"] = redonda_zip

    if boostera[user_id]["verificação"] == "2":
        boostera[user_id]["previews"]["preview2"] = link_preview
        boostera[user_id]["previews"]["dl1_2"] = quadrada_zip
        boostera[user_id]["previews"]["dl2_2"] = redonda_zip

    await interaction.edit_original_response(embed=embed, view=ButtonShare(has_role)) 

class SayConfirmSimModal(discord.ui.Button):
    def __init__(self, msg,  mensagem_final, chat, anexo):
        super().__init__(label="Sim, com mensagem", style=discord.ButtonStyle.green)
        self.msg = msg
        self.mensagem_final = mensagem_final
        self.chat = chat
        self.anexo = anexo

    async def callback(self, interaction: discord.Interaction):
        msgc = self.msg
        msgf = self.mensagem_final
        chat = self.chat
        anexo = self.anexo

        class Modal(discord.ui.Modal, title="MENSAGEM QUE SERÁ ENVIDA NA THREAD"):
            message = discord.ui.TextInput(label="MENSAGEM", placeholder="Mensagem que será enviada após criação da thread", style=discord.TextStyle.paragraph)
            tname = discord.ui.TextInput(label="NOME DA THREAD", placeholder="Nome da thread que será criada\nVázio = mensagem enviada", style=discord.TextStyle.long, max_length=100, required=False)

            async def on_submit(self, interaction: discord.Interaction):

                if anexo is not None:
                    file = await anexo.to_file()
                    msg = await chat.send(msgf, file=file)

                else:
                    msg = await chat.send(msgf)

                if self.tname.value:
                    thread = await msg.create_thread(name=self.tname.value)
                    await thread.send(self.message)

                else:
                    thread = await msg.create_thread(name=msgf[0:100])
                    await thread.send(self.message)

                await msgc(content=f"A mensagem foi enviada e a thread criada! | {thread.mention}", view=None)
                await interaction.response.send_message("enviado.", ephemeral=True, delete_after=0.01)
        
        await interaction.response.send_modal(Modal())

class SayConfirmSim(discord.ui.Button):
    def __init__(self, msg, mensagem_final, chat, anexo):
        super().__init__(label="Sim, sem mensagem", style=discord.ButtonStyle.gray)
        self.msg = msg
        self.mensagem_final = mensagem_final
        self.chat = chat
        self.anexo = anexo

    async def callback(self, interaction: discord.Interaction):
        msgc = self.msg
        msgf = self.mensagem_final
        chat = self.chat
        anexo = self.anexo

        class Modal(discord.ui.Modal, title="MENSAGEM QUE SERÁ ENVIDA NA THREAD"):
            tname = discord.ui.TextInput(label="NOME DA THREAD", placeholder="Nome da thread que será criada\nVázio = mensagem enviada", style=discord.TextStyle.long, max_length=100, required=False)

            async def on_submit(self, interaction: discord.Interaction):

                if anexo is not None:
                    file = await anexo.to_file()
                    msg = await chat.send(msgf, file=file)

                else:
                    msg = await chat.send(msgf)

                if self.tname.value:
                    thread = await msg.create_thread(name=self.tname.value)

                else:
                    thread = await msg.create_thread(name=msgf[0:100])

                await msgc(content=f"A mensagem foi enviada e a thread criada! | {thread.mention}", view=None)
                await interaction.response.send_message("enviado.", ephemeral=True, delete_after=0.01)

        await interaction.response.send_modal(Modal())

class SayConfirmNão(discord.ui.Button):
    def __init__(self, ver, msg, mensagem_final, chat, anexo):
        super().__init__(label="Não, sem thread", style=discord.ButtonStyle.red)
        self.msg = msg
        self.mensagem_final = mensagem_final
        self.chat = chat
        self.anexo = anexo
        self.ver = ver

    async def callback(self, interaction: discord.Interaction):
        if self.ver == True:
            ver = "nao"
            mensagem_final = self.mensagem_final
            chat = self.chat
            anexo = self.anexo
            await CriarSay(interaction, mensagem_final, chat, anexo, ver)
            return
        else:
            if self.anexo is not None:
                file = await self.anexo.to_file()
                msg = await self.chat.send(self.mensagem_final, file=file)

            else:
                msg = await self.chat.send(self.mensagem_final)

            await self.msg(content=f"A mensagem foi enviada! | {msg.jump_url}", view=None)

class SayConfirmSimThread(discord.ui.Button):
    def __init__(self, msg, mensagem_final, chat, anexo):
        super().__init__(label="Sim, enviar na thread", style=discord.ButtonStyle.gray)
        self.msg = msg
        self.mensagem_final = mensagem_final
        self.chat = chat
        self.anexo = anexo

    async def callback(self, interaction: discord.Interaction):
        threads = []
        threads_menu = [self.chat.threads]
        for thread in threads_menu:
            threads.extend(thread)

        options = [discord.SelectOption(label=thread.name, value=str(thread.id)) for thread in threads]
        options.append(discord.SelectOption(label="Voltar", value="back", emoji="◀"))
        select = SelectPrompt(
            placeholder="Selecione uma thread...",
            options=options,
            max_values=1,
        )
        await interaction.response.edit_message(content="**Selecione uma thread abaixo:**", view=select)
        await select.wait()

        if select.values[0] == "back":
            ver = True
            await interaction.edit_original_response(content="Enviar a mensagem em alguma thread?", view=SayButton(ver, self.msg, self.mensagem_final, self.chat, self.anexo))
        
        else:
            thread = interaction.guild.get_thread(int(select.values[0]))
            if self.anexo is not None:
                file = await self.anexo.to_file()
                msg = await thread.send(self.mensagem_final, file=file)

            else:
                msg = await thread.send(self.mensagem_final)

            await self.msg(content=f"A mensagem foi enviada! | {msg.jump_url}", view=None)

class SayButton(discord.ui.View):
    def __init__(self, ver, msg, mensagem_final, chat, anexo):
        super().__init__(timeout=None)
        
        if ver == False:
            self.add_item(SayConfirmSim(msg, mensagem_final, chat, anexo))
            self.add_item(SayConfirmSimModal(msg, mensagem_final, chat, anexo))
        if ver == True:
            self.add_item(SayConfirmSimThread(msg, mensagem_final, chat, anexo))
            
        self.add_item(SayConfirmNão(ver, msg, mensagem_final, chat, anexo))

async def CriarSay(interaction: discord.Interaction, mensagem_final, chat, anexo, ver):
    msg = interaction.edit_original_response

    if chat.id == ChannelIDs.SAY_VERIFY and ver != "nao":
        ver = True
        await interaction.response.send_message("Enviar a mensagem em alguma thread?", view=SayButton(ver, msg, mensagem_final, chat, anexo), ephemeral=True)
    else:
        if ver == False:
            await interaction.response.send_message("Você deseja criar uma thread após o envio da mensagem?", view=SayButton(ver, msg, mensagem_final, chat, anexo), ephemeral=True)
        if ver == "nao":
            ver = False
            await interaction.response.edit_message(content="Você deseja criar uma thread após o envio da mensagem?", view=SayButton(ver, msg, mensagem_final, chat, anexo))

async def translate(interaction: discord.Interaction, message):
    locale = interaction.locale
    locale = str(locale)
    locale = locale.split("-")[0]

    await interaction.response.defer(ephemeral=True)
    try:
        loop = asyncio.get_running_loop()
        translator = GoogleTranslator(source='auto', target=locale)
        translated_text = await loop.run_in_executor(None, translator.translate, message)
        await interaction.followup.send(translated_text, ephemeral=True)
    except Exception as e:
        # Fallback simples em caso de erro na tradução
        await interaction.followup.send(f"Houve um erro na mensagem que deseja traduzir: {e}", ephemeral=True)
