import os
from aiohttp import web
import secrets
import asyncio
import json
import aiohttp
import discord
import datetime
from github import Github
import base64
import socket

routes = web.RouteTableDef()
current_token = None
bot_instance = None
cached_app_id = None

EDITABLE_FILES = [
    ".env",
    "message_counts.json",
    "divisores.json",
    "last_ticket_number.json",
    "user_locales.json",
    "user_history.json"
]

CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, api-token'
}

def get_file_content(filename):
    if filename not in EDITABLE_FILES:
        return ""
    if os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            return f.read()
    return ""

def save_file_content(filename, content):
    if filename not in EDITABLE_FILES:
        return False
    
    try:
        if filename.endswith(".json"):
            json.loads(content)
            
        with open(filename, "w", encoding="utf-8") as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"Erro ao salvar {filename}: {e}")
        return False

def check_auth(request):
    # 1. Verifica Token nos Cookies
    token = request.cookies.get('session_token')
    if token and current_token and token == current_token:
        return True
    
    # 2. Verifica Basic Auth (Usuário/Senha)
    auth_header = request.headers.get('Authorization')
    if auth_header:
        try:
            scheme, params = auth_header.split(' ', 1)
            if scheme.lower() == 'basic':
                decoded = base64.b64decode(params).decode('utf-8')
                username, password = decoded.split(':', 1)
                
                env_user = os.getenv("DASHBOARD_USER", "admin")
                env_pass = os.getenv("DASHBOARD_PASS", "admin")
                
                if username == env_user and password == env_pass:
                    return True
        except:
            pass
    return False

def get_login_page_html(bot_avatar_url, error_message=""):
    """Gera a página de login personalizada."""
    return f"""
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>PrivacyMods - Login</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap');
    * {{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Quicksand', sans-serif;
    }}
    body {{
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        background: #000;
        overflow: hidden;
    }}
    section {{
        position: absolute;
        width: 100vw;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 2px;
        flex-wrap: wrap;
        overflow: hidden;
    }}
    section::before {{
        content: '';
        position: absolute;
        width: 100%;
        height: 100%;
        background: linear-gradient(#000, #e6c200, #000);
        animation: animate 5s linear infinite;
    }}
    @keyframes animate {{
        0% {{ transform: translateY(-100%); }}
        100% {{ transform: translateY(100%); }}
    }}
    section span {{
        position: relative;
        display: block;
        width: calc(6.25vw - 2px);
        height: calc(6.25vw - 2px);
        background: #181818;
        z-index: 2;
        transition: 1.5s;
    }}
    section span:hover {{
        background: #e6c200;
        transition: 0s;
    }}
    .signin {{
        position: absolute;
        width: 400px;
        background: #222;
        z-index: 1000;
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 40px;
        border-radius: 4px;
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.9);
    }}
    .signin .content {{
        position: relative;
        width: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        gap: 20px;
    }}
    .signin .content h2 {{
        font-size: 2em;
        color: #e6c200;
        text-transform: uppercase;
    }}
    .signin .content .form {{
        width: 100%;
        display: flex;
        flex-direction: column;
        gap: 25px;
    }}
    .signin .content .form .inputBox {{
        position: relative;
        width: 100%;
    }}
    .signin .content .form .inputBox input {{
        position: relative;
        width: 100%;
        background: #333;
        border: none;
        outline: none;
        padding: 25px 10px 7.5px;
        border-radius: 4px;
        color: #fff;
        font-weight: 500;
        font-size: 1em;
    }}
    .signin .content .form .inputBox i {{
        position: absolute;
        left: 0;
        padding: 15px 10px;
        font-style: normal;
        color: #aaa;
        transition: 0.5s;
        pointer-events: none;
    }}
    .signin .content .form .inputBox input:focus ~ i,
    .signin .content .form .inputBox input:valid ~ i {{
        transform: translateY(-7.5px);
        font-size: 0.8em;
        color: #fff;
    }}
    .signin .content .form .inputBox input[type="submit"] {{
        padding: 10px;
        background: #e6c200;
        color: #000;
        font-weight: 600;
        font-size: 1.35em;
        letter-spacing: 0.05em;
        cursor: pointer;
    }}
    input[type="submit"]:active {{
        opacity: 0.6;
    }}
    .error-message {{
        color: #ff4747;
        background: rgba(255, 0, 0, 0.1);
        padding: 10px;
        border-radius: 4px;
        text-align: center;
        width: 100%;
    }}
    @media (max-width: 900px) {{
        section span {{
            width: calc(10vw - 2px);
            height: calc(10vw - 2px);
        }}
    }}
    @media (max-width: 600px) {{
        section span {{
            width: calc(20vw - 2px);
            height: calc(20vw - 2px);
        }}
    }}
  </style>
</head>
<body>
<section>
    {''.join(['<span></span>' for _ in range(256)])}
    <div class="signin">
      <div class="content">
        <img src="{bot_avatar_url}" style="width: 80px; height: 80px; border-radius: 50%; border: 2px solid #e6c200;">
        <h2>Sign In</h2>
        <form class="form" action="/login" method="POST">
          {error_message}
          <div class="inputBox">
            <input type="text" name="username" required>
            <i>Username</i>
          </div>
          <div class="inputBox">
            <input type="password" name="password" required>
            <i>Password</i>
          </div>
          <div class="inputBox">
            <input type="submit" value="Login">
          </div>
        </form>
      </div>
    </div>
  </section>
</body>
</html>
"""

@routes.get('/api/logs')
async def api_logs(request):
    if not check_auth(request):
        return web.Response(status=401, headers={'WWW-Authenticate': 'Basic realm="Dashboard"', **CORS_HEADERS})
    
    global cached_app_id
    discloud_token = os.getenv("DISCLOUD_API_KEY")
    app_id = cached_app_id or os.getenv("DISCLOUD_BOT_ID") or os.getenv("BOT_ID")

    if discloud_token and app_id:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"https://api.discloud.app/v2/app/{app_id}/logs", headers={"api-token": discloud_token}) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get("status") == "ok" and "apps" in data:
                             return web.Response(text=data["apps"]["terminal"]["big"], headers=CORS_HEADERS)
        except Exception as e:
            print(f"Erro ao buscar logs da Discloud: {e}")

    if bot_instance:
        return web.Response(text=bot_instance.log_buffer.getvalue(), headers=CORS_HEADERS)
        # Retorna apenas os últimos 2000 caracteres para economizar RAM no plano Free
        log_content = bot_instance.log_buffer.getvalue()
        if len(log_content) > 50000:
            log_content = log_content[-50000:]
        return web.Response(text=log_content, headers=CORS_HEADERS)
    return web.Response(text="Log indisponível.", headers=CORS_HEADERS)

@routes.get('/api/guild_data')
async def api_guild_data(request):
    if not check_auth(request):
        return web.json_response({"error": "Unauthorized"}, status=401, headers={'WWW-Authenticate': 'Basic realm="Dashboard"', **CORS_HEADERS})
    
    if not bot_instance:
        return web.json_response({"error": "Bot not ready"}, status=503, headers=CORS_HEADERS)

    guild_id = int(os.getenv("SERVER_ID", 0))
    guild = bot_instance.get_guild(guild_id)
    
    if not guild:
        return web.json_response({"error": "Guild not found"}, status=404, headers=CORS_HEADERS)

    channels_struct = []
    # Ordena categorias por posição
    categories = sorted(guild.categories, key=lambda c: c.position)
    
    # Canais de texto sem categoria
    no_cat = [c for c in guild.text_channels if c.category is None]
    if no_cat:
        channels_struct.append({
            "id": "nocat", "name": "Sem Categoria", 
            "channels": [{"id": str(c.id), "name": c.name} for c in no_cat]
        })

    for cat in categories:
        chans = [c for c in cat.text_channels]
        if chans:
            channels_struct.append({
                "id": str(cat.id), "name": cat.name,
                "channels": [{"id": str(c.id), "name": c.name} for c in chans]
            })

    return web.json_response({
        "guild_name": guild.name,
        "guild_icon": guild.icon.url if guild.icon else "https://cdn.discordapp.com/embed/avatars/0.png",
        "bot_name": bot_instance.user.name,
        "bot_avatar": bot_instance.user.avatar.url if bot_instance.user.avatar else "https://cdn.discordapp.com/embed/avatars/0.png",
        "channels": channels_struct
    }, headers=CORS_HEADERS)

@routes.get('/api/search_members')
async def api_search_members(request):
    if not check_auth(request):
        return web.Response(status=401, headers={'WWW-Authenticate': 'Basic realm="Dashboard"', **CORS_HEADERS})
    
    query = request.query.get('q', '').lower()
    guild_id = int(os.getenv("SERVER_ID", 0))
    guild = bot_instance.get_guild(guild_id)
    
    results = []
    if guild:
        count = 0
        # Limita a busca para evitar travamento em servidores grandes com pouca RAM
        for m in guild.members[:2000]: 
            if query in m.name.lower() or (m.nick and query in m.nick.lower()) or query in str(m.id):
                results.append({
                    "id": str(m.id),
                    "name": m.name,
                    "nick": m.nick,
                    "avatar": m.avatar.url if m.avatar else m.default_avatar.url
                })
                count += 1
                if count >= 20: break
    return web.json_response(results, headers=CORS_HEADERS)

@routes.get('/api/get_messages')
async def api_get_messages(request):
    if not check_auth(request):
        return web.Response(status=401, headers={'WWW-Authenticate': 'Basic realm="Dashboard"', **CORS_HEADERS})
    
    channel_id = request.query.get('channel_id')
    try:
        channel = bot_instance.get_channel(int(channel_id))
        msgs = []
        async for m in channel.history(limit=20):
            if m.author.id == bot_instance.user.id:
                desc = m.content
                if not desc and m.embeds:
                    desc = f"[Embed] {m.embeds[0].title or m.embeds[0].description or 'Sem título'}"
                if not desc: desc = "[Sem conteúdo]"
                msgs.append({"id": str(m.id), "content": desc[:60], "date": m.created_at.strftime("%d/%m %H:%M")})
        return web.json_response(msgs, headers=CORS_HEADERS)
    except:
        return web.json_response([], headers=CORS_HEADERS)

@routes.get('/api/get_message_details')
async def api_get_message_details(request):
    if not check_auth(request):
        return web.Response(status=401, headers={'WWW-Authenticate': 'Basic realm="Dashboard"', **CORS_HEADERS})
    
    channel_id = request.query.get('channel_id')
    message_id = request.query.get('message_id')
    
    if not channel_id or not message_id:
        return web.json_response({"error": "Parâmetros inválidos"}, status=400, headers=CORS_HEADERS)
        
    try:
        channel = bot_instance.get_channel(int(channel_id))
        if not channel: return web.json_response({"error": "Canal não encontrado"}, status=404, headers=CORS_HEADERS)
        
        msg = await channel.fetch_message(int(message_id))
        
        embed_json = ""
        if msg.embeds:
            embed_json = json.dumps(msg.embeds[0].to_dict(), indent=4)
            
        return web.json_response({"content": msg.content, "embed_json": embed_json}, headers=CORS_HEADERS)
    except Exception as e:
        return web.json_response({"error": str(e)}, status=500, headers=CORS_HEADERS)

@routes.post('/api/action')
async def api_action(request):
    if not check_auth(request):
        return web.json_response({"success": False, "message": "Acesso negado."}, status=401, headers={'WWW-Authenticate': 'Basic realm="Dashboard"', **CORS_HEADERS})
    
    if not bot_instance:
        return web.json_response({"success": False, "message": "Bot não inicializado."}, status=500, headers=CORS_HEADERS)

    data = await request.post()
    action = data.get('action')
    
    try:
        if action == 'send_message':
            target_id = int(data.get('target_id'))
            content = data.get('content')
            embed_json = data.get('embed_json')
            is_dm = data.get('is_dm') == 'true'
            message_id = data.get('message_id')
            
            target = None
            if is_dm:
                target = await bot_instance.fetch_user(target_id)
            else:
                target = bot_instance.get_channel(target_id)
                
            if not target:
                return web.json_response({"success": False, "message": "Alvo não encontrado."}, headers=CORS_HEADERS)
                
            embed = None
            if embed_json and embed_json.strip():
                try:
                    embed_dict = json.loads(embed_json)
                    embed = discord.Embed.from_dict(embed_dict)
                except Exception as e:
                    return web.json_response({"success": False, "message": f"Erro no JSON do Embed: {e}"}, headers=CORS_HEADERS)
            
            if not content and not embed:
                 return web.json_response({"success": False, "message": "Mensagem vazia."}, headers=CORS_HEADERS)

            if message_id:
                try:
                    msg = await target.fetch_message(int(message_id))
                    await msg.edit(content=content if content else None, embed=embed)
                    return web.json_response({"success": True, "message": "Mensagem editada com sucesso!"}, headers=CORS_HEADERS)
                except Exception as e:
                    return web.json_response({"success": False, "message": f"Erro ao editar mensagem: {e}"}, headers=CORS_HEADERS)
            else:
                await target.send(content=content, embed=embed)
                return web.json_response({"success": True, "message": "Mensagem enviada!"}, headers=CORS_HEADERS)

        elif action == 'moderation':
            user_id = int(data.get('user_id'))
            mod_action = data.get('mod_action')
            reason = data.get('reason')
            duration = int(data.get('duration', 0))
            
            guild_id = int(os.getenv("SERVER_ID"))
            guild = bot_instance.get_guild(guild_id)
            if not guild: return web.json_response({"success": False, "message": "Servidor não encontrado."}, headers=CORS_HEADERS)
            
            if mod_action == 'unban':
                 await guild.unban(discord.Object(id=user_id), reason=reason)
            else:
                member = await guild.fetch_member(user_id)
                if not member: return web.json_response({"success": False, "message": "Membro não encontrado."})
                if mod_action == 'ban': await member.ban(reason=reason)
                elif mod_action == 'kick': await member.kick(reason=reason)
                elif mod_action == 'timeout': await member.timeout(datetime.timedelta(minutes=duration) if duration > 0 else None, reason=reason)
            return web.json_response({"success": True, "message": f"Ação {mod_action} executada."})
    except Exception as e: return web.json_response({"success": False, "message": f"Erro: {e}"})
    return web.json_response({"success": False, "message": "Ação desconhecida."})

@routes.get('/')
async def index(request):
    if not check_auth(request): # Se não estiver autenticado
        error = request.query.get('error')
        error_msg_html = '<div class="error-message">Usuário ou senha inválidos.</div>' if error else ''
        
        bot_avatar = bot_instance.user.avatar.url if bot_instance and bot_instance.user.avatar else "https://cdn.discordapp.com/embed/avatars/0.png"
        
        login_page = get_login_page_html(bot_avatar, error_msg_html)
        return web.Response(text=login_page, content_type='text/html')
    
    # Se estiver autenticado, mostra o painel normal
    current_file = request.query.get('file', 'management')
    if current_file not in ['logs', 'management'] and current_file not in EDITABLE_FILES:
        current_file = 'management'

    file_content = get_file_content(current_file) if current_file not in ['logs', 'management'] else ""
    
    # Navigation Logic
    nav_items = [
        {"id": "management", "icon": "construct-outline", "text": "Gestão", "link": "/?file=management"},
        {"id": "logs", "icon": "terminal-outline", "text": "Logs", "link": "/?file=logs"},
        {"id": "editor", "icon": "folder-open-outline", "text": "Arquivos", "link": "/?file=.env"},
    ]

    active_tab = "management"
    if current_file == "logs":
        active_tab = "logs"
    elif current_file in EDITABLE_FILES:
        active_tab = "editor"

    nav_html = ""
    for item in nav_items:
        is_active = "active" if item["id"] == active_tab else ""
        nav_html += f"""
        <li class="{is_active}">
            <a href="{item['link']}">
                <span class="icon">
                    <ion-icon name="{item['icon']}"></ion-icon>
                </span>
                <span class="text">{item['text']}</span>
            </a>
        </li>
        """

    # Bot Info for Sidebar
    bot_avatar = bot_instance.user.avatar.url if bot_instance and bot_instance.user.avatar else "https://cdn.discordapp.com/embed/avatars/0.png"
    bot_name = bot_instance.user.name if bot_instance else "Privacy Mods"

    js_config = f"""
        const API_BASE = "";
    """

    section_id = "editor"
    if current_file == "logs": section_id = "logs"
    elif current_file == "management": section_id = "management"

    if current_file == "logs":
        main_content = f"""
            <div class="header">
                <div class="file-info">
                    <h2>Logs do Sistema <span class="file-badge">REAL-TIME</span></h2>
                </div>
                <button onclick="fetchLogs()" class="btn-save" style="width: auto;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
                    Atualizar
                </button>
            </div>
            <div class="editor-wrapper" style="background-color: #0d1117;">
                <pre id="logViewer" style="padding: 20px; color: #c9d1d9; font-family: 'JetBrains Mono', monospace; font-size: 12px; overflow: auto; height: 100%; white-space: pre-wrap; margin: 0;"></pre>
            </div>
            <script>
                const logViewer = document.getElementById('logViewer');
                let autoScroll = true;

                logViewer.addEventListener('scroll', () => {{
                    if (logViewer.scrollTop + logViewer.clientHeight >= logViewer.scrollHeight - 10) {{
                        autoScroll = true;
                    }} else {{
                        autoScroll = false;
                    }}
                }});
                
                async function fetchLogs() {{
                    try {{
                        const response = await fetch('/api/logs');
                        const text = await response.text();
                        logViewer.textContent = text;
                        if (autoScroll) {{
                            logViewer.scrollTop = logViewer.scrollHeight;
                        }}
                    }} catch (e) {{
                        console.error(e);
                    }}
                }}
                
                setInterval(fetchLogs, 2000);
                fetchLogs();
            </script>
        """
    elif current_file == "management":
        main_content = f"""
            <div class="header">
                <div class="file-info" style="display: flex; align-items: center; gap: 15px;">
                    <img id="guildIcon" src="" style="width: 40px; height: 40px; border-radius: 50%; display: none;">
                    <div>
                        <h2 id="guildName">Carregando...</h2>
                        <span class="file-badge">ADMIN DASHBOARD</span>
                    </div>
                </div>
            </div>
            <div class="editor-wrapper" style="padding: 20px; overflow-y: auto;">
                <!-- Messaging Section -->
                <div style="margin-bottom: 30px; background: rgba(0,0,0,0.2); padding: 20px; border-radius: 8px;">
                    <h3 style="color: var(--accent); margin-bottom: 15px; display: flex; align-items: center; gap: 8px;">📨 Enviar Mensagem / Embed</h3>
                    <form onsubmit="submitAction(event, 'send_message')">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                            <div>
                                <label style="display: block; margin-bottom: 5px; font-size: 12px; color: var(--text-muted);">ID do Canal ou Usuário</label>
                                <div style="display: flex; gap: 5px;">
                                    <input type="text" id="target_id" name="target_id" required style="flex: 1; background: var(--bg-body); border: 1px solid var(--border); color: white; padding: 8px; border-radius: 4px;">
                                    <button type="button" class="btn-icon" onclick="openModal('channelModal')" title="Selecionar Canal">#</button>
                                    <button type="button" class="btn-icon" onclick="openModal('memberModal')" title="Selecionar Membro">@</button>
                                </div>
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 5px; font-size: 12px; color: var(--text-muted);">ID da Mensagem (Para Editar - Opcional)</label>
                                <div style="display: flex; gap: 5px;">
                                    <input type="text" id="message_id" name="message_id" style="flex: 1; background: var(--bg-body); border: 1px solid var(--border); color: white; padding: 8px; border-radius: 4px;" placeholder="Deixe vazio para enviar nova">
                                    <button type="button" class="btn-icon" onclick="openPanelSelector()" title="Selecionar Painel">📄</button>
                                </div>
                            </div>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                                <input type="checkbox" name="is_dm" id="is_dm_check" value="true">
                                <span style="font-size: 13px; color: var(--text-muted);">É uma Mensagem Direta (DM)?</span>
                            </label>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 5px; font-size: 12px; color: var(--text-muted);">Conteúdo da Mensagem</label>
                            <textarea name="content" rows="3" style="width: 100%; background: var(--bg-body); border: 1px solid var(--border); color: white; padding: 8px; border-radius: 4px; font-family: sans-serif;"></textarea>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 5px; font-size: 12px; color: var(--text-muted);">JSON do Embed (Opcional)</label>
                            <textarea name="embed_json" rows="5" style="width: 100%; background: var(--bg-body); border: 1px solid var(--border); color: white; padding: 8px; border-radius: 4px; font-family: monospace;" placeholder='{{"title": "Exemplo", "description": "..."}}'></textarea>
                        </div>
                        <button type="submit" class="btn-save">Executar Ação</button>
                    </form>
                </div>

                <!-- Moderation Section -->
                <div style="background: rgba(0,0,0,0.2); padding: 20px; border-radius: 8px;">
                    <h3 style="color: #ef4444; margin-bottom: 15px; display: flex; align-items: center; gap: 8px;">🛡️ Moderação</h3>
                    <form onsubmit="submitAction(event, 'moderation')">
                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                            <div>
                                <label style="display: block; margin-bottom: 5px; font-size: 12px; color: var(--text-muted);">ID do Usuário</label>
                                <div style="display: flex; gap: 5px;">
                                    <input type="text" id="mod_user_id" name="user_id" required style="flex: 1; background: var(--bg-body); border: 1px solid var(--border); color: white; padding: 8px; border-radius: 4px;">
                                    <button type="button" class="btn-icon" onclick="openModal('memberModal', 'mod_user_id')" title="Selecionar Membro">@</button>
                                </div>
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 5px; font-size: 12px; color: var(--text-muted);">Ação</label>
                                <select name="mod_action" style="width: 100%; background: var(--bg-body); border: 1px solid var(--border); color: white; padding: 8px; border-radius: 4px;">
                                    <option value="timeout">Mutar (Timeout)</option>
                                    <option value="kick">Expulsar (Kick)</option>
                                    <option value="ban">Banir</option>
                                    <option value="unban">Desbanir</option>
                                </select>
                            </div>
                            <div>
                                <label style="display: block; margin-bottom: 5px; font-size: 12px; color: var(--text-muted);">Duração (Minutos - Apenas Mute)</label>
                                <input type="number" name="duration" value="0" style="width: 100%; background: var(--bg-body); border: 1px solid var(--border); color: white; padding: 8px; border-radius: 4px;">
                            </div>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 5px; font-size: 12px; color: var(--text-muted);">Motivo</label>
                            <input type="text" name="reason" style="width: 100%; background: var(--bg-body); border: 1px solid var(--border); color: white; padding: 8px; border-radius: 4px;">
                        </div>
                        <button type="submit" class="btn-save" style="background-color: #ef4444;">Executar Punição</button>
                    </form>
                </div>
            </div>

            <!-- Modals -->
            <div id="channelModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Selecionar Canal</h3>
                        <span class="close" onclick="closeModal('channelModal')">&times;</span>
                    </div>
                    <div id="channelList" class="modal-body">Carregando...</div>
                </div>
            </div>

            <div id="memberModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Selecionar Membro</h3>
                        <span class="close" onclick="closeModal('memberModal')">&times;</span>
                    </div>
                    <div style="padding: 10px;">
                        <input type="text" id="memberSearch" placeholder="Buscar por nome ou ID..." onkeyup="searchMembers()" style="width: 100%; padding: 8px; background: var(--bg-input); border: 1px solid var(--border); color: white; border-radius: 4px;">
                    </div>
                    <div id="memberList" class="modal-body">Digite para buscar...</div>
                </div>
            </div>

            <div id="panelModal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Selecionar Painel (Mensagem)</h3>
                        <span class="close" onclick="closeModal('panelModal')">&times;</span>
                    </div>
                    <div style="padding: 10px; font-size: 12px; color: var(--text-muted);">
                        1. Selecione o canal onde está o painel.<br>
                        2. Selecione a mensagem do bot.
                    </div>
                    <div id="panelChannelList" class="modal-body" style="max-height: 150px; overflow-y: auto; border-bottom: 1px solid var(--border);">Carregando canais...</div>
                    <div id="panelMessageList" class="modal-body" style="max-height: 200px; overflow-y: auto;">Selecione um canal acima.</div>
                </div>
            </div>
        """
    else:
        # Editor de Arquivos
        options = ""
        for f in EDITABLE_FILES:
            selected = "selected" if f == current_file else ""
            options += f'<option value="{f}" {selected}>{f}</option>'
            
        file_selector = f"""
        <div style="margin-bottom: 20px; background: #242433; padding: 15px; border-radius: 15px; display: flex; align-items: center; gap: 10px; box-shadow: inset 5px 5px 10px rgba(0,0,0,0.2);">
            <ion-icon name="folder-open-outline" style="font-size: 24px; color: #29fd53;"></ion-icon>
            <span style="font-weight: 600;">Editando:</span>
            <select onchange="window.location.href='/?file='+this.value" style="flex: 1; padding: 10px; border-radius: 10px; background: #2f363e; color: #fff; border: none; outline: none; font-family: 'Poppins', sans-serif;">
                {options}
            </select>
        </div>
        """

        main_content = f"""
            {file_selector}
            <form id="editorForm" action="/save?file={current_file}" method="POST" style="display: flex; flex-direction: column; height: 100%;">
                <div class="header">
                    <div class="file-info">
                        <h2>{current_file} <span class="file-badge">EDITANDO</span></h2>
                    </div>
                    <button type="submit" class="btn-save" id="saveBtn">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
                        Salvar Alterações
                    </button>
                </div>
                
                <div class="editor-wrapper">
                    <textarea name="file_content" spellcheck="false">{file_content}</textarea>
                </div>
            </form>
        """

    main_content = f'<div id="{section_id}" class="section active">{main_content}</div>'

    html = f"""
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Privacy Mods Dashboard</title>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        <style>
            @import url("https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap");
            
            * {{
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                font-family: "Poppins", sans-serif;
            }}

            :root {{
                --bg-body: #262433;
                --bg-nav: #242433;
                --text-main: #fff;
                --accent: #29fd53;
                --bg-card: #2f363e;
                --border: #444;
            }}
            
            body {{
                min-height: 100vh;
                background: var(--bg-body);
                color: var(--text-main);
                overflow-x: hidden;
                padding-bottom: 140px;
            }}
            
            .navigation {{
                position: fixed;
                bottom: 20px;
                left: 50%;
                transform: translateX(-50%);
                width: 350px;
                height: 100px;
                background: var(--bg-nav);
                box-shadow: inset 5px 5px 10px rgba(0, 0, 0, 0.5),
                    inset 5px 5px 20px rgba(255, 255, 255, 0.2),
                    inset -5px -5px 15px rgba(0, 0, 0, 0.75);
                border-radius: 25px;
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 1000;
            }}

            .navigation li {{
                position: relative;
                list-style: none;
                width: 80px;
                margin: 0 5px;
            }}

            .navigation li::before {{
                content: "";
                position: absolute;
                top: 35px;
                left: 50%;
                transform: translateX(-50%);
                width: 5px;
                height: 5px;
                background: #222;
                border-radius: 50%;
                transition: 0.5s;
            }}

            .navigation li.active::before {{
                background: #0f0;
                box-shadow: 0 0 5px #0f0, 0 0 10px #0f0, 0 0 20px #0f0, 0 0 30px #0f0,
                    0 0 40px #0f0, 0 0 50px #0f0;
            }}

            .navigation li a {{
                display: flex;
                align-items: center;
                justify-content: center;
                flex-direction: column;
                text-decoration: none;
            }}

            .navigation li a .icon {{
                position: absolute;
                font-size: 1.75em;
                width: 80px;
                height: 80px;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #aaa;
                border-radius: 50px;
                transition: 0.5s;
                transition-delay: 0.2s;
            }}

            .navigation li.active a .icon {{
                background: var(--accent);
                color: #fff;
                transform: translateY(-55px);
                box-shadow: 5px 5px 7px rgba(0, 0, 0, 0.25),
                    inset 2px 2px 3px rgba(255, 255, 255, 0.25),
                    inset -3px -3px 5px rgba(0, 0, 0, 0.5);
                transition-delay: 0s;
            }}

            .navigation li a .icon::before {{
                content: "";
                position: absolute;
                inset: 10px;
                background: #2f363e;
                border-radius: 50%;
                box-shadow: 5px 5px 5px rgba(0, 0, 0, 0.5),
                    inset 2px 2px 3px rgba(255, 255, 255, 0.25),
                    inset -3px -3px 5px rgba(0, 0, 0, 0.5);
                transform: scale(0);
                transition: 0.5s;
            }}

            .navigation li.active a .icon::before {{
                transform: scale(1);
            }}

            .navigation li a .text {{
                position: absolute;
                font-size: 0.75em;
                color: #2f363e;
                opacity: 0;
                transform: translateY(20px);
                padding: 2px 10px;
                background: #fff;
                border-radius: 15px;
                box-shadow: 5px 5px 7px rgba(0, 0, 0, 0.25),
                    inset -3px -3px 5px rgba(0, 0, 0, 0.5);
                transition: 0.5s;
                transition-delay: 0s;
            }}

            .navigation li.active a .text {{
                opacity: 1;
                transform: translateY(10px);
                transition-delay: 0.2s;
            }}

            /* Main Content */
            .main {{
                padding: 40px;
                max-width: 1200px;
                margin: 0 auto;
            }}
            
            .header {{
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 24px;
            }}
            
            .file-info h2 {{
                font-size: 20px;
                font-weight: 600;
                color: var(--text-main);
                display: flex;
                align-items: center;
                gap: 10px;
            }}
            
            .file-badge {{
                font-size: 11px;
                background: var(--bg-nav);
                padding: 4px 8px;
                border-radius: 4px;
                border: 1px solid var(--border);
                color: #aaa;
                font-family: 'JetBrains Mono', monospace;
            }}
            
            .editor-wrapper {{
                flex: 1;
                background-color: var(--bg-card);
                border-radius: 8px;
                border: 1px solid var(--border);
                display: flex;
                flex-direction: column;
                overflow: hidden;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            }}
            
            textarea {{
                flex: 1;
                background-color: transparent;
                color: #fff;
                border: none;
                padding: 24px;
                font-family: 'JetBrains Mono', monospace;
                font-size: 13px;
                line-height: 1.6;
                resize: none;
            }}
            
            .btn-save {{
                background-color: var(--accent);
                color: #2f363e;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-size: 13px;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.2s;
                display: flex;
                align-items: center;
                gap: 8px;
                box-shadow: 0 4px 12px rgba(41, 253, 83, 0.2);
            }}
            
            .btn-save:hover {{
                filter: brightness(1.1);
                transform: translateY(-1px);
            }}
            
            .btn-save:disabled {{
                opacity: 0.7;
                cursor: not-allowed;
                transform: none;
            }}

            /* Toast Notification */
            .toast {{
                position: fixed;
                top: 30px;
                right: 30px;
                background: var(--bg-nav);
                border: 1px solid var(--border);
                padding: 16px 20px;
                border-radius: 8px;
                display: flex;
                align-items: center;
                gap: 12px;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
                transform: translateY(100px);
                opacity: 0;
                transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
                z-index: 100;
            }}
            
            .toast.show {{
                transform: translateY(0);
                opacity: 1;
            }}
            
            .toast.success {{ border-left: 4px solid var(--success); }}
            .toast.error {{ border-left: 4px solid var(--danger); }}
            
            .toast-title {{ font-weight: 600; font-size: 14px; }}
            .toast-desc {{ font-size: 12px; color: #aaa; margin-top: 2px; }}

            /* Modal Styles */
            .modal {{ display: none; position: fixed; z-index: 200; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.7); backdrop-filter: blur(2px); }}
            .modal-content {{ background-color: var(--bg-card); margin: 5% auto; padding: 0; border: 1px solid var(--border); width: 500px; border-radius: 8px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); display: flex; flex-direction: column; max-height: 80vh; }}
            .modal-header {{ padding: 15px 20px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }}
            .modal-header h3 {{ font-size: 16px; margin: 0; color: var(--text-main); }}
            .close {{ color: var(--text-muted); font-size: 24px; font-weight: bold; cursor: pointer; }}
            .close:hover {{ color: var(--text-main); }}
            .modal-body {{ padding: 10px; overflow-y: auto; flex: 1; }}
            
            .list-item {{ padding: 10px; border-bottom: 1px solid rgba(255,255,255,0.05); cursor: pointer; display: flex; align-items: center; gap: 10px; transition: background 0.2s; }}
            .list-item:hover {{ background-color: rgba(255,255,255,0.05); }}
            .list-item:last-child {{ border-bottom: none; }}
            .list-item-icon {{ width: 20px; height: 20px; border-radius: 50%; background: #333; display: flex; align-items: center; justify-content: center; font-size: 10px; }}
            .list-item-details {{ display: flex; flex-direction: column; }}
            .list-item-sub {{ font-size: 11px; color: #aaa; }}
            
            .category-header {{ padding: 8px 10px; font-size: 11px; font-weight: bold; color: var(--accent); text-transform: uppercase; background: rgba(0,0,0,0.2); margin-top: 5px; }}

            .btn-icon {{ background: var(--bg-nav); border: 1px solid var(--border); color: var(--text-main); width: 34px; height: 34px; border-radius: 4px; cursor: pointer; display: flex; align-items: center; justify-content: center; font-weight: bold; transition: all 0.2s; }}
            .btn-icon:hover {{ background: var(--accent); color: black; border-color: var(--accent); }}
            
            .section {{ display: none; flex: 1; flex-direction: column; overflow: hidden; }}
            .section.active {{ display: flex; }}
            
            input, select, textarea {{ background: #242433; color: #fff; border: 1px solid #444; }}

        </style>
    </head>
    <body>
        <main class="main">
            {main_content}
        </main>
        
        <ul class="navigation">
            {nav_html}
        </ul>

        <div id="toast" class="toast">
            <div id="toast-icon"></div>
            <div>
                <div id="toast-title" class="toast-title"></div>
                <div id="toast-desc" class="toast-desc"></div>
            </div>
        </div>

        <script>
            {js_config}
            
            let list = document.querySelectorAll(".navigation li");
            function activeLink() {{
                list.forEach((item) => item.classList.remove("active"));
                this.classList.add("active");
            }}
            list.forEach((item) => item.addEventListener("click", activeLink));

            // Logs Logic
            const logViewer = document.getElementById('logViewer');
            async function fetchLogs() {{
                try {{
                    const response = await fetch(`${{API_BASE}}/api/logs?token=${{TOKEN}}`);
                    const text = await response.text();
                    logViewer.textContent = text;
                    logViewer.scrollTop = logViewer.scrollHeight;
                    if(logViewer) {{
                        logViewer.textContent = text;
                        logViewer.scrollTop = logViewer.scrollHeight;
                    }}
                }} catch (e) {{ console.error(e); }}
            }}
            if(document.getElementById('logs')) setInterval(fetchLogs, 5000);
            if(document.getElementById('logs')) {{
                setInterval(fetchLogs, 5000);
                fetchLogs();
            }}

            // Toast Logic
            // Editor Scripts
            if (document.getElementById('editorForm')) {{
            const form = document.getElementById('editorForm');
            const btn = document.getElementById('saveBtn');
            const toast = document.getElementById('toast');
            
            function showToast(type, title, desc) {{
                toast.className = 'toast show ' + type;
                document.getElementById('toast-title').innerText = title;
                document.getElementById('toast-desc').innerText = desc;
                document.getElementById('toast-icon').innerHTML = type === 'success' ? '✅' : '❌';
                
                setTimeout(() => {{
                    toast.className = 'toast ' + type;
                }}, 3000);
            }}

            form.addEventListener('submit', async (e) => {{
                e.preventDefault();
                const originalContent = btn.innerHTML;
                btn.innerHTML = '⏳ Salvando...';
                btn.disabled = true;
                
                try {{
                    const formData = new FormData(e.target);
                    const response = await fetch(e.target.action, {{
                        method: 'POST',
                        body: formData
                    }});
                    
                    const result = await response.json();
                    
                    if (result.success) {{
                        showToast('success', 'Sucesso!', result.message);
                    }} else {{
                        showToast('error', 'Erro!', result.message);
                    }}
                }} catch (err) {{
                    showToast('error', 'Erro de Conexão', 'Não foi possível salvar o arquivo.');
                }}
                
                btn.innerHTML = originalContent;
                btn.disabled = false;
            }});
            
            // Simple tab support for textarea
            document.querySelector('textarea').addEventListener('keydown', function(e) {{
                if (e.key == 'Tab') {{
                    e.preventDefault();
                    var start = this.selectionStart;
                    var end = this.selectionEnd;
                    this.value = this.value.substring(0, start) + "    " + this.value.substring(end);
                    this.selectionStart = this.selectionEnd = start + 4;
                }}
            }});
            }}
            
            // Management Scripts
            let currentTargetInput = 'target_id';
            let guildData = null;

            async function loadGuildData() {{
                if (guildData) return;
                try {{
                    const res = await fetch(`${{API_BASE}}/api/guild_data`);
                    guildData = await res.json();
                    
                    // Update Header
                    const icon = document.getElementById('guildIcon');
                    const name = document.getElementById('guildName');
                    if(icon && name) {{
                        icon.src = guildData.guild_icon;
                        icon.style.display = 'block';
                        name.innerText = guildData.guild_name;
                    }}
                }} catch(e) {{ console.error(e); }}
            }}

            // Load data if on management page
            if (document.getElementById('guildName')) {{
                loadGuildData();
            }}

            function openModal(id, targetInputId = 'target_id') {{
                currentTargetInput = targetInputId;
                document.getElementById(id).style.display = 'block';
                if (id === 'channelModal') renderChannels();
                if (id === 'memberModal') searchMembers();
            }}

            function closeModal(id) {{
                document.getElementById(id).style.display = 'none';
            }}

            function renderChannels(containerId = 'channelList', onClickFunc = 'selectChannel') {{
                if (!guildData) return;
                const container = document.getElementById(containerId);
                container.innerHTML = '';
                
                guildData.channels.forEach(cat => {{
                    if (cat.id !== 'nocat') {{
                        container.innerHTML += `<div class="category-header">${{cat.name}}</div>`;
                    }}
                    cat.channels.forEach(ch => {{
                        container.innerHTML += `
                            <div class="list-item" onclick="${{onClickFunc}}('${{ch.id}}')">
                                <div class="list-item-icon">#</div>
                                <div>${{ch.name}}</div>
                            </div>`;
                    }});
                }});
            }}

            function selectChannel(id) {{
                document.getElementById(currentTargetInput).value = id;
                closeModal('channelModal');
            }}

            async function searchMembers() {{
                const query = document.getElementById('memberSearch').value;
                
                const res = await fetch(`${{API_BASE}}/api/search_members?q=${{encodeURIComponent(query)}}`);
                const members = await res.json();
                const container = document.getElementById('memberList');
                container.innerHTML = '';
                
                members.forEach(m => {{
                    container.innerHTML += `
                        <div class="list-item" onclick="selectMember('${{m.id}}')">
                            <img src="${{m.avatar}}" style="width: 30px; height: 30px; border-radius: 50%;">
                            <div class="list-item-details">
                                <span>${{m.name}}</span>
                                <span class="list-item-sub">${{m.id}}</span>
                            </div>
                        </div>`;
                }});
            }}

            function selectMember(id) {{
                document.getElementById(currentTargetInput).value = id;
                closeModal('memberModal');
            }}

            function openPanelSelector() {{
                openModal('panelModal');
                renderChannels('panelChannelList', 'loadChannelMessages');
            }}

            async function loadChannelMessages(channelId) {{
                const container = document.getElementById('panelMessageList');
                container.innerHTML = '<div style="padding:10px;">Carregando mensagens...</div>';
                
                const res = await fetch(`${{API_BASE}}/api/get_messages?channel_id=${{channelId}}`);
                const msgs = await res.json();
                container.innerHTML = '';
                
                if (msgs.length === 0) container.innerHTML = '<div style="padding:10px;">Nenhuma mensagem do bot encontrada.</div>';
                
                msgs.forEach(m => {{
                    container.innerHTML += `
                        <div class="list-item" onclick="selectMessage('${{m.id}}', '${{channelId}}')">
                            <div class="list-item-details">
                                <span style="font-weight:bold;">${{m.content}}</span>
                                <span class="list-item-sub">ID: ${{m.id}} • ${{m.date}}</span>
                            </div>
                        </div>`;
                }});
            }}

            function selectMessage(id, channelId) {{
                document.getElementById('message_id').value = id;
                document.getElementById('target_id').value = channelId;
                closeModal('panelModal');
                loadMessageDetails(channelId, id);
            }}

            async function loadMessageDetails(channelId, messageId) {{
                try {{
                    const res = await fetch(`${{API_BASE}}/api/get_message_details?channel_id=${{channelId}}&message_id=${{messageId}}`);
                    const data = await res.json();
                    
                    if (data.error) {{
                        showToast('error', 'Erro', data.error);
                        return;
                    }}
                    
                    document.querySelector('textarea[name="content"]').value = data.content;
                    document.querySelector('textarea[name="embed_json"]').value = data.embed_json;
                    showToast('success', 'Carregado', 'Conteúdo da mensagem carregado para edição.');
                    
                }} catch(e) {{ console.error(e); }}
            }}

            // DM Template
            document.getElementById('is_dm_check').addEventListener('change', function(e) {{
                if(e.target.checked) {{
                    const embedField = document.querySelector('textarea[name="embed_json"]');
                    if(!embedField.value.trim()) {{
                        embedField.value = JSON.stringify({{
                            "title": "Mensagem Privada",
                            "description": "Olá! Esta é uma mensagem oficial da administração.",
                            "color": 3092790,
                            "footer": {{ "text": "Privacy Mods • Suporte" }}
                        }}, null, 4);
                    }}
                }}
            }}

            async function submitAction(e, actionType) {{
                e.preventDefault();
                const formData = new FormData(e.target);
                formData.append('action', actionType);
                
                try {{
                    const response = await fetch(`${{API_BASE}}/api/action`, {{ method: 'POST', body: formData }});
                    const result = await response.json();
                    if (result.success) {{
                        showToast('success', 'Sucesso', result.message);
                        if(actionType === 'moderation') e.target.reset();
                    }} else {{
                        showToast('error', 'Erro', result.message);
                    }}
                }} catch (err) {{ showToast('error', 'Erro', 'Falha na requisição.'); }}
            }}
        </script>
    </body>
    </html>
    """
    return web.Response(text=html, content_type='text/html')

@routes.post('/save')
async def save(request):
    if not check_auth(request):
        return web.json_response({"success": False, "message": "Acesso negado."}, status=401, headers={'WWW-Authenticate': 'Basic realm="Dashboard"', **CORS_HEADERS})
    
    target_file = request.query.get('file', '.env')
    
    data = await request.post()
    content = data.get('file_content')
    
    if content is not None:
        success = save_file_content(target_file, content)
        if success:
            msg = "Salvo com sucesso!"
            if target_file == ".env":
                msg += " Reinicie o bot para aplicar alterações no .env."
            return web.json_response({"success": True, "message": msg}, headers=CORS_HEADERS)
        else:
            return web.json_response({"success": False, "message": "Erro ao salvar! Verifique se o JSON é válido."}, headers=CORS_HEADERS)
    else:
        return web.json_response({"success": False, "message": "Conteúdo vazio."})

@routes.post('/login')
async def handle_login(request):
    global current_token
    data = await request.post()
    username = data.get('username')
    password = data.get('password')

    env_user = os.getenv("DASHBOARD_USER", "admin")
    env_pass = os.getenv("DASHBOARD_PASS", "admin")

    if username == env_user and password == env_pass:
        current_token = secrets.token_urlsafe(32)
        response = web.HTTPFound('/')
        response.set_cookie('session_token', current_token, httponly=True, max_age=86400)
        return response
    else:
        # Redireciona de volta para a página de login com um erro
        raise web.HTTPFound('/?error=1')

async def options_handler(request):
    return web.Response(headers=CORS_HEADERS)

async def start_dashboard(bot=None):
    global bot_instance
    bot_instance = bot
    app = web.Application()
    app.add_routes(routes)
    app.router.add_route('OPTIONS', '/{tail:.*}', options_handler)
    runner = web.AppRunner(app)
    await runner.setup()
    port = int(os.getenv("PORT", 8080))
    site = web.TCPSite(runner, '0.0.0.0', port)
    await site.start()
    print(f"🌐 Dashboard iniciado na porta {port}")

    url = await get_dashboard_url()
    print(f"🔗 URL de Acesso Inicial: {url}")

async def get_dashboard_url():
    global cached_app_id
    base_url = os.getenv("DASHBOARD_URL")
    
    # Prioriza IP local se estiver no Windows (Ambiente de Teste)
    if not base_url and os.name == 'nt':
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            port = os.getenv("PORT", 8080)
            base_url = f"http://{local_ip}:{port}"
        except:
            base_url = "http://localhost:8080"

    if not base_url:
        discloud_token = os.getenv("DISCLOUD_API_KEY")
        
        if discloud_token:
            try:
                async with aiohttp.ClientSession() as session:
                    # Tenta listar todos os apps para encontrar o correto
                    async with session.get("https://api.discloud.app/v2/app", headers={"api-token": discloud_token}) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            if data.get("status") == "ok" and "apps" in data:
                                # Tenta encontrar o app que corresponde aos IDs configurados ou pega o primeiro
                                target_ids = [os.getenv("DISCLOUD_BOT_ID"), os.getenv("BOT_ID")]
                                found_app = None
                                
                                for app in data["apps"]:
                                    if app["id"] in target_ids:
                                        found_app = app["id"]
                                        break
                                
                                if not found_app and data["apps"]:
                                    found_app = data["apps"][0]["id"]
                                
                                if found_app:
                                    cached_app_id = found_app
                                    # Busca detalhes para pegar o subdomínio
                                    async with session.get(f"https://api.discloud.app/v2/app/{found_app}", headers={"api-token": discloud_token}) as detail_resp:
                                        if detail_resp.status == 200:
                                            d_data = await detail_resp.json()
                                            if d_data.get("status") == "ok" and "app" in d_data:
                                                sub = d_data["app"].get("subdomain")
                                                if sub:
                                                    base_url = f"https://{sub}.discloud.app"
                                                    print(f"✅ Subdomínio detectado: {sub}")
            except Exception as e:
                print(f"Erro ao detectar URL da Discloud: {e}")

    # Fallback para ler o ID direto do arquivo de configuração se a API falhar
    if not base_url:
        try:
            if os.path.exists("discloud.config"):
                with open("discloud.config", "r", encoding="utf-8") as f:
                    for line in f:
                        if line.startswith("ID="):
                            conf_id = line.strip().split("=")[1]
                            base_url = f"https://{conf_id}.discloud.app"
                            break
        except:
            pass

    # Detecção específica para Koyeb
    if not base_url and os.getenv("KOYEB_APP_NAME"):
        # Tenta usar a URL configurada manualmente ou estima
        if os.getenv("DASHBOARD_URL"):
            base_url = os.getenv("DASHBOARD_URL")
        else:
            app_name = os.getenv("KOYEB_APP_NAME")
            base_url = f"https://{app_name}.koyeb.app"
            print(f"⚠️ Koyeb detectado. URL estimada: {base_url}. Recomendado configurar DASHBOARD_URL nas variáveis de ambiente.")

    # Tenta detectar IP público (Oracle Cloud/VPS) se nenhuma URL foi encontrada até agora
    if not base_url:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('https://api64.ipify.org', timeout=2) as resp:
                    if resp.status == 200:
                        public_ip = await resp.text()
                        port = os.getenv("PORT", 8080)
                        base_url = f"http://{public_ip}:{port}"
                        print(f"✅ IP Público detectado: {public_ip}")
        except:
            pass

    if not base_url:
        app_id = os.getenv("BOT_ID")
        if app_id:
            base_url = f"https://{app_id}.discloud.app"
        else:
            base_url = "http://localhost:8080"
        
    return base_url.rstrip('/')

async def create_github_bridge(interaction):
    """
    Gera o HTML do painel com URLs absolutas e faz upload para o GitHub.
    """
    gtoken = os.getenv("GTOKEN")
    repo_name = os.getenv("FIST_REPO") # Usando o mesmo repo de fists ou outro configurado
    
    if not gtoken or not repo_name:
        return "Erro: GTOKEN ou FIST_REPO não configurados no .env"

    # Gera URL base e Token
    dashboard_url = await get_dashboard_url()
    base_url = dashboard_url.split("?")[0]

    # Gera HTML Standalone
    html_content = f"""
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirecionando...</title>
    <meta http-equiv="refresh" content="0; url={base_url}">
    <script>
        window.location.href = "{base_url}";
    </script>
    <style>
        body {{ background-color: #0f172a; color: #f1f5f9; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }}
        .loader {{ border: 4px solid #1e293b; border-top: 4px solid #eab308; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; }}
        @keyframes spin {{ 0% {{ transform: rotate(0deg); }} 100% {{ transform: rotate(360deg); }} }}
    </style>
</head>
<body>
    <div style="text-align: center;"><div class="loader" style="margin: 0 auto 20px;"></div><p>Conectando ao Painel de Controle...</p><p style="font-size: 12px; color: #94a3b8;">Se não for redirecionado, <a href="{base_url}" style="color: #eab308;">clique aqui</a>.</p></div>
</body>
</html>
"""
    
    try:
        github = Github(gtoken)
        repo = github.get_repo(repo_name)
        
        target_branch = "gh-pages"
        try:
            repo.get_branch(target_branch)
        except:
            target_branch = repo.default_branch

        file_path = "index.html"
        
        try:
            contents = repo.get_contents(file_path, ref=target_branch)
            repo.update_file(file_path, "chore: Update dashboard bridge", html_content, contents.sha, branch=target_branch)
        except Exception:
            repo.create_file(file_path, "feat: Create dashboard bridge", html_content, branch=target_branch)
            
        return f"https://{repo.owner.login}.github.io/{repo.name}/"
        
    except Exception as e:
        return f"Erro ao criar ponte no GitHub: {e}"