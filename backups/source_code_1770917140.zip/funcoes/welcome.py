import discord
from discord.ext import commands
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from io import BytesIO
import requests
import json
import os
import datetime
from settings.ids import ChannelIDs
from settings import imagenspainel
import asyncio

class Welcome(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.history_file = "user_history.json"
        self.ensure_file()

    def ensure_file(self):
        if not os.path.exists(self.history_file):
            with open(self.history_file, "w") as f:
                json.dump({}, f)

    def get_history(self, user_id):
        with open(self.history_file, "r") as f:
            data = json.load(f)
        return data.get(str(user_id), {"leaves": 0, "joins": 0})

    def update_history(self, user_id, type):
        with open(self.history_file, "r") as f:
            data = json.load(f)
        
        uid = str(user_id)
        if uid not in data:
            data[uid] = {"leaves": 0, "joins": 0}
        
        data[uid][type] += 1
        
        with open(self.history_file, "w") as f:
            json.dump(data, f, indent=4)
        return data[uid]

    def get_user_locale(self, user_id):
        if os.path.exists("user_locales.json"):
            with open("user_locales.json", "r") as f:
                data = json.load(f)
            return data.get(str(user_id), "N/A")
        return "N/A"

    def generate_welcome_image(self, avatar_url, name, count, locale_str):
        width, height = 1024, 500
        background_color = (47, 49, 54)
        
        try:
            # Tenta usar o banner do painel como fundo
            response = requests.get(imagenspainel.privacy_banner)
            background = Image.open(BytesIO(response.content)).convert("RGBA")
            background = background.resize((width, height))
            
            # Logo da Privacy atrás
            try:
                response_logo = requests.get(imagenspainel.poste_seus_mods)
                logo = Image.open(BytesIO(response_logo.content)).convert("RGBA")
                
                # Redimensionar logo
                logo_h = int(height * 0.7)
                ratio = logo_h / logo.height
                logo_w = int(logo.width * ratio)
                logo = logo.resize((logo_w, logo_h), Image.Resampling.LANCZOS)
                
                # Centralizar
                logo_x = (width - logo_w) // 2
                logo_y = (height - logo_h) // 2
                
                # Colar logo no fundo
                background.paste(logo, (logo_x, logo_y), logo)
            except Exception as e:
                print(f"Erro ao adicionar logo: {e}")

            # Blur no fundo (Banner + Logo)
            background = background.filter(ImageFilter.GaussianBlur(radius=5))
            
            # Overlay escuro
            overlay = Image.new("RGBA", (width, height), (0, 0, 0, 100))
            background = Image.alpha_composite(background, overlay)
        except:
            background = Image.new("RGBA", (width, height), background_color)

        draw = ImageDraw.Draw(background)

        # Card central (Retângulo arredondado)
        card_w, card_h = 850, 400
        card_x, card_y = (width - card_w) // 2, (height - card_h) // 2
        draw.rounded_rectangle((card_x, card_y, card_x + card_w, card_y + card_h), radius=30, fill=(30, 30, 30, 180))

        # Avatar
        avatar_size = 180
        try:
            response = requests.get(avatar_url)
            avatar_raw = Image.open(BytesIO(response.content)).convert("RGBA")
            avatar_raw = avatar_raw.resize((avatar_size, avatar_size), Image.Resampling.LANCZOS)
            
            mask = Image.new("L", (avatar_size, avatar_size), 0)
            draw_mask = ImageDraw.Draw(mask)
            draw_mask.ellipse((0, 0, avatar_size, avatar_size), fill=255)
            
            # Borda Dourada (Tema Privacy)
            avatar_img = Image.new("RGBA", (avatar_size + 8, avatar_size + 8), (0,0,0,0))
            draw_av = ImageDraw.Draw(avatar_img)
            draw_av.ellipse((0, 0, avatar_size + 8, avatar_size + 8), fill=(230, 196, 0, 255)) # Gold
            avatar_img.paste(avatar_raw, (4, 4), mask)
            
            # Colar Avatar
            av_x = (width - (avatar_size + 8)) // 2
            av_y = card_y + 40
            background.paste(avatar_img, (av_x, av_y), avatar_img)
        except Exception as e:
            print(f"Erro ao processar avatar: {e}")

        # Texto
        try:
            font_large = ImageFont.truetype("arial.ttf", 55)
            font_small = ImageFont.truetype("arial.ttf", 35)
            font_mini = ImageFont.truetype("arial.ttf", 25)
        except:
            font_large = ImageFont.load_default()
            font_small = ImageFont.load_default()
            font_mini = ImageFont.load_default()

        final_avatar_y = card_y + 40
        final_text_y = final_avatar_y + avatar_size + 20

        # Bem vindo
        text_welcome = "BEM VINDO(A) AO SERVIDOR"
        bbox2 = draw.textbbox((0, 0), text_welcome, font=font_small)
        text_w2 = bbox2[2] - bbox2[0]
        draw.text(((width - text_w2) / 2, final_text_y), text_welcome, font=font_small, fill=(200, 200, 200, 255))

        # Nome
        text_name = str(name).upper()
        bbox = draw.textbbox((0, 0), text_name, font=font_large)
        text_w = bbox[2] - bbox[0]
        draw.text(((width - text_w) / 2, final_text_y + 50), text_name, font=font_large, fill=(230, 196, 0, 255))
        
        # Info (Membro # + Idioma)
        info_text = f"Membro #{count}"
        if locale_str != "N/A":
            info_text += f" • {locale_str}"
        bbox3 = draw.textbbox((0, 0), info_text, font=font_mini)
        text_w3 = bbox3[2] - bbox3[0]
        draw.text(((width - text_w3) / 2, final_text_y + 120), info_text, font=font_mini, fill=(150, 150, 150, 255))
            
        output = BytesIO()
        background.save(output, format="PNG")
        output.seek(0)
        return output

    @commands.Cog.listener()
    async def on_member_join(self, member):
        history = self.update_history(member.id, "joins")
        locale = self.get_user_locale(member.id)
        channel = member.guild.get_channel(ChannelIDs.WELCOME)
        
        if channel:
            avatar_url = member.avatar.url if member.avatar else member.default_avatar.url
            name = member.name
            count = member.guild.member_count
            
            loop = asyncio.get_running_loop()
            file_img = await loop.run_in_executor(None, self.generate_welcome_image, avatar_url, name, count, locale)
            
            file = discord.File(file_img, filename="welcome.png")
            embed = discord.Embed(title=f"Bem-vindo(a) ao {member.guild.name}!", description=f"Olá {member.mention}, seja muito bem-vindo(a)!\nVocê é o membro nº **{member.guild.member_count}**.", color=0x2F3136, timestamp=datetime.datetime.now())
            if member.guild.icon: embed.set_thumbnail(url=member.guild.icon.url)
            embed.set_image(url="attachment://welcome.png")
            embed.add_field(name="👤 Perfil", value=f"**User:** {member.name}\n**ID:** {member.id}", inline=True)
            embed.add_field(name="📅 Conta Criada", value=f"{member.created_at.strftime('%d/%m/%Y')}", inline=True)
            embed.add_field(name="🔄 Histórico", value=f"Entrou: {history['joins']}x | Saiu: {history['leaves']}x", inline=False)
            if locale != "N/A":
                embed.add_field(name="🌐 Idioma Detectado", value=f"`{locale}`", inline=True)
            embed.set_footer(text="Privacy Mods • Sistema de Boas Vindas", icon_url=self.bot.user.avatar.url if self.bot.user.avatar else None)
            await channel.send(files=[file], embed=embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        history = self.update_history(member.id, "leaves")
        channel = member.guild.get_channel(ChannelIDs.EXIT_LOGS)
        if channel:
            embed = discord.Embed(title="📤 Membro Saiu", description=f"O usuário **{member.name}** deixou o servidor.", color=0xFF0000, timestamp=datetime.datetime.now())
            if member.avatar: embed.set_thumbnail(url=member.avatar.url)
            embed.add_field(name="👤 Informações", value=f"**Nome:** {member.name}\n**ID:** {member.id}", inline=False)
            embed.add_field(name="📊 Estatísticas", value=f"**Entrou:** {history['joins']} vezes\n**Saiu:** {history['leaves']} vezes", inline=False)
            embed.set_footer(text=f"ID do Usuário: {member.id}")
            await channel.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Welcome(bot))