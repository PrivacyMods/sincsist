import discord
from discord import app_commands
from funcoes import components, ticket, embedcreator, hub, youtube, dashboard
from settings.check import Bot
from settings import emojis
from settings.ids import CategoryIDs, ChannelIDs, MessageIDs, UserIDs, RoleIDs, GithubConfig
from dispie import ModalInput
from github import Github, UnknownObjectException
from dotenv import load_dotenv
import json
import os
import zipfile
import re
import sys
import io
import psutil
import time
import datetime
load_dotenv(override=True)


class Fist(app_commands.Group):

    @app_commands.command(description="Crie fists quadradas e redondas (estática)")
    @app_commands.describe(imagem="Imagem que deseja criar a fist (png, jpg ou jpeg)")
    async def estaticas(self, interaction: discord.Interaction, imagem: discord.Attachment):
        ext = os.path.splitext(imagem.filename)[1].lower()
        if ext == ".gif":
            await interaction.response.send_message("Com este comando você só consegue fazer fists estaticas.\nTente: </fist animadas:1204240498802302996>", ephemeral=True)
        elif ext in [".png", ".jpg", ".jpeg"]:
            ver = "nova"
            await components.static(interaction, imagem, ver)

        else:
            await interaction.response.send_message(f"{interaction.user.mention} |Upe uma imagem em: png, jpg ou jpeg.",
                                                    ephemeral=True)

    @app_commands.command(description="Crie fists quadradas e redondas (animada)")
    @app_commands.describe(imagem="Imagem que deseja criar a fist (apenas GIFs)")
    async def animadas(self, interaction: discord.Interaction, imagem: discord.Attachment):
        ext = os.path.splitext(imagem.filename)[1].lower()
        if ext == ".gif":
            try:
                ver = "nova"
                await components.animated(interaction, imagem, ver)
            except:
                try:
                    await interaction.edit_original_response(
                        content="Houve um erro com essa sua imagem.\n**Recomendado** trocar a imagem.", embed=None)
                except:
                    try:
                        await interaction.response.edit_message(
                            content="Houve um erro com essa sua imagem.\n**Recomendado** trocar a imagem.", embed=None)
                    except:
                        print("Fist estatica nao conseguiu editar a mensagem (erro)")

        elif ext in [".png", ".jpg", ".jpeg"]:
            await interaction.response.send_message(
                "Com este comando você só consegue fazer fists animadas.\nTente: </fist estaticas:1204240498802302996>",
                ephemeral=True)
        else:
            await interaction.response.send_message(f"{interaction.user.mention} | Upe um gif.", ephemeral=True)


class Discord(app_commands.Group):

    @app_commands.command(description="Obtenha o link de nosso discord.")
    async def link(self, interaction: discord.Interaction):
        await interaction.response.send_message(
            f"**LINK DISCORD PRIVACY:**\nㅤ{emojis.privacy}・https://discord.gg/UDKjp4gfay",
            ephemeral=True)


class Say(app_commands.Group):
    com = app_commands.Group(name="com", description="Teste")

    @app_commands.command(description="Comando say normal")
    @app_commands.describe(mensagem='Mensagem que será enviada. (use "\\n" para saltar uma linha)',
                           chat="Canal que será enviado a mensagem.",
                           anexo="Anexo que será enviado junto com a mensagem.")
    async def normal(self, interaction: discord.Interaction, mensagem: str, chat: discord.TextChannel,
                     anexo: discord.Attachment = None):
        mensagem_final = mensagem.replace("\\n", "\n")

        member = interaction.user
        has_admin = False

        for role in member.roles:
            if role.permissions.administrator:
                has_admin = True
                break

        if has_admin:
            ver = False
            if anexo is not None:
                if anexo.size > 25 * 1024 * 1024:
                    await interaction.response.send_message(
                        "**Sua mensagem não foi enviada**\nㅤSua mensagem não foi enviada por seu arquivo exceder o tamanho max de 25 mb.",
                        ephemeral=True)
                    return
                else:
                    await components.CriarSay(interaction, mensagem_final, chat, anexo, ver)
            else:
                anexo = None
                await components.CriarSay(interaction, mensagem_final, chat, anexo, ver)
        else:
            await interaction.response.send_message("Comando rêstrito para admins.", ephemeral=True)

    @com.command(description="Comando say com embed")
    async def embed(self, interaction: discord.Interaction):
        member = interaction.user
        has_admin = False

        for role in member.roles:
            if role.permissions.administrator:
                has_admin = True
                break

        if has_admin:
            await embedcreator.CriarEmbed(interaction)

        else:
            await interaction.response.send_message("Comando rêstrito para admins.", ephemeral=True)


class CloseTicket(app_commands.Group):

    @app_commands.command(description="Fechar ticket (admins)")
    async def ticket(self, interaction: discord.Interaction):
        member = interaction.user
        has_admin = False

        for role in member.roles:
            if role.permissions.administrator:
                has_admin = True
                break

        if has_admin:
            categoria = interaction.guild.get_channel(CategoryIDs.TICKET_CLOSE)
            if interaction.channel.category == categoria:
                await ticket.trash(interaction)
            else:
                await interaction.response.send_message("Este comando só pode ser utilizado em algum ticket aberto.",
                                                        ephemeral=True)
        else:
            await interaction.response.send_message("Comando rêstrito para admins.", ephemeral=True)


@Bot.tree.context_menu(name="Editar (admins)")
async def edit(interaction: discord.Interaction, message: discord.Message):
    member = interaction.user
    has_admin = False

    for role in member.roles:
        if role.permissions.administrator:
            has_admin = True
            break

    if has_admin:
        if message.author.id == Bot.application_id:
            modal = ModalInput(title="EDITE A MENSAGEM ABAIXO")
            modal.add_item(
                discord.ui.TextInput(
                    label="MENSAGEM",
                    default=str(message.content),
                    placeholder="Modifique a mensagem",
                    required=False,
                    max_length=4000,
                    style=discord.TextStyle.paragraph
                )
            )
            await interaction.response.send_modal(modal)
            await modal.wait()
            try:
                await message.edit(content=str(modal.children[0]))
            except:
                await message.delete()
        else:
            await interaction.response.send_message("Só posso editar minhas mensagens.", ephemeral=True)

    else:
        await interaction.response.send_message("Apenas admins tem essa permissão!", ephemeral=True)


@Bot.tree.context_menu(name="Copiar JSON do Embed (admins)")
async def CopiarJSON(interaction: discord.Interaction, message: discord.Message):
    member = interaction.user
    has_admin = False

    for role in member.roles:
        if role.permissions.administrator:
            has_admin = True
            break

    if has_admin:
        if message.embeds:
            embed_fields = []
            n = 0
            for embed in message.embeds:
                n += 1
                try:
                    embed_data = embed.to_dict()
                    json_data = json.dumps(embed_data, indent=4)

                    embed_fields.append((f"Embed {n}", f"```json\n{json_data}```"))
                except json.JSONDecodeError:
                    await interaction.response.send_message(f"O JSON no embed com ID {embed.id} não é válido.",
                                                            ephemeral=True)

            if embed_fields:
                for field_name, field_value in embed_fields:
                    embed = discord.Embed(title=field_name, description=field_value)
                    try:
                        await interaction.response.send_message(embed=embed, ephemeral=True)
                    except:
                        await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message("Nenhum embed encontrado na mensagem.", ephemeral=True)
        else:
            await interaction.response.send_message("Nenhum embed encontrado na mensagem.", ephemeral=True)
    else:
        await interaction.response.send_message(f"Apenas admins podem usar essa função.", ephemeral=True)


@Bot.tree.context_menu(name="Editar Embed (admins)")
async def EditarEmbed(interaction: discord.Interaction, message: discord.Message):
    member = interaction.user
    has_admin = False

    for role in member.roles:
        if role.permissions.administrator:
            has_admin = True
            break

    if has_admin:
        if message.author.id != Bot.application_id:
            await interaction.response.send_message("Só posso editar mensagens que foram enviadas por mim.",
                                                    ephemeral=True)

        else:
            if message.embeds:
                embeds = []
                for embed in message.embeds:
                    embeds.append(embed)

                msg = message.content
                msgedit = message.edit
                await embedcreator.EditarEmbedPostado(interaction, msg, embeds, msgedit)
            else:
                await interaction.response.send_message(
                    'Essa mensagem minha não contém embeds, tente usar a função "Editar (admins)".', ephemeral=True)
    else:
        await interaction.response.send_message(f"Apenas admins podem usar essa função.", ephemeral=True)


@Bot.tree.context_menu(name="Delete (post)")
async def deleteMessage(interaction: discord.Interaction, message: discord.Message):
    member = interaction.user
    has_admin = False
    postadores = False
    postador = interaction.guild.get_role(RoleIDs.POSTADOR)
    id = str(interaction.user.id)

    for role in member.roles:
        if role.permissions.administrator:
            has_admin = True
            break

    if postador in member.roles:
        postadores = True

    if has_admin or postadores:
        if len(message.embeds) > 0:
            embed = message.embeds[0]
            if embed.footer:
                if re.match("^[0-9]+$", embed.footer.text):
                    if id in embed.footer.text:
                        async for msg in message.channel.history(after=message, limit=1):
                            if len(msg.attachments) > 0:
                                await msg.delete()
                                break
                        await message.delete()
                        await interaction.response.send_message(f"Apaguei seu post <@{id}>!", ephemeral=True)
                        return
                    else:
                        if has_admin:
                            async for msg in message.channel.history(after=message, limit=1):
                                if len(msg.attachments) > 0:
                                    await msg.delete()
                                    break
                            await message.delete()
                            await interaction.response.send_message(
                                f"<@{id}> | Apaguei o post do usuário <@{str(embed.footer.text)}> para você.",
                                ephemeral=True)
                            return
                        else:
                            await interaction.response.send_message(
                                f"Posts que não são seu só podem ser apagados pelos admins.", ephemeral=True)
                else:
                    await interaction.response.send_message("Esse embed não é um embed de posts.", ephemeral=True)
            else:
                await interaction.response.send_message("Esse embed não é um embed de posts.", ephemeral=True)

        elif f"ㅤ・By **[{interaction.user.name}](https://discord.com/users/{id})**" in message.content:
            async for msg in message.channel.history(after=message, limit=1):
                if len(msg.attachments) > 0:
                    await msg.delete()
                    break
            await message.delete()
            await interaction.response.send_message(f"Apaguei seu post <@{id}>!", ephemeral=True)
            return
        else:
            if has_admin:
                match = re.search(r'https://discord\.com/users/(\d+)', message.content)
                if match:
                    async for msg in message.channel.history(after=message, limit=1):
                        if len(msg.attachments) > 0:
                            await msg.delete()
                            break
                    await message.delete()
                    await interaction.response.send_message(
                        f"<@{id}> | Apaguei o post do usuário <@{str(match.group(1))}> para você.", ephemeral=True)
                    return

    else:
        await interaction.response.send_message(f"Apenas admins e os {postador.mention}es podem usar essa função.",
                                                ephemeral=True)


class Adicionar(app_commands.Group):
    @app_commands.command(description="Edita os divisores para publicação de mods. (admins)")
    async def divisores(self, interaction: discord.Interaction):

        has_admin = False
        for role in interaction.user.roles:
            if role.permissions.administrator:
                has_admin = True
                break
        if has_admin:
            await hub.adcdivisor(interaction)
        else:
            await interaction.response.send_message("Comando rêstrito para admins.", ephemeral=True)

class Git(app_commands.Group):
    @app_commands.command(description="Configura o repositório do GitHub para backup de fists. (Owner only)")
    @app_commands.describe(repositorio="O nome do repositório no formato 'usuario/repo'.")
    async def set(self, interaction: discord.Interaction, repositorio: str):
        if interaction.user.id != UserIDs.DEV_OCEANS:
            await interaction.response.send_message("Apenas o desenvolvedor pode utilizar este comando.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        gtoken = os.getenv("GTOKEN")
        if not gtoken:
            await interaction.followup.send("❌ Token do GitHub (GTOKEN) não encontrado no arquivo .env.")
            return

        try:
            github = Github(gtoken)
            repo = github.get_repo(repositorio)
        except Exception as e:
            await interaction.followup.send(f"❌ Erro ao acessar o repositório `{repositorio}`: {e}")
            return

        paths = [
            "fists/zips/.gitkeep",
            "fists/previews/.gitkeep",
            "fists/raw_static/.gitkeep",
        ]
        
        report = [f"✅ Repositório `{repo.full_name}` encontrado e acessível."]
        
        for path in paths:
            try:
                repo.get_contents(path)
                report.append(f"➡️ Diretório `{os.path.dirname(path)}` já existe.")
            except UnknownObjectException:
                try:
                    repo.create_file(
                        path=path,
                        message=f"feat: Inicializa diretório {os.path.dirname(path)}",
                        content="",
                        branch=repo.default_branch
                    )
                    report.append(f"✅ Diretório `{os.path.dirname(path)}` criado com sucesso.")
                except Exception as e:
                    report.append(f"❌ Erro ao criar diretório `{os.path.dirname(path)}`: {e}")
            except Exception as e:
                report.append(f"❌ Erro ao verificar diretório `{os.path.dirname(path)}`: {e}")

        try:
            env_path = ".env"
            if os.path.exists(env_path):
                with open(env_path, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                
                with open(env_path, "w", encoding="utf-8") as f:
                    repo_found, branch_found = False, False
                    for line in lines:
                        if line.strip().startswith("FIST_REPO"):
                            f.write(f'FIST_REPO = "{repositorio}"\n'); repo_found = True
                        elif line.strip().startswith("FIST_REPO_BRANCH"):
                            f.write(f'FIST_REPO_BRANCH = "{repo.default_branch}"\n'); branch_found = True
                        else: f.write(line)
                    if not repo_found: f.write(f'\nFIST_REPO = "{repositorio}"\n')
                    if not branch_found: f.write(f'FIST_REPO_BRANCH = "{repo.default_branch}"\n')
                report.append("✅ Arquivo .env atualizado com `FIST_REPO` e `FIST_REPO_BRANCH`.")
                load_dotenv(override=True)
        except Exception as e:
            report.append(f"❌ Erro ao salvar no .env: {e}")

        await interaction.followup.send("**Relatório de Configuração do GitHub:**\n" + "\n".join(report))

    @app_commands.command(description="Configura um repositório exclusivo para o código do bot. (Owner only)")
    @app_commands.describe(repositorio="O nome do repositório no formato 'usuario/repo'.")
    async def set_code(self, interaction: discord.Interaction, repositorio: str):
        if interaction.user.id != UserIDs.DEV_OCEANS:
            await interaction.response.send_message("Apenas o desenvolvedor pode utilizar este comando.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)

        gtoken = os.getenv("GTOKEN")
        if not gtoken:
            await interaction.followup.send("❌ Token do GitHub (GTOKEN) não encontrado no arquivo .env.")
            return

        try:
            github = Github(gtoken)
            repo = github.get_repo(repositorio)
        except Exception as e:
            await interaction.followup.send(f"❌ Erro ao acessar o repositório `{repositorio}`: {e}")
            return

        try:
            env_path = ".env"
            content = ""
            if os.path.exists(env_path):
                with open(env_path, "r", encoding="utf-8") as f:
                    content = f.read()
            
            if "BACKUP_REPO" in content:
                content = re.sub(r'BACKUP_REPO\s*=\s*".*"', f'BACKUP_REPO = "{repositorio}"', content)
            else:
                content += f'\nBACKUP_REPO = "{repositorio}"\n'
                
            with open(env_path, "w", encoding="utf-8") as f:
                f.write(content)
            
            os.environ["BACKUP_REPO"] = repositorio
            await interaction.followup.send(f"✅ Repositório de código configurado para: `{repositorio}`")
        except Exception as e:
            await interaction.followup.send(f"❌ Erro ao salvar no .env: {e}")

    @app_commands.command(description="Faz backup do código fonte do bot para o GitHub. (Owner only)")
    async def backup(self, interaction: discord.Interaction):
        if interaction.user.id != UserIDs.DEV_OCEANS:
            await interaction.response.send_message("Apenas o desenvolvedor pode utilizar este comando.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)
        
        gtoken = os.getenv("GTOKEN")
        repo_name = os.getenv("BACKUP_REPO") or os.getenv("FIST_REPO")
        
        if not gtoken or not repo_name:
            await interaction.followup.send("❌ GitHub não configurado. Use `/git set` (fists) ou `/git set_code` (código) primeiro.")
            return

        try:
            buffer = io.BytesIO()
            with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
                for root, dirs, files in os.walk("."):
                    dirs[:] = [d for d in dirs if d not in ["venv", "__pycache__", ".git", ".idea"]]
                    for file in files:
                        if file in [".env", "discloud.config", "session.token"]: continue
                        if file.endswith(".pyc"): continue
                        file_path = os.path.join(root, file)
                        zip_file.write(file_path, os.path.relpath(file_path, "."))
            
            buffer.seek(0)
            zip_content = buffer.getvalue()
            timestamp = int(time.time())
            file_name = f"backups/source_code_{timestamp}.zip"
            
            github = Github(gtoken)
            repo = github.get_repo(repo_name)
            repo.create_file(path=file_name, message=f"chore: Backup do código fonte {timestamp}", content=zip_content, branch=repo.default_branch)
            
            await interaction.followup.send(f"✅ Backup do código realizado com sucesso!\nArquivo: `{file_name}`")
        except Exception as e:
            await interaction.followup.send(f"❌ Erro ao fazer backup: {e}")

class EditCategoriesModal(discord.ui.Modal, title="Editar Categorias"):
    ids = discord.ui.TextInput(
        label="IDs das Categorias", 
        placeholder="Separe por vírgula (ex: 123456, 789012)", 
        style=discord.TextStyle.paragraph, 
        required=False
    )

    def __init__(self):
        super().__init__()
        self.ids.default = ", ".join(map(str, CategoryIDs.POSTS))

    async def on_submit(self, interaction: discord.Interaction):
        new_ids_str = self.ids.value
        new_ids = []
        if new_ids_str:
            for x in new_ids_str.split(","):
                if x.strip().isdigit():
                    new_ids.append(int(x.strip()))
        
        # Atualiza a memória (in-place para refletir em outros módulos)
        CategoryIDs.POSTS.clear()
        CategoryIDs.POSTS.extend(new_ids)
        
        # Atualiza o arquivo .env
        try:
            env_path = ".env"
            if os.path.exists(env_path):
                with open(env_path, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                
                with open(env_path, "w", encoding="utf-8") as f:
                    found = False
                    for line in lines:
                        if line.strip().startswith("CATEGORY_IDS_POSTS"):
                            f.write(f'CATEGORY_IDS_POSTS = "{", ".join(map(str, new_ids))}"\n')
                            found = True
                        else:
                            f.write(line)
                    if not found:
                        f.write(f'\nCATEGORY_IDS_POSTS = "{", ".join(map(str, new_ids))}"\n')
            
            await interaction.response.send_message(f"Categorias atualizadas com sucesso! Novos IDs: {new_ids}", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"Categorias atualizadas na memória, mas erro ao salvar no .env: {e}", ephemeral=True)

class EditCategoriesView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Editar Categorias", style=discord.ButtonStyle.primary, emoji=emojis.edit)
    async def edit(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != UserIDs.DEV_OCEANS:
            await interaction.response.send_message("Apenas o dono do bot pode editar as categorias.", ephemeral=True)
            return
        await interaction.response.send_modal(EditCategoriesModal())

    @discord.ui.button(label="Adicionar Categoria Atual", style=discord.ButtonStyle.success, emoji=emojis.plus)
    async def add_current(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != UserIDs.DEV_OCEANS:
            await interaction.response.send_message("Apenas o dono do bot pode editar as categorias.", ephemeral=True)
            return
        
        channel = interaction.channel
        category = getattr(channel, 'category', None)
        
        if not category and hasattr(channel, 'parent') and hasattr(channel.parent, 'category'):
             category = channel.parent.category

        if not category:
             await interaction.response.send_message("Este canal não parece estar em uma categoria válida.", ephemeral=True)
             return
        
        category_id = category.id
        
        if category_id in CategoryIDs.POSTS:
            await interaction.response.send_message(f"A categoria **{category.name}** (`{category_id}`) já está na lista.", ephemeral=True)
            return

        CategoryIDs.POSTS.append(category_id)
        new_ids = CategoryIDs.POSTS

        try:
            env_path = ".env"
            if os.path.exists(env_path):
                with open(env_path, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                
                with open(env_path, "w", encoding="utf-8") as f:
                    found = False
                    for line in lines:
                        if line.strip().startswith("CATEGORY_IDS_POSTS"):
                            f.write(f'CATEGORY_IDS_POSTS = "{", ".join(map(str, new_ids))}"\n')
                            found = True
                        else:
                            f.write(line)
                    if not found:
                        f.write(f'\nCATEGORY_IDS_POSTS = "{", ".join(map(str, new_ids))}"\n')
            
            await interaction.response.send_message(f"Categoria **{category.name}** (`{category_id}`) adicionada com sucesso!", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"Categoria adicionada na memória, mas erro ao salvar no .env: {e}", ephemeral=True)

@Bot.tree.command(description="Altera o idioma de tradução do ticket atual")
@app_commands.describe(idioma="O código do novo idioma (ex: en, pt, es, fr)")
async def setlanguage(interaction: discord.Interaction, idioma: str):
    if interaction.channel.category_id != CategoryIDs.TICKET_OPEN:
        await interaction.response.send_message("Este comando só pode ser usado em tickets abertos.", ephemeral=True)
        return

    topic = interaction.channel.topic
    if not topic or "Traduzir: Sim" not in topic:
        await interaction.response.send_message("Este ticket não tem a tradução ativa ou não é um ticket válido.", ephemeral=True)
        return

    new_topic = re.sub(r"(Traduzir: Sim, )(\w+)", f"\\g<1>{idioma}", topic)
    
    if new_topic != topic:
        await interaction.channel.edit(topic=new_topic)
        await interaction.response.send_message(f"Idioma do ticket alterado para `{idioma}`.", ephemeral=True)
    else:
        await interaction.response.send_message("Não foi possível alterar o idioma. Verifique se o formato do tópico está correto.", ephemeral=True)

@Bot.tree.command(description="Verifica e configura as categorias de posts")
async def check_categories(interaction: discord.Interaction):
    is_owner = interaction.user.id == UserIDs.DEV_OCEANS
    is_admin = False
    for role in interaction.user.roles:
        if role.permissions.administrator:
            is_admin = True
            break
            
    if not is_admin and not is_owner:
        await interaction.response.send_message("Apenas administradores podem usar este comando.", ephemeral=True)
        return

    guild = interaction.guild
    configured_ids = CategoryIDs.POSTS
    description = ""
    
    if not configured_ids:
        description = "⚠️ Nenhuma categoria configurada."
    else:
        for cat_id in configured_ids:
            channel = guild.get_channel(cat_id)
            if channel:
                description += f"✅ <#{cat_id}> (`{cat_id}`) - Visível\n"
            else:
                description += f"❌ `{cat_id}` - Não encontrado/Invisível\n"

    embed = discord.Embed(title="Configuração de Categorias de Posts", description=description, color=0x2F3136)
    view = EditCategoriesView() if is_owner else None
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

@Bot.tree.command(description="Limpa mensagens do chat (admins)")
@app_commands.describe(quantidade="Quantidade de mensagens para apagar")
async def limpar(interaction: discord.Interaction, quantidade: int):
    member = interaction.user
    has_admin = False

    for role in member.roles:
        if role.permissions.administrator:
            has_admin = True
            break

    if has_admin:
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=quantidade)
        await interaction.followup.send(f"Apaguei {len(deleted)} mensagens.", ephemeral=True)
    else:
        await interaction.response.send_message("Apenas admins podem usar este comando.", ephemeral=True)

@Bot.tree.command(description="Verifica o status do bot")
async def status(interaction: discord.Interaction):
    process = psutil.Process(os.getpid())
    uptime_seconds = time.time() - process.create_time()
    uptime = str(datetime.timedelta(seconds=int(uptime_seconds)))
    await interaction.response.send_message(f"Olá {interaction.user.mention}, estou online e operante!\n**Tempo Online:** `{uptime}`", ephemeral=True)

@Bot.tree.command(description="Reinicia o processo do bot (Owner only)")
async def restart(interaction: discord.Interaction):
    if interaction.user.id == UserIDs.DEV_OCEANS:
        await interaction.response.send_message("Reiniciando o sistema...", ephemeral=True)
        print("Reiniciando o bot via comando...")
        os.execv(sys.executable, [sys.executable] + sys.argv)
    else:
        await interaction.response.send_message("Apenas o desenvolvedor pode utilizar este comando.", ephemeral=True)

@Bot.tree.command(description="Define manualmente a URL do painel (Owner only)")
@app_commands.describe(url="A URL base do seu painel (ex: https://subdominio.discloud.app)")
async def set_dashboard_url(interaction: discord.Interaction, url: str):
    if interaction.user.id != UserIDs.DEV_OCEANS:
        await interaction.response.send_message("Apenas o desenvolvedor pode utilizar este comando.", ephemeral=True)
        return
    
    url = url.rstrip('/')
    if not url.startswith("http"):
        url = "https://" + url
        
    try:
        env_path = ".env"
        content = ""
        if os.path.exists(env_path):
            with open(env_path, "r", encoding="utf-8") as f:
                content = f.read()
        
        if "DASHBOARD_URL" in content:
            content = re.sub(r'DASHBOARD_URL\s*=\s*".*"', f'DASHBOARD_URL = "{url}"', content)
        else:
            content += f'\nDASHBOARD_URL = "{url}"\n'
            
        with open(env_path, "w", encoding="utf-8") as f:
            f.write(content)
            
        os.environ["DASHBOARD_URL"] = url
        await interaction.response.send_message(f"✅ URL do painel atualizada para: `{url}`\nUse `/painel` para gerar um novo link de acesso.", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"❌ Erro ao salvar URL: {e}", ephemeral=True)

@Bot.tree.command(description="Exibe os logs do console (Owner only)")
async def logs(interaction: discord.Interaction):
    if interaction.user.id == UserIDs.DEV_OCEANS:
        await interaction.response.defer(ephemeral=True)
        content = Bot.log_buffer.getvalue()
        if not content:
            await interaction.followup.send("Log vazio.")
            return
            
        if len(content) > 1900:
            file = discord.File(io.BytesIO(content.encode("utf-8")), filename="log.txt")
            await interaction.followup.send(file=file)
        else:
            await interaction.followup.send(f"```ansi\n{content}\n```")
    else:
        await interaction.response.send_message("Apenas o desenvolvedor pode utilizar este comando.", ephemeral=True)

@Bot.tree.command(description="Verifica e repara arquivos JSON corrompidos (Owner only)")
async def check_json(interaction: discord.Interaction):
    if interaction.user.id == UserIDs.DEV_OCEANS:
        await interaction.response.defer(ephemeral=True)
        
        files_defaults = {
            "message_counts.json": {"totalmsg": 0, "mensagemid": 0},
            "divisores.json": {},
            "last_ticket_number.json": {"last_ticket_number": 0},
            "user_locales.json": {}
        }
        
        report = []
        
        for filename, default_value in files_defaults.items():
            status = "✅ Válido"
            try:
                if os.path.exists(filename):
                    with open(filename, 'r', encoding='utf-8') as f:
                        json.load(f)
                else:
                    status = "⚠️ Ausente (Criado Novo)"
                    with open(filename, 'w', encoding='utf-8') as f:
                        json.dump(default_value, f, indent=4)
            except json.JSONDecodeError:
                status = "❌ Corrompido (Resetado & Backup criado)"
                try:
                    if os.path.exists(f"{filename}.bak"):
                        os.remove(f"{filename}.bak")
                    os.rename(filename, f"{filename}.bak")
                except: pass
                
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(default_value, f, indent=4)
            except Exception as e:
                status = f"🚫 Erro: {str(e)}"
            
            report.append(f"📄 **{filename}**: {status}")
            
        await interaction.followup.send("**Diagnóstico de Arquivos JSON:**\n" + "\n".join(report))
    else:
        await interaction.response.send_message("Apenas o desenvolvedor pode utilizar este comando.", ephemeral=True)

@Bot.tree.command(description="Sincroniza os comandos (Reset e Atualização)")
async def sync(interaction: discord.Interaction):
    if interaction.user.id == UserIDs.DEV_OCEANS:
        await interaction.response.defer(ephemeral=True)
        
        # Limpa comandos globais para evitar duplicatas
        Bot.tree.clear_commands(guild=None)

        # Adiciona os comandos
        Bot.tree.add_command(Fist(name="fist"))
        Bot.tree.add_command(Discord(name="discord"))
        Bot.tree.add_command(Say(name="say"))
        Bot.tree.add_command(CloseTicket(name="fechar"))
        Bot.tree.add_command(Adicionar(name="editar"))
        Bot.tree.add_command(setlanguage)
        Bot.tree.add_command(Git(name="git"))
        
        # Restaurar Context Menus
        Bot.tree.add_command(edit)
        Bot.tree.add_command(CopiarJSON)
        Bot.tree.add_command(EditarEmbed)
        Bot.tree.add_command(deleteMessage)

        # Restaurar comando clear
        Bot.tree.add_command(sync)
        Bot.tree.add_command(clear)
        Bot.tree.add_command(restart)
        Bot.tree.add_command(status)
        Bot.tree.add_command(logs)
        Bot.tree.add_command(check_json)
        Bot.tree.add_command(check_categories)
        Bot.tree.add_command(limpar)
        Bot.tree.add_command(painel_youtube)
        Bot.tree.add_command(setup_channels)
        Bot.tree.add_command(painel)
        Bot.tree.add_command(set_dashboard_url)
        
        await Bot.tree.sync()

        print(f"Comandos globais carregados: {[c.name for c in Bot.tree.get_commands()]}")

        # Limpa comandos da guilda atual para evitar conflitos
        if interaction.guild:
            Bot.tree.clear_commands(guild=interaction.guild)
            await Bot.tree.sync(guild=interaction.guild)

        await interaction.followup.send("Comandos sincronizados globalmente! (Duplicatas locais removidas)")
    else:
        await interaction.response.send_message("Apenas o desenvolvedor pode utilizar este comando.", ephemeral=True)

@Bot.tree.command(description="Limpa todos os comandos registrados (Mantém /sync e /clear)")
async def clear(interaction: discord.Interaction):
    if interaction.user.id == UserIDs.DEV_OCEANS:
        await interaction.response.defer(ephemeral=True)
        
        # Limpa todos os comandos globais
        Bot.tree.clear_commands(guild=None)
        
        # Mantém apenas sync e clear
        Bot.tree.add_command(sync)
        Bot.tree.add_command(clear)
        Bot.tree.add_command(restart)
        Bot.tree.add_command(status)
        Bot.tree.add_command(logs)
        Bot.tree.add_command(check_json)
        Bot.tree.add_command(check_categories)
        Bot.tree.add_command(Git(name="git"))
        Bot.tree.add_command(set_dashboard_url)
        
        await Bot.tree.sync()

        # Limpa comandos da guilda atual
        if interaction.guild:
            Bot.tree.clear_commands(guild=interaction.guild)
            await Bot.tree.sync(guild=interaction.guild)
            
        await interaction.followup.send("Todos os comandos foram removidos, exceto /sync e /clear.")
    else:
        await interaction.response.send_message("Apenas o desenvolvedor pode utilizar este comando.", ephemeral=True)

async def setup(bot):
    bot.tree.add_command(Fist(name="fist"))
    bot.tree.add_command(Discord(name="discord"))
    bot.tree.add_command(Say(name="say"))
    bot.tree.add_command(CloseTicket(name="fechar"))
    bot.tree.add_command(Adicionar(name="editar"))
    bot.tree.add_command(Git(name="git"))

@Bot.tree.command(description="Envia o painel de divulgação do YouTube (admins)")
async def painel_youtube(interaction: discord.Interaction):
    if interaction.user.guild_permissions.administrator:
        await youtube.send_panel(interaction)
    else:
        await interaction.response.send_message("Apenas administradores podem usar este comando.", ephemeral=True)

@Bot.tree.command(description="Configura canais de logs e divulgação (admins)")
@app_commands.describe(
    youtube="Canal para divulgação de vídeos do YouTube",
    welcome="Canal de Boas Vindas",
    exit_logs="Canal de Logs de Saída"
)
async def setup_channels(interaction: discord.Interaction, youtube: discord.TextChannel = None, welcome: discord.TextChannel = None, exit_logs: discord.TextChannel = None):
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message("Apenas administradores podem usar este comando.", ephemeral=True)
        return

    await interaction.response.defer(ephemeral=True)
    
    changes = []
    env_updates = {}

    if youtube:
        ChannelIDs.YOUTUBE_POSTS = youtube.id
        env_updates["CANAL_YOUTUBE_POSTS"] = str(youtube.id)
        changes.append(f"📺 YouTube: {youtube.mention}")
    
    if welcome:
        ChannelIDs.WELCOME = welcome.id
        env_updates["CANAL_WELCOME"] = str(welcome.id)
        changes.append(f"👋 Welcome: {welcome.mention}")

    if exit_logs:
        ChannelIDs.EXIT_LOGS = exit_logs.id
        env_updates["CANAL_EXIT_LOGS"] = str(exit_logs.id)
        changes.append(f"📤 Exit Logs: {exit_logs.mention}")

    if not changes:
        await interaction.followup.send("Nenhum canal foi alterado.")
        return

    # Update .env
    try:
        env_path = ".env"
        if os.path.exists(env_path):
            with open(env_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            
            with open(env_path, "w", encoding="utf-8") as f:
                updated_keys = set()
                for line in lines:
                    key = line.split("=")[0].strip()
                    if key in env_updates:
                        f.write(f'{key} = "{env_updates[key]}"\n')
                        updated_keys.add(key)
                    else:
                        f.write(line)
                
                for key, value in env_updates.items():
                    if key not in updated_keys:
                        f.write(f'\n{key} = "{value}"\n')
        
        await interaction.followup.send(f"✅ Canais atualizados com sucesso!\n" + "\n".join(changes))
    except Exception as e:
        await interaction.followup.send(f"⚠️ Canais atualizados na memória, mas erro ao salvar no .env: {e}")

@Bot.tree.command(description="Gera link para o painel de edição web (Owner only)")
async def painel(interaction: discord.Interaction):
    if interaction.user.id == UserIDs.DEV_OCEANS:
        await interaction.response.defer(ephemeral=True)
        
        bridge_url = await dashboard.create_github_bridge(interaction)
        
        if bridge_url.startswith("http"):
            await interaction.followup.send(f"🔑 **Acesso ao Painel de Controle**\nClique no link abaixo para acessar o painel:\n{bridge_url}\n\n*Este link conecta-se ao seu bot via GitHub Pages.*", ephemeral=True)
        else:
            url = await dashboard.get_dashboard_url()
            await interaction.followup.send(f"⚠️ **Erro na Ponte GitHub:** {bridge_url}\n\n🔑 **Link Direto:**\n{url}", ephemeral=True)
    else:
        await interaction.response.send_message("Apenas o desenvolvedor pode utilizar este comando.", ephemeral=True)
