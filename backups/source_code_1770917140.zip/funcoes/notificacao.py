import discord
from settings import check
from settings import emojis
from settings.ids import ChannelIDs, RoleIDs, ServerIDs, UserIDs
import json
import asyncio
from discord.ext import tasks
import random
import os
import psutil
import platform
import datetime
import time
from dotenv import load_dotenv
from collections import Counter
load_dotenv()

CHANNEL_ANUNCIO = ChannelIDs.ANUNCIO
CHANNEL_FIST = ChannelIDs.FIST
CALL_ID = ChannelIDs.MEMBER_COUNT
SERVER_ID = ServerIDs.GUILD_ID


palavras_chave = ["link do discord", "manda o link do discord", "discord link"]
last_bot_message = None
last_bot_message_fist = None
description = 'Faça sua fist com "</fist estaticas:1132734394906460190>" ou "</fist animadas:1132734394906460190>" para compartilha-la aqui.'
embedf = discord.Embed(description='Faça sua fist com "</fist estaticas:1132734394906460190>" ou "</fist animadas:1132734394906460190>" para compartilha-la aqui.', colour=0x383d42)
add = emojis.add
remove = emojis.remove
pause = emojis.pause
start = emojis.start

class rolermv(discord.ui.Button):
    def __init__(self):
        super().__init__(emoji=emojis.remove, style=discord.ButtonStyle.gray, custom_id="2")

    async def callback(self, interaction: discord.Interaction):
        server = interaction.guild
        role = server.get_role(RoleIDs.POSTADOR)
        if not role in interaction.user.roles:
            await interaction.response.send_message(f"{interaction.user.mention} | Você já não estava recebendo notificações.", ephemeral=True)
        else:
            await interaction.user.remove_roles(role)
            await interaction.response.send_message(f'{interaction.user.mention} | Agora você não irá receber notiicações', ephemeral=True)

class roleadc(discord.ui.Button):
    def __init__(self):
        super().__init__(emoji=emojis.add, style=discord.ButtonStyle.gray, custom_id="1")

    async def callback(self, interaction: discord.Interaction):
        server = interaction.guild
        role = server.get_role(RoleIDs.POSTADOR)
        if not role in interaction.user.roles:
            await interaction.user.add_roles(role)
            await interaction.response.send_message(f"{interaction.user.mention} | Agora você irá receber notiicações.", ephemeral=True)
        else:
            await interaction.response.send_message(f'{interaction.user.mention} | Você já estava recebendo as notificações.', ephemeral=True)

class roleadcc(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

        self.add_item(roleadc())
        self.add_item(rolermv())

async def on_message_channel(message):
    global last_bot_message
    embed = discord.Embed(title="Adiciona/Remove o cargo de Notificação.", colour=0x2F3136)
    if message.author.id == UserIDs.BOT and message.channel.id == CHANNEL_ANUNCIO:
        idcargo = RoleIDs.POSTADOR
        cargo = f"<@&{idcargo}>"
        if cargo in message.content:
            await last_bot_message.delete()
            last_bot_message = await message.channel.send(embed=embed, view=roleadcc())

async def check_last_message(channela):
    global last_bot_message
    embedr = discord.Embed(title="Adiciona/Remove o cargo de Notificação.", colour=0x2F3136)
    async for message in channela.history(limit=1):
        if message.author.id == UserIDs.BOT:
            idcargo = RoleIDs.POSTADOR
            cargo = f"<@&{idcargo}>"
            if cargo in message.content:
                last_bot_message = await channela.send(embed=embedr, view=roleadcc())

            elif len(message.embeds) > 0 and message.embeds[0].title == 'Adiciona/Remove o cargo de Notificação.':
                last_bot_message = message

        break

async def on_message_link_dc(message):
    if message.author == check.Bot.user:
        return

    if message.channel.id == ChannelIDs.HUB:
        return

    mensagem = message.content.lower()

    if any(palavra in mensagem for palavra in palavras_chave):
        resposta = await message.reply(f"**LINK DISCORD PRIVACY:**\nㅤ{emojis.privacy}・https://discord.gg/Q5VarmhsHz")
        if not resposta.pinned and resposta.channel.permissions_for(resposta.guild.me).manage_messages:
            await asyncio.sleep(10)
            try:
                await resposta.delete()
            except discord.NotFound:
                pass

async def on_message_channel_fist(message):
    global last_bot_message_fist
    if message.embeds and message.channel.id == CHANNEL_FIST:
        autor = message.embeds[0].author.name
        if autor == "Privacyᵐᵒᵈˢ":
            if last_bot_message_fist:
                await last_bot_message_fist.delete()
            last_bot_message_fist = await message.channel.send(embed=embedf)

async def check_last_message_fist(channelb):
    global last_bot_message_fist
    async for message in channelb.history(limit=1):
        if len(message.embeds) > 0 and message.embeds[0].description == description:
            last_bot_message_fist = message
        else:
            last_bot_message_fist = await channelb.send(embed=embedf)
            
        break

@tasks.loop(seconds=1)
async def mute_unmute_task(call, server):
    rand_int = random.randint(0, 3)
    mute, deaf = None, None
    
    try:
        if rand_int == 0:
            mute, deaf = True, False
        elif rand_int == 1:
            mute, deaf = False, True
        elif rand_int == 2:
            mute, deaf = True, True

        await call.connect(self_mute=mute, self_deaf=deaf)
    except:
        pass
    
    mute, deaf = not mute, deaf
    await server.change_voice_state(channel=call, self_mute=mute, self_deaf=deaf)

async def membros(*args):
    bot = check.Bot
    server = bot.get_guild(SERVER_ID)
    if server:
        # Conta apenas humanos (exclui bots)
        member_count = len([m for m in server.members if not m.bot])
        activity = discord.Streaming(name=f"{member_count} Membros", url="https://www.twitch.tv/discord")
        await bot.change_presence(activity=activity)
        
        # Atualiza o canal de voz se necessário
        try:
            call = server.get_channel(CALL_ID)
            if call:
                await call.edit(name=f"Total Membros: {server.member_count}")
        except:
            pass

async def bots_count():
    bot = check.Bot
    server = bot.get_guild(ServerIDs.GUILD_ID)
    if server:
        bot_count = len([m for m in server.members if m.bot])
        activity = discord.Streaming(name=f"{bot_count} Bots", url="https://www.twitch.tv/discord")
        await bot.change_presence(activity=activity)

async def staffs():
    bot = check.Bot
    server = bot.get_guild(ServerIDs.GUILD_ID)
    if server:
        role_admin = server.get_role(RoleIDs.ADMIN)
        role_suporte = server.get_role(RoleIDs.SUPORTE)
        
        staff_members = set()
        if role_admin:
            staff_members.update(role_admin.members)
        if role_suporte:
            staff_members.update(role_suporte.members)
            
        online_staff = len([member for member in staff_members if member.status != discord.Status.offline])
        
        activity = discord.Streaming(name=f"{online_staff} Staffs Online", url="https://www.twitch.tv/discord")
        await bot.change_presence(activity=activity)

@tasks.loop(minutes=5)
async def switchpresence():
    options = [membros, bots_count, staffs]
    chosen_task = random.choice(options)
    await chosen_task()

@tasks.loop(seconds=10)
async def status_bot_task():
    bot = check.Bot
    channel_id = ChannelIDs.STATUS_BOT
    if not channel_id:
        return
        
    channel = bot.get_channel(channel_id)
    if not channel:
        return

    # Coletando Informações
    cpu_usage = psutil.cpu_percent()
    memory = psutil.virtual_memory()
    ram_usage_percent = memory.percent
    ram_used_gb = memory.used / (1024 ** 3)
    ram_total_gb = memory.total / (1024 ** 3)
    
    process = psutil.Process(os.getpid())
    bot_ram_mb = process.memory_info().rss / (1024 ** 2)
    
    uptime_seconds = time.time() - process.create_time()
    uptime = str(datetime.timedelta(seconds=int(uptime_seconds)))
    
    ping = round(bot.latency * 1000)
    
    # Contagem de Staffs Online
    server = bot.get_guild(ServerIDs.GUILD_ID)
    online_staff = 0
    if server:
        role_admin = server.get_role(RoleIDs.ADMIN)
        role_suporte = server.get_role(RoleIDs.SUPORTE)
        staff_members = set()
        if role_admin: staff_members.update(role_admin.members)
        if role_suporte: staff_members.update(role_suporte.members)
        online_staff = len([m for m in staff_members if m.status != discord.Status.offline])

    # Contagem de Idiomas
    lang_stats = ""
    if os.path.exists("user_locales.json"):
        try:
            with open("user_locales.json", "r") as f:
                data = json.load(f)
            
            counts = Counter(data.values())
            flags = {"pt-BR": "🇧🇷", "en-US": "🇺🇸", "es-ES": "🇪🇸", "fr": "🇫🇷", "de": "🇩🇪", "it": "🇮🇹", "ja": "🇯🇵", "ru": "🇷🇺", "ko": "🇰🇷", "zh-CN": "🇨🇳"}
            
            top_langs = counts.most_common(5)
            for lang, count in top_langs:
                flag = flags.get(lang, "🏳️")
                lang_stats += f"{flag} **{lang}**: `{count}`\n"
        except: pass

    embed = discord.Embed(title="📊 Status do Bot", color=0x2F3136, timestamp=datetime.datetime.now())
    embed.add_field(name="🖥️ CPU", value=f"`{cpu_usage}%`", inline=True)
    embed.add_field(name="💾 RAM (Sistema)", value=f"`{ram_usage_percent}%` ({ram_used_gb:.2f}GB / {ram_total_gb:.2f}GB)", inline=True)
    embed.add_field(name="🤖 RAM (Bot)", value=f"`{bot_ram_mb:.2f} MB`", inline=True)
    embed.add_field(name="⏱️ Uptime", value=f"`{uptime}`", inline=True)
    embed.add_field(name="📶 Ping", value=f"`{ping}ms`", inline=True)
    embed.add_field(name="🛡️ Staffs Online", value=f"`{online_staff}`", inline=True)
    if lang_stats:
        embed.add_field(name="🌐 Idiomas (Top 5)", value=lang_stats, inline=False)
    embed.add_field(name="🐍 Python", value=f"`{platform.python_version()}`", inline=True)
    embed.add_field(name="🐧 Sistema", value=f"`{platform.system()} {platform.release()}`", inline=True)
    embed.set_footer(text="Atualizado em tempo real")

    try:
        history = [msg async for msg in channel.history(limit=5) if msg.author == bot.user]
        if history:
            await history[0].edit(embed=embed)
        else:
            await channel.purge(limit=10, check=lambda m: m.author == bot.user)
            await channel.send(embed=embed)
    except Exception as e:
        print(f"Erro ao atualizar status: {e}")

def start_status_task():
    if not status_bot_task.is_running():
        status_bot_task.start()
