import discord
from discord.ui import View, Button, Modal, TextInput
from settings import imagenspainel
from settings.ids import RoleIDs, ChannelIDs
import re

class YoutubeModal(Modal, title="Divulgar Vídeo no YouTube"):
    link = TextInput(label="Link do Vídeo", placeholder="https://youtube.com/watch?v=...", required=True)
    descricao = TextInput(label="Descrição do Vídeo", placeholder="Sobre o que é o vídeo?", style=discord.TextStyle.paragraph, required=True, max_length=1000)

    async def on_submit(self, interaction: discord.Interaction):
        link_val = self.link.value
        desc_val = self.descricao.value
        
        # Verifica se é um link do YouTube
        if not re.search(r"(youtube\.com|youtu\.be)", link_val):
            await interaction.response.send_message("❌ **Apenas links do YouTube são permitidos!**", ephemeral=True)
            return

        # Verifica convites de Discord na descrição ou link
        invite_regex = r"(discord\.(gg|io|me|li)|discordapp\.com/invite|discord\.com/invite)"
        if re.search(invite_regex, link_val) or re.search(invite_regex, desc_val):
            role = interaction.guild.get_role(RoleIDs.YOUTUBER)
            if role and role in interaction.user.roles:
                await interaction.user.remove_roles(role)
                await interaction.response.send_message(f"⚠️ **INFRAÇÃO DETECTADA:** Você tentou divulgar um servidor de Discord! Seu cargo {role.mention} foi removido e você recebeu uma advertência.", ephemeral=True)
            else:
                await interaction.response.send_message("🚫 **É proibido divulgar servidores de Discord!**", ephemeral=True)
            return

        # Extrai ID do vídeo para thumbnail
        video_id = None
        match = re.search(r"(?:v=|\/)([0-9A-Za-z_-]{11})", link_val)
        if match:
            video_id = match.group(1)

        # Envia para o canal de divulgação
        channel = interaction.guild.get_channel(ChannelIDs.YOUTUBE_POSTS)
        if channel:
            embed = discord.Embed(title="🎥 Novo Vídeo Publicado!", description=desc_val, color=0xFF0000, url=link_val)
            if video_id:
                embed.set_image(url=f"https://img.youtube.com/vi/{video_id}/maxresdefault.jpg")
            
            if interaction.user.avatar:
                embed.set_author(name=interaction.user.display_name, icon_url=interaction.user.avatar.url)
            else:
                embed.set_author(name=interaction.user.display_name)
                
            if interaction.guild.icon:
                embed.set_thumbnail(url=interaction.guild.icon.url)
                
            embed.set_footer(text="Privacy Mods • Divulgação YouTube")
            
            await channel.send(content=f"📢 **Novo vídeo de {interaction.user.mention}!**\n{link_val}", embed=embed)
            await interaction.response.send_message("✅ **Vídeo divulgado com sucesso!**", ephemeral=True)
        else:
            await interaction.response.send_message("⚠️ **Erro:** Canal de divulgação não configurado. Contate um administrador.", ephemeral=True)

class YoutubeView(View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Divulgar Vídeo", style=discord.ButtonStyle.red, emoji="📹", custom_id="divulgar_youtube")
    async def divulgar(self, interaction: discord.Interaction, button: Button):
        role = interaction.guild.get_role(RoleIDs.YOUTUBER)
        if role not in interaction.user.roles:
            await interaction.response.send_message(f"🚫 Você precisa do cargo {role.mention if role else 'Postador'} para divulgar vídeos.", ephemeral=True)
            return
        
        await interaction.response.send_modal(YoutubeModal())

async def send_panel(interaction: discord.Interaction):
    embed = discord.Embed(title="🔴 Painel de Divulgação YouTube", description="Clique no botão abaixo para divulgar seus vídeos do YouTube para a comunidade!\n\n**⚠️ Regras Importantes:**\n• Apenas links do YouTube são permitidos.\n• **PROIBIDO** divulgar outros servidores de Discord.\n• Violações resultarão na **perda imediata do cargo** e advertência.", color=0xFF0000)
    if interaction.guild.icon:
        embed.set_thumbnail(url=interaction.guild.icon.url)
    embed.set_image(url=imagenspainel.privacy_banner)
    
    await interaction.channel.send(embed=embed, view=YoutubeView())
    await interaction.response.send_message("Painel de YouTube enviado com sucesso!", ephemeral=True)