import discord
import asyncio
from deep_translator import GoogleTranslator
from settings import emojis
from settings import imagenspainel
from settings.ids import CategoryIDs
import os
import re
from dotenv import load_dotenv
load_dotenv()


class Traduzir(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Translate", style=discord.ButtonStyle.blurple, emoji=emojis.translate,
                       custom_id="translate")
    async def callback(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        try:
            mensagem = interaction.message.embeds[0].description.replace("ㅤ", "")
            target = str(interaction.locale).split("-")[0]
            loop = asyncio.get_running_loop()
            msg = await loop.run_in_executor(None, GoogleTranslator(source='auto', target=target).translate, mensagem)
            await interaction.followup.send(f"> {msg}", ephemeral=True)
        except Exception as e:
            await interaction.followup.send(f"Erro ao traduzir: {e}", ephemeral=True)


async def on_message(message: discord.Message):
    if isinstance(message.channel,
                  discord.TextChannel) and message.channel.category_id == CategoryIDs.TICKET_OPEN and message.channel.topic and "Traduzir: Sim" in message.channel.topic and not message.author.bot:
        
        topic = message.channel.topic
        user_id_match = re.search(r"ID: (\d+)", topic)
        locale_match = re.search(r"Traduzir: Sim, (\w+)", topic)
        
        translated_text = None
        target_lang = None
        detected_lang = None
        
        if user_id_match and locale_match:
            ticket_user_id = int(user_id_match.group(1))
            ticket_locale = locale_match.group(1)
            
            loop = asyncio.get_running_loop()

            async def get_translation(text, target):
                try:
                    translator = GoogleTranslator(source='auto', target=target)
                    return await loop.run_in_executor(None, translator.translate, text)
                except Exception as e:
                    print(f"Erro na tradução: {e}")
                    return None
            
            if message.content:
                if ticket_locale == 'pt':
                    translated_text = await get_translation(message.content, 'pt')
                    if translated_text and translated_text.strip().lower() != message.content.strip().lower():
                        target_lang = 'pt'
                        detected_lang = 'Auto'
                else:
                    trans_pt = await get_translation(message.content, 'pt')
                    trans_user = await get_translation(message.content, ticket_locale)
                    
                    is_pt_diff = trans_pt and trans_pt.strip().lower() != message.content.strip().lower()
                    is_user_diff = trans_user and trans_user.strip().lower() != message.content.strip().lower()
                    
                    if is_pt_diff and not is_user_diff:
                        translated_text = trans_pt
                        target_lang = 'pt'
                        detected_lang = ticket_locale
                    elif is_user_diff and not is_pt_diff:
                        translated_text = trans_user
                        target_lang = ticket_locale
                        detected_lang = 'pt'
                    elif is_pt_diff and is_user_diff:
                        if message.author.id == ticket_user_id:
                            translated_text = trans_pt
                            target_lang = 'pt'
                            detected_lang = ticket_locale
                        else:
                            translated_text = trans_user
                            target_lang = ticket_locale
                            detected_lang = 'pt'

        if not translated_text or translated_text.strip().lower() == message.content.strip().lower():
            return

        embed = discord.Embed(description=message.content, color=0x2F3136)
        embed.add_field(name="Tradução", value=translated_text[:1024], inline=False)
        if target_lang and detected_lang:
            embed.set_footer(text=f"Traduzido de {detected_lang} para {target_lang}")
        embed.set_author(name=message.author.name,
                         icon_url=message.author.avatar.url if message.author.avatar else imagenspainel.translate_author_icon)
        embeds = [embed]

        if message.attachments:
            for i in message.attachments:
                embeda = discord.Embed(color=0x2F3136)
                embeda.set_image(url=i.url)
                embeds.append(embeda)

        await message.channel.send(embeds=embeds, view=Traduzir())
        await message.delete()
