import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    @staticmethod
    def get(key):
        return os.getenv(key)
