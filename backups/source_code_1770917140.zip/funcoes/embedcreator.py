from discord import Interaction, Embed, ButtonStyle, SelectOption, TextStyle
from discord.ui import button, Select, View, Button, TextInput
from dispie import ModalInput
from settings import emojis as bot_emojis
from settings import imagenspainel
import discord
import json

usuario = {}
emojis = {
    "title": bot_emojis.title,
    "description": bot_emojis.description,
    "color": bot_emojis.color,
    "author": bot_emojis.author,
    "fields": bot_emojis.fields,
    "image": bot_emojis.image,
    "footer": bot_emojis.footer,
    "back": bot_emojis.back_menu,
    "trash": bot_emojis.trash,
    "send": bot_emojis.send,
    "adc": bot_emojis.adc,
    "edit": bot_emojis.edit,
    "import": bot_emojis.import_json,
    "export": bot_emojis.export_json
}

async def EditarEmbedPostado(interaction: Interaction, msg, embeds, msgedit):
    user_id = interaction.user.id
    usuario[user_id] = {"mensagem": msg, "embeds": embeds, "embedselecionado": "", "id": "", "color": "", "nomeembed": "", "field": "", "index": "", "msgedit": msgedit}

    totalembeds = len(embeds)
    edit = "s"
    await interaction.response.send_message(msg, embeds=embeds, view=MenuInicial(user_id, totalembeds, edit), ephemeral=True)

async def CriarEmbed(interaction: Interaction):
    user_id = interaction.user.id
    embed = Embed(colour=0x383d42)
    embed.set_author(name="Privacyᵐᵒᵈˢ", icon_url=interaction.guild.icon.url)
    embed.set_image(url=imagenspainel.privacy_banner)
    usuario[user_id] = {"mensagem": "**Personalize essa mensagem e o embed no menu abaixo. (sem mensagem = vázio)**", "embeds": [embed], "embedselecionado": "", "id": "", "color": "", "nomeembed": "", "field": "", "index": ""}
    msg = usuario[user_id]["mensagem"]
    embeds = usuario[user_id]["embeds"]
    totalembeds = 1
    edit = "n"
    await interaction.response.send_message(msg, embeds=embeds, view=MenuInicial(user_id, totalembeds, edit), ephemeral=True)

class MenuSeleçãoEmbeds(Select):
    def __init__(self, user_id, edit):
        self.edit = edit
        embedsusuario = usuario[user_id]["embeds"]
        mensagemusuario = usuario[user_id]["mensagem"]
        dftmsg = "Nenhuma mensagem foi inserida."
        if mensagemusuario:
            dftmsg = mensagemusuario[:100]
            
        embeds = []
        for embed in embedsusuario:
            embeds.append(embed)

        embedsoptions = [embed for embed in embeds]
        opções = [SelectOption(label=f"Mensagem", description=f"{dftmsg}", value=f"msg")]
        opções += [SelectOption(label=f"{n}. Embed", value=f"Embed {n}") for n, embed in enumerate(embedsoptions, start=1)]
        super().__init__(
            placeholder="Selecione uma opção para editar",
            min_values=1,
            max_values=1,
            options=opções,
        )

    async def callback(self, interaction: Interaction):
        user_id = interaction.user.id
        edit = self.edit

        if self.values[0] == "msg":
            mensagemusuario = usuario[user_id]["mensagem"]
            embeds = usuario[user_id]["embeds"]

            modal = ModalInput(title=f"EDITE A MENSAGEM")
            modal.add_item(TextInput(label="MENSAGEM", placeholder="Negrito=**texto**\nItálico=*texto*\nSublinhado=__texto__\nCitação=> texto\nHyperlink=[texto](link)", default = mensagemusuario, max_length=4000, style=TextStyle.paragraph, required=False))
            await interaction.response.send_modal(modal)
            await modal.wait()

            usuario[user_id]["mensagem"] = str(modal.children[0])
            totalembeds = len(usuario[user_id]["embeds"])
            await interaction.edit_original_response(content=str(modal.children[0]), embeds=embeds, view=MenuInicial(user_id, totalembeds, edit))
        
        else:
            embedsusuario = usuario[user_id]["embeds"]
            embed_index = int(self.values[0].split(" ")[1]) - 1
            selected_embed = embedsusuario[embed_index]

            usuario[user_id]["embedselecionado"] = selected_embed
            usuario[user_id]["id"] = embed_index
            usuario[user_id]["nomeembed"] = str(self.values[0])
            totalembeds = len(usuario[user_id]["embeds"])
            await interaction.response.edit_message(content=f"Edite o {str(self.values[0])} abaixo.", embed=selected_embed, view=EditarEmbed(totalembeds, edit))

class NovoEmbed(Button):
    def __init__(self, totalembeds, edit):
        self.edit = edit
        super().__init__(emoji=emojis["adc"], label="Adicionar Embed" if totalembeds < 10 else f"Máximo de Embeds ({totalembeds}) atingido", disabled=False if totalembeds < 10 else True, style=ButtonStyle.blurple, row=2)

    async def callback(self, interaction: Interaction):
        user_id = interaction.user.id
        edit = self.edit
        embeds = usuario[user_id]["embeds"]

        embed = Embed(title="Personalize o Título", description="Personalize a descrição", colour=0x383d42)
        embeds.append(embed)

        totalembeds = len(usuario[user_id]["embeds"])
        await interaction.response.edit_message(embeds=embeds, view=MenuInicial(user_id, totalembeds, edit))

class Enviar(Button):
    def __init__(self, edit):
        self.edit = edit
        super().__init__(emoji=emojis["send"], label="Enviar", style=ButtonStyle.green, row=2)

    async def callback(self, interaction: Interaction):
        user_id = interaction.user.id
        edit = self.edit
        embeds = usuario[user_id]["embeds"]
        msg = usuario[user_id]["mensagem"]

        totalembeds = len(usuario[user_id]["embeds"])
        await interaction.response.edit_message(embeds=embeds, view=MenuInicial(user_id, totalembeds, edit))
        await interaction.channel.send(msg, embeds=embeds)

class Salvar(Button):
    def __init__(self, edit):
        self.edit = edit
        super().__init__(label="Salvar Edição", style=ButtonStyle.green, row=2)

    async def callback(self, interaction: Interaction):
        user_id = interaction.user.id
        edit = self.edit
        embeds = usuario[user_id]["embeds"]
        msg = usuario[user_id]["mensagem"]
        msgedit = usuario[user_id]["msgedit"]

        totalembeds = len(usuario[user_id]["embeds"])
        await interaction.response.edit_message(embeds=embeds, view=MenuInicial(user_id, totalembeds, edit))
        msglink = await msgedit(content=msg, embeds=embeds)
        button = Button(label='Ir para a mensagem', url=msglink.jump_url)
        view = View().add_item(button)
        await interaction.followup.send(f"{bot_emojis.check} Mensagem com embed editada com sucesso.", view=view, ephemeral=True)

class MenuInicial(View):
    def __init__(self, user_id, totalembeds, edit):
        super().__init__(timeout=None)

        self.add_item(NovoEmbed(totalembeds, edit))
        self.add_item(MenuSeleçãoEmbeds(user_id, edit))
        if edit == "n":
            self.add_item(Enviar(edit))
        if edit == "s":
            self.add_item(Salvar(edit))

class EditarEmbed(View):
    def __init__(self, totalembeds, edit):
        self.edit = edit
        super().__init__(timeout=None)
        if totalembeds > 1:
            self.add_item(ApagarEmbed(edit))

    @button(label="Título", emoji=emojis["title"], style=ButtonStyle.gray, row=1)
    async def titulo(self, interaction: Interaction, button: Button):
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]

        modal = ModalInput(title=f"EDITE O TÍTULO")
        modal.add_item(TextInput(label="TÍTULO", placeholder="Ficará no topo do Embed, abaixo apenas do Autor.", default=str(embed.title) if embed.title else "", max_length=256, required=False))
        modal.add_item(TextInput(label="LINK DO TÍTULO", placeholder="Ao clicar no Título, o usuario será redirecionado.", default=str(embed.url) if embed.url else "", required=False))
        await interaction.response.send_modal(modal)
        await modal.wait()

        embed.title = str(modal.children[0])
        embed.url = str(modal.children[1])

        edit = self.edit
        await EditarPreview(interaction, embed, edit)
        return

    @button(label="Descrição", emoji=emojis["description"], style=ButtonStyle.gray, row=1)
    async def descrição(self, interaction: Interaction, button: Button):
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]

        modal = ModalInput(title=f"EDITE A DESCRIÇÃO")
        modal.add_item(TextInput(label="DESCRIÇÃO", placeholder="Negrito=**texto**\nItálico=*texto*\nSublinhado=__texto__\nCitação=> texto\nHyperlink=[texto](link)", default=str(embed.description) if embed.description else "", max_length=4000, style=TextStyle.paragraph, required=False))
        await interaction.response.send_modal(modal)
        await modal.wait()

        embed.description = str(modal.children[0])

        edit = self.edit
        await EditarPreview(interaction, embed, edit)
        return

    @button(label="Cores", emoji=emojis["color"], style=ButtonStyle.gray, row=1)
    async def cor(self, interaction: Interaction, button: Button):
        edit = self.edit
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]
        color = str(embed.color).upper()
        nomeembed = usuario[user_id]["nomeembed"]
        await interaction.response.edit_message(content=f"Altere a cor do {nomeembed}", view=Cores(color, edit))

    @button(label="Autor", emoji=emojis["author"], style=ButtonStyle.gray, row=1)
    async def autor(self, interaction: Interaction, button: Button):
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]

        modal = ModalInput(title=f"EDITE O AUTOR")
        modal.add_item(TextInput(label="NOME DO AUTOR", placeholder="Texto que ficará pequeno, acima de tudo.", default=str(embed.author.name) if embed.author.name else "", max_length=256, required=False))
        modal.add_item(TextInput(label="ÍCONE DO AUTOR", placeholder="URL de uma imagem para icone do Autor", default=str(embed.author.icon_url) if embed.author.icon_url else "", required=False))
        modal.add_item(TextInput(label="URL DO AUTOR", placeholder="Ao clicar no Autor, o usuario será redirecionado.", default=str(embed.author.url) if embed.author.url else "", required=False))
        await interaction.response.send_modal(modal)
        await modal.wait()

        embed.set_author(name= str(modal.children[0]) if modal.children[0] else "", url= str(modal.children[2]) if modal.children[2] else "", icon_url= str(modal.children[1]) if modal.children[1] else "")

        edit = self.edit
        await EditarPreview(interaction, embed, edit)
        return

    @button(label="Editar Campos", emoji=emojis["edit"], style=ButtonStyle.gray, row=2)
    async def fields(self, interaction: Interaction, button: Button):
        user_id = interaction.user.id
        nomeembed = usuario[user_id]["nomeembed"]
        embed = usuario[user_id]["embedselecionado"]
        fields = len(embed.fields)
        index = usuario[user_id]["index"]
        edit = self.edit
        await interaction.response.edit_message(content=f"Edite os Campos do {nomeembed}",view=Campos(fields, user_id, index, edit))

    @button(label="Imagem & Thumbnail", emoji=emojis["image"], style=ButtonStyle.gray, row=2)
    async def imagem(self, interaction: Interaction, button: Button):
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]

        modal = ModalInput(title=f"EDITE AS IMAGENS")
        modal.add_item(TextInput(label="IMAGEM", placeholder="URL da Imagem que ficará grande no final.", default=str(embed.image.url) if embed.image.url else "", required=False))
        modal.add_item(TextInput(label="THUMBNAIL", placeholder="URL da Thumbnail que ficará pequena no topo direito.", default=str(embed.thumbnail.url) if embed.thumbnail.url else "", required=False))
        await interaction.response.send_modal(modal)
        await modal.wait()

        embed.set_image(url=str(modal.children[0]))
        embed.set_thumbnail(url=str(modal.children[1]))

        edit = self.edit
        await EditarPreview(interaction, embed, edit)
        return

    @button(label="Rodapé", emoji=emojis["footer"], style=ButtonStyle.gray, row=2)
    async def rodapé(self, interaction: Interaction, button: Button):
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]

        modal = ModalInput(title=f"EDITE O RODAPÉ")
        modal.add_item(TextInput(label="TEXTO DO RODAPÉ", placeholder="Texto que ficará pequeno, abaixo de tudo.", default=str(embed.footer.text) if embed.footer.text else "", max_length=2048, required=False))
        modal.add_item(TextInput(label="ÍCONE DO RODAPÉ", placeholder="URL da imagem que ficará ao lado do texto do Rodapé.", default=str(embed.footer.icon_url) if embed.footer.icon_url else "", required=False))
        await interaction.response.send_modal(modal)
        await modal.wait()

        embed.set_footer(text=str(modal.children[0]), icon_url=str(modal.children[1]))
        edit = self.edit
        await EditarPreview(interaction, embed, edit)
        return

    @button(emoji=emojis["back"], style=ButtonStyle.gray, row=3)
    async def voltar(self, interaction: Interaction, button: Button):
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]
        msg = usuario[user_id]["mensagem"]
        idembed = usuario[user_id]["id"]
        embeds = usuario[user_id]["embeds"]
        totalembeds = len(usuario[user_id]["embeds"])
        edit = self.edit

        try:
            embeds[idembed] = embed
            await interaction.response.edit_message(content=msg, embeds=embeds, view=MenuInicial(user_id, totalembeds, edit))

        except discord.errors.HTTPException as e:
            if e.status == 400 and e.code == 50035:
                totalembeds = len(usuario[user_id]["embeds"])
                await interaction.response.edit_message(view=EditarEmbed(totalembeds, edit))
                await interaction.followup.send("Você não pode deixar o embed vázio.", ephemeral=True)

    @button(label="Importar JSON", emoji=emojis["import"], style=ButtonStyle.blurple, row=3)
    async def importar(self, interaction: Interaction, button: Button):
        
        modal = ModalInput(title=f"IMPORTE O EMBED COM O JSON")
        modal.add_item(TextInput(label="JSON", placeholder="Cole aqui o código JSON", max_length=4000, style=TextStyle.paragraph, required=True))
        await interaction.response.send_modal(modal)
        await modal.wait()

        edit = self.edit
        user_id = interaction.user.id
        json_data = modal.children[0].value

        try:
            embed_data = json.loads(json_data)
            embed = discord.Embed.from_dict(embed_data)
            totalembeds = len(usuario[user_id]["embeds"])
            usuario[user_id]["embedselecionado"] = embed
            await interaction.edit_original_response(embed=embed, view=EditarEmbed(totalembeds, edit))
        except json.JSONDecodeError:
            await interaction.followup.send("O JSON fornecido é inválido. Por favor, forneça um JSON válido.", ephemeral=True)

    @button(label="Exportar JSON", emoji=emojis["export"], style=ButtonStyle.blurple, row=3)
    async def exportar(self, interaction: Interaction, button: Button):
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]
        totalembeds = len(usuario[user_id]["embeds"])
        edit = self.edit

        embed_dict = embed.to_dict()
        embed_json = json.dumps(embed_dict, indent=4)

        embed_exportado = discord.Embed(description=f"```json\n{embed_json}```", color=discord.Color.green())

        await interaction.response.edit_message(embed=embed, view=EditarEmbed(totalembeds, edit))
        await interaction.followup.send(embed=embed_exportado, ephemeral=True)

class CoresMenu(Select):
    def __init__(self, color, edit):
        op = [
            SelectOption(label="Adicionar HEX", value="hex", description=color, emoji=bot_emojis.adc),
            SelectOption(label="Cor Primária Privacyᵐᵒᵈˢ", value="cor1"),
            SelectOption(label="Cor Secundaria Privacyᵐᵒᵈˢ", value="cor2"),
            SelectOption(label="Azul Discord", value="dc"),
            SelectOption(label="Neutro", value="neutro"),
            SelectOption(label="Vermelho", value="red"),
            SelectOption(label="Verde", value="green"),
            SelectOption(label="Azul", value="blue"),
            SelectOption(label="Ciano", value="cian"),
            SelectOption(label="Magenta", value="magenta"),
            SelectOption(label="Amarelo", value="yellow"),
        ]
        super().__init__(
            placeholder="Selecione uma das cores",
            min_values=1,
            max_values=1,
            options=op,
        )
        self.edit = edit
    async def callback(self, interaction: Interaction):
        edit = self.edit
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]
        color = usuario[user_id]["color"]

        if self.values[0] == "cor1":
            embed.colour = 0xFFFFFF
            usuario[user_id]["color"] = "#FFFFFF"
        if self.values[0] == "cor2":
            embed.colour = 0x000000
            usuario[user_id]["color"] = "#000000"
        if self.values[0] == "dc":
            embed.colour = 0x7289DA
            usuario[user_id]["color"] = "7289DA"
        if self.values[0] == "neutro":
            embed.colour = 0x2F3136
            usuario[user_id]["color"] = "#2F3136"
        if self.values[0] == "red":
            embed.colour = 0xFF0000
            usuario[user_id]["color"] = "#FF0000"
        if self.values[0] == "green":
            embed.colour = 0x00FF00
            usuario[user_id]["color"] = "#00FF00"
        if self.values[0] == "blue":
            embed.colour = 0x0000FF
            usuario[user_id]["color"] = "#0000FF"
        if self.values[0] == "cian":
            embed.colour = 0x00FFFF
            usuario[user_id]["color"] = "#00FFFF"
        if self.values[0] == "magenta":
            embed.colour = 0xFF00FF
            usuario[user_id]["color"] = "#FF00FF"
        if self.values[0] == "yellow":
            embed.colour = 0xFFFF00
            usuario[user_id]["color"] = "#FFFF00"
        
        if self.values[0] == "hex":
            modal = ModalInput(title=f"EDITE A COR")
            modal.add_item(TextInput(label="HEX", placeholder="Insira o Hexadeciaml da cor. ex: #E6C200", default=color, max_length=7, required=True))
            await interaction.response.send_modal(modal)
            await modal.wait()

            if len(str(modal.children[0])) < 6:
                await interaction.edit_original_response(view=Cores(color, edit))
                await interaction.followup.send("Você inseriu um hexadecimal inválido.", ephemeral=True)
            
            else:
                if len(str(modal.children[0])) == 6 and not str(modal.children[0]).startswith("#"):
                    cor = f"#{str(modal.children[0]).upper()}"
                    hex = str(modal.children[0])

                elif len(str(modal.children[0])) == 7 and str(modal.children[0]).startswith("#"):
                    cor = str(modal.children[0]).upper()
                    hex = str(modal.children[0]).replace("#", "")

                else:
                    await interaction.edit_original_response(view=Cores(color, edit))
                    await interaction.followup.send("Você inseriu um hexadecimal inválido.", ephemeral=True)
                    return

                usuario[user_id]["color"] = cor
                embed.colour = int(hex, 16)

        color = usuario[user_id]["color"]
        try:
            await interaction.response.edit_message(embed=embed, view=Cores(color, edit))
        except:
            await interaction.edit_original_response(embed=embed, view=Cores(color, edit))

class ApagarEmbed(Button):
    def __init__(self, edit):
        super().__init__(label="Apagar Embed", emoji=emojis["trash"], style=ButtonStyle.gray, row=3)
        self.edit = edit

    async def callback(self, interaction: Interaction):
        edit = self.edit
        user_id = interaction.user.id
        idembed = usuario[user_id]["id"]
        embeds = usuario[user_id]["embeds"]
        totalembeds = len(usuario[user_id]["embeds"])

        embeds.pop(idembed)
        await interaction.response.edit_message(embeds=embeds, view=MenuInicial(user_id, totalembeds, edit))

class Back(Button):
    def __init__(self, edit):
        self.edit = edit
        super().__init__(emoji=emojis["back"], style=ButtonStyle.gray, row=3)

    async def callback(self, interaction: Interaction):
        edit = self.edit
        user_id = interaction.user.id
        nomeembed = usuario[user_id]["nomeembed"]
        totalembeds = len(usuario[user_id]["embeds"])
        await interaction.response.edit_message(content=f"Edite o {nomeembed} abaixo.",view=EditarEmbed(totalembeds, edit))

class Cores(View):
    def __init__(self, color, edit):
        super().__init__(timeout=None)

        self.add_item(CoresMenu(color, edit))
        self.add_item(Back(edit))
        self.add_item(Button(label="Encontrar HEX", url="https://htmlcolorcodes.com/", row=3))

class NovoCampo(Button):
    def __init__(self, fields, edit):
        self.edit = edit
        super().__init__(label="Adicionar Campo" if fields < 25 else f"Máximo de fields ({fields}) atingido", emoji=emojis["adc"] if fields < 25 else None, style=ButtonStyle.green, row=3)

    async def callback(self, interaction: Interaction):
        edit = self.edit
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]

        modal = ModalInput(title=f"CONFIGURE O CAMPO")
        modal.add_item(TextInput(label="NOME DO CAMPO", placeholder="Nome para o campo, permitida certas formatações.", max_length=256, required=True))
        modal.add_item(TextInput(label="VALOR DO CAMPO", placeholder="Texto dentro do campo, permitido formatação.", max_length=1024, style=TextStyle.paragraph, required=False))
        modal.add_item(TextInput(label="EN LINHA", placeholder="Adicionar o Campo abaixo? (não/sim)", default="Não", max_length=3, required=True))
        await interaction.response.send_modal(modal)
        await modal.wait()

        inline = True if str(modal.children[2]).lower() == "sim" else False if str(modal.children[2]).lower() in ["não", "nao"] else True

        embed.add_field(
            name=str(modal.children[0]),
            value=str(modal.children[1]) if modal.children[1] else "",
            inline=inline
        )
        fields = len(embed.fields)
        index = usuario[user_id]["index"]
        await interaction.edit_original_response(embed=embed, view=Campos(fields, user_id, index, edit))

class Selecionado(Button):
    def __init__(self, index):
        super().__init__(label=f'"Campo {index + 1}" selecionado' if index != "" else "Nenhum campo selecionado", style=ButtonStyle.gray, row=1, disabled=True)

    async def callback(self, interaction: Interaction):
        print("erro | linha 358")

class Apagar(Button):
    def __init__(self, index, edit):
        self.edit = edit
        super().__init__(label="Apagar", emoji=emojis["trash"], style=ButtonStyle.gray, row=1, disabled=True if index == "" else False)

    async def callback(self, interaction: Interaction):
        edit = self.edit
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]
        index = usuario[user_id]["index"]
        fields = len(embed.fields)
        if fields == 1 and not embed.title and not embed.description and not embed.url and not embed.author.name and not embed.footer.text and not embed.image.url and not embed.thumbnail.url:
            index = usuario[user_id]["index"]
            await interaction.response.edit_message(embed=embed, view=Campos(fields, user_id, index, edit))
            await interaction.followup.send("Você não pode deixar o embed vázio.", ephemeral=True)

        else:
            embed.remove_field(index)
            index = usuario[user_id]["index"] = ""
            embed = usuario[user_id]["embedselecionado"]
            fields = len(embed.fields)
            await interaction.response.edit_message(embed=embed, view=Campos(fields, user_id, index, edit))

class Editar(Button):
    def __init__(self, index, edit):
        self.edit = edit
        super().__init__(label="Editar", emoji=emojis["edit"], style=ButtonStyle.gray, row=1, disabled=True if index == "" else False)

    async def callback(self, interaction: Interaction):
        edit = self.edit
        user_id = interaction.user.id
        embed = usuario[user_id]["embedselecionado"]
        index = usuario[user_id]["index"]
        field = usuario[user_id]["field"]

        modal = ModalInput(title=f"CONFIGURE O CAMPO {index}")
        modal.add_item(TextInput(label="NOME DO CAMPO", placeholder="Nome para o campo, permitida certas formatações.", default=str(field.name), max_length=256, required=True))
        modal.add_item(TextInput(label="VALOR DO CAMPO", placeholder="Texto dentro do campo, permitido formatação.", default=str(field.value), max_length=1024, required=False))
        modal.add_item(TextInput(label="EN LINHA", placeholder="Adicionar o Campo abaixo? (não/sim)", default="Não" if field.inline == False else "Sim", max_length=3, required=True))
        await interaction.response.send_modal(modal)
        await modal.wait()

        inline = True if str(modal.children[2]).lower() == "sim" else False if str(modal.children[2]).lower() in ["não", "nao"] else True

        embed.set_field_at(
            index,
            name=str(modal.children[0]),
            value=str(modal.children[1]) if modal.children[1] else "",
            inline=inline
        )

        fields = len(embed.fields)
        index = usuario[user_id]["index"]
        usuario[user_id]["field"] = embed.fields[index]
        await interaction.edit_original_response(embed=embed, view=Campos(fields, user_id, index, edit))

class MenuFields(Select):
    def __init__(self, user_id, edit):
        self.edit = edit
        embed = usuario[user_id]["embedselecionado"]
        embedfields = embed.fields
        fields = []
            
        for index, field in enumerate(embedfields, start=1):
            fields.append((index, field))

        opções = [SelectOption(label=f"{index}. {field.name[:100]}", value=index, description=f"{str(field.value)[:100]}") for index, field in fields]
        super().__init__(
            placeholder="Selecione um campo para configurar",
            min_values=1,
            max_values=1,
            options=opções,
            row=2
        )

    async def callback(self, interaction: Interaction):
        user_id = interaction.user.id
        edit = self.edit
        embed = usuario[user_id]["embedselecionado"]
        selected_option = self.values[0]
        index = int(selected_option)
        fieldselecionado = embed.fields[index - 1]

        usuario[user_id]["index"] = index - 1
        usuario[user_id]["field"] = fieldselecionado
        
        fields = len(embed.fields)
        index = usuario[user_id]["index"]
        await interaction.response.edit_message(view=Campos(fields, user_id, index, edit))

class Campos(View):
    def __init__(self, fields, user_id, index, edit):
        super().__init__(timeout=None)

        if fields != 0:
            self.add_item(Selecionado(index))
            self.add_item(Editar(index, edit))
            self.add_item(Apagar(index, edit))
            self.add_item(MenuFields(user_id, edit))
        self.add_item(Back(edit))
        self.add_item(NovoCampo(fields, edit))

async def EditarPreview(interaction: Interaction, embed, edit):
    user_id = interaction.user.id
    totalembeds = len(usuario[user_id]["embeds"])

    try:
        usuario[user_id]["embedselecionado"] = embed
        await interaction.edit_original_response(embed=embed, view=EditarEmbed(totalembeds, edit))

    except discord.errors.HTTPException as e:
        if e.status == 400 and e.code == 50035:
            await interaction.edit_original_response(view=EditarEmbed(totalembeds, edit))
            await interaction.followup.send("Você não pode deixar o embed vázio.", ephemeral=True)
