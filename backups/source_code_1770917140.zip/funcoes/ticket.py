import discord, os, time, chat_exporter, asyncio, json
from github import Github
from discord.ui import button, Button, View
from settings import emojis
from settings import imagenspainel
from settings.ids import ChannelIDs, CategoryIDs, RoleIDs
from deep_translator import GoogleTranslator
from dotenv import load_dotenv
from funcoes.gerenciador import Config
load_dotenv()

idemoji = emojis.id_emoji
openemoji = emojis.check
closeemoji = emojis.remove
horaemoji = emojis.hour


async def traduzirmsg(msg, lingua):
    try:
        loop = asyncio.get_running_loop()
        translator = GoogleTranslator(source='auto', target=lingua)
        return await loop.run_in_executor(None, translator.translate, msg)
    except Exception as e:
        print(f"Erro ao traduzir mensagem do sistema: {e}")
        return msg


async def TicketMensagem(interaction: discord.Interaction):
    embed = discord.Embed()
    icon_url = interaction.guild.icon.url if interaction.guild.icon else None
    embed.set_author(name="Support Privacyᵐᵒᵈˢ", icon_url=icon_url)
    embed.description = "🇧🇷・Clique no botão abaixo para abrir um ticket e receber suporte de nossos administradores.\n**Abra o ticket para retirar dúvidas relacionadas ao servidor ou a mods apenas.**\n\n🇺🇸・Click the button below to open a ticket and receive support from our administrators.\n**Open a ticket for questions regarding the server or mods only.**\n\n🇪🇸・Haga clic en el botón de abajo para abrir un ticket y recibir soporte de nuestros administradores.\n**Abra un ticket solo para dudas relacionadas con el servidor o mods.**"
    embed.set_image(
        url=imagenspainel.privacy_banner)
    embed.set_footer(text="© Privacyᵐᵒᵈˢ, 2026. All Rights Reserved.")
    embed.colour = 0xe6c200
    await interaction.channel.send(embed=embed, view=CreateButton())


async def get_transcript(memberid, channel: discord.TextChannel):
    export = await chat_exporter.export(channel=channel)
    file_name = f"{memberid}.html"
    with open(file_name, "w", encoding="utf-8") as f:
        f.write(export)


def upload(file_path: str, member_name: str):
    github = Github(os.getenv("GTOKEN"))
    repo = github.get_repo(Config.get("TICKET_REPO"))
    file_name = f"{int(time.time())}"
    repo.create_file(
        path=f"tickets/{file_name}.html",
        message="Ticket Log for {0}".format(member_name),
        branch="main",
        content=open(f"{file_path}", "r", encoding="utf-8").read()
    )
    os.remove(file_path)

    return file_name


def get_last_ticket_number():
    try:
        with open("last_ticket_number.json", "r") as f:
            last_ticket_number = json.load(f)
            if isinstance(last_ticket_number, dict):
                last_ticket_number = last_ticket_number["last_ticket_number"]
    except FileNotFoundError:
        with open("last_ticket_number.json", "w") as f:
            json.dump({"last_ticket_number": last_ticket_number}, f)
    last_ticket_number = int(last_ticket_number)
    return last_ticket_number


def save_last_ticket_number(new_ticket_number):
    with open("last_ticket_number.json", "w") as f:
        json.dump({"last_ticket_number": new_ticket_number}, f)


async def CreateTicket(interaction: discord.Interaction, category, traduzir):
    locale = interaction.locale
    locale = str(locale)
    locale = locale.split("-")[0]

    r1: discord.Role = interaction.guild.get_role(RoleIDs.ADMIN)
    r2: discord.Role = interaction.guild.get_role(RoleIDs.SUPORTE)
    overwrites = {
        interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
        r1: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_messages=True),
        r2: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_messages=True),
        interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
        interaction.guild.me: discord.PermissionOverwrite(
            read_messages=True, send_messages=True)
    }

    last_ticket_number = get_last_ticket_number()
    new_ticket_number = last_ticket_number + 1
    save_last_ticket_number(new_ticket_number)

    for ch in category.text_channels:
        name = int(ch.name.split("・")[0])
        if name == new_ticket_number:
            new_ticket_number += 1
            break

    adm = interaction.guild.get_role(RoleIDs.ADMIN)
    adm1 = interaction.guild.get_role(RoleIDs.SUPORTE)

    if traduzir == "Sim":
        redi = await traduzirmsg("Ticket criado, clique para ser redirecionado:", locale)
        titleEmbed = await traduzirmsg("Ticket Criado.", locale)
        descriptionEmbed = await traduzirmsg(
            "**Seu ticket foi criado com sucesso!**\nAguarde, nossa equipe te responderá o quanto antes.\n\nDescreva o motivo para abrir este ticket abaixo:",
            locale)
        msg = await traduzirmsg("Este é seu ticket.\n **Administradores responsaveis:**", locale)
        embed = discord.Embed(title=titleEmbed, description=descriptionEmbed, colour=0x2F3136)
        lang_field = await traduzirmsg("Idioma detectado", locale)
        embed.add_field(name=lang_field, value=f"`{locale}`", inline=True)
        icon_url = interaction.guild.icon.url if interaction.guild.icon else None
        embed.set_footer(text="© Privacyᵐᵒᵈˢ, 2026. All Rights Reserved.", icon_url=icon_url)

        channel = await category.create_text_channel(
            name=f"{new_ticket_number}・{interaction.user.name}",
            topic=f"Ticket do usuario ID: {interaction.user.id} | Traduzir: {traduzir}, {locale}",
            overwrites=overwrites
        )
        msg = await channel.send(f"{interaction.user.mention} | {msg} {adm.mention}, {adm1.mention}", embed=embed,
                                 view=CloseButton())
        await msg.pin()
        await interaction.edit_original_response(content=None,
                                                 embed=discord.Embed(description=f"{redi} {channel.mention}",
                                                                     color=discord.Color.green()), view=None)

    if traduzir == "BR" or traduzir == "Não":
        channel = await category.create_text_channel(
            name=f"{new_ticket_number}・{interaction.user.name}",
            topic=f"Ticket do usuario ID: {interaction.user.id} | Traduzir: {traduzir}, {locale}",
            overwrites=overwrites
        )
        title = await traduzirmsg("Ticket Criado.", locale)
        desc = await traduzirmsg("**Seu ticket foi criado com sucesso!**\nAguarde, nossa equipe te responderá o quanto antes.\n\nDescreva o motivo para abrir este ticket abaixo:", locale)
        
        embed = discord.Embed(title=title, description=desc, colour=0xE6C400)
        embed.add_field(name="Idioma / Language", value=f"`{locale}`", inline=True)
        msg = await channel.send(
            f"{interaction.user.mention} | Este é seu ticket.\n **Administradores responsaveis:** {adm.mention}, {adm1.mention}",
            embed=embed, view=CloseButton())
        await msg.pin()
        await interaction.edit_original_response(content=None, embed=discord.Embed(
            description=f"Ticket criado, clique para ser redirecionado: {channel.mention}",
            color=discord.Color.green()))


class ButtonConfirmSim(discord.ui.Button):
    def __init__(self, msg, category, sim):
        super().__init__(label=sim, style=discord.ButtonStyle.green)
        self.category = category
        self.msg = msg

    async def callback(self, interaction: discord.Interaction):
        category = self.category
        traduzir = "Sim"
        msg = self.msg
        await interaction.response.edit_message(content=f"**{msg}**", embed=None, view=None)
        await CreateTicket(interaction, category, traduzir)


class ButtonConfirmNão(discord.ui.Button):
    def __init__(self, msg, category, não):
        super().__init__(label=não, style=discord.ButtonStyle.red)
        self.category = category
        self.msg = msg

    async def callback(self, interaction: discord.Interaction):
        category = self.category
        traduzir = "Não"
        msg = self.msg
        await interaction.response.edit_message(content=f"**{msg}**", embed=None, view=None)
        await CreateTicket(interaction, category, traduzir)


class ConfirmButton(discord.ui.View):
    def __init__(self, msg, category, sim, não):
        super().__init__(timeout=None)

        self.add_item(ButtonConfirmSim(msg, category, sim))
        self.add_item(ButtonConfirmNão(msg, category, não))


class CreateButton(View):
    def __init__(self):
        super().__init__(timeout=None)

    @button(label="・Criar Ticket", style=discord.ButtonStyle.blurple, emoji=emojis.plus, custom_id="ticketopen")
    async def ticket(self, interaction: discord.Interaction, button: Button):
        category: discord.CategoryChannel = discord.utils.get(interaction.guild.categories, id=CategoryIDs.TICKET_OPEN)
        locale = interaction.locale
        locale = str(locale)
        locale = locale.split("-")[0]
        for ch in category.text_channels:
            if f"Ticket do usuario ID: {interaction.user.id}" in ch.topic:
                await interaction.response.send_message(f"Você já tem um ticket aberto em: {ch.mention}",
                                                        ephemeral=True)
                return

        if locale != "pt":
            a = await traduzirmsg("Aguarde uns instantes...", locale)
            await interaction.response.send_message(f"**{a}**", ephemeral=True)
            translated_text = await traduzirmsg(
                "**IMPORTANTE**\n\nPercebemos que seu aplicativo do discord não está configurado com a linguagem portuguesa.\nTemos um sistema que traduz automaticamente sua mensagem, deseja ativar esta função neste ticket?\n**Observação:** Esta função ajuda no seu atendimento com nossos admins.\n\n**Abra o ticket para retirar dúvidas relacionadas ao servidor ou a mods apenas.**",
                locale)
            sim = await traduzirmsg("Sim, ativar", locale)
            não = await traduzirmsg("Não, não ativar", locale)
            msg = str(a)
            await interaction.edit_original_response(content=translated_text,
                                                     view=ConfirmButton(msg, category, sim, não))

        else:
            await interaction.response.send_message("**Aguarde uns instantes...**", ephemeral=True)
            traduzir = "BR"
            await CreateTicket(interaction, category, traduzir)


async def trash(interaction: discord.Interaction):
    member = interaction.user
    role_ids = [RoleIDs.ADMIN, RoleIDs.SUPORTE]

    has_role = False
    for role in member.roles:
        if role.id in role_ids:
            has_role = True
            break

    if has_role:
        user = interaction.channel.topic
        user = user.split(":")[1].split("|")[0].strip()
        if interaction.response.is_done():
            await interaction.followup.send(f"{interaction.user.mention} | Fechei o ticket para você.", ephemeral=True)
        else:
            await interaction.response.send_message(f"{interaction.user.mention} | Fechei o ticket para você.", ephemeral=True)

        r1: discord.Role = interaction.guild.get_role(role_ids[0])
        r2: discord.Role = interaction.guild.get_role(role_ids[1])
        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
            r1: discord.PermissionOverwrite(read_messages=True, send_messages=False, manage_messages=False),
            r2: discord.PermissionOverwrite(read_messages=True, send_messages=False, manage_messages=False),
            interaction.guild.get_member(int(user)): discord.PermissionOverwrite(read_messages=True,
                                                                                 send_messages=False),
            interaction.guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=False)
        }

        channel = interaction.channel
        for target, overwrite in overwrites.items():
            await channel.set_permissions(target, overwrite=overwrite)
        await interaction.channel.send(f"Ticket fechado por {interaction.user.mention}!")
        async for message in interaction.channel.history(limit=1, oldest_first=True):
            message_time = message.created_at
            timestamp = int(message_time.timestamp())

        from settings.check import Bot
        check_user = await Bot.fetch_user(user)

        name = interaction.user.display_name

        await get_transcript(memberid=user, channel=interaction.channel)
        file_name = upload(f'{user}.html', name)
        repo_full_name = Config.get("TICKET_REPO")
        repo_owner, repo_name = repo_full_name.split('/')
        link = f"https://{repo_owner}.github.io/{repo_name}/tickets/{file_name}.html"

        class ButtonTranscript(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(label="・Acessar o Transcript", emoji=emojis.refresh, url=link))

        log_channel = interaction.guild.get_channel(ChannelIDs.TICKET_LOGS)
        id = interaction.channel.name.split("・")
        id = id[0]

        embed = discord.Embed(title="TICKET FECHADO", color=0x2F3136)
        embed.add_field(name=f"{idemoji} Ticket ID", value=f"{id}", inline=False)
        embed.add_field(name=f"{openemoji} Aberto por", value=f"<@{user}>", inline=False)
        embed.add_field(name=f"{closeemoji} Fechado por", value=f"{interaction.user.mention}", inline=False)
        embed.add_field(name=f"{horaemoji} Aberto em", value=f"<t:{timestamp}:f>", inline=False)
        icon_url = interaction.guild.icon.url if interaction.guild.icon else None
        embed.set_footer(text="© Privacyᵐᵒᵈˢ, 2026. All Rights Reserved.", icon_url=icon_url)

        await log_channel.send(embed=embed, view=ButtonTranscript())
        await interaction.channel.send(f"Tentando Enviar o transcript para <@{user}>")

        try:
            await check_user.send(embed=embed, view=ButtonTranscript())
            await interaction.channel.send(f"Foi enviado o transcript para <@{user}>!")
        except:
            await interaction.channel.send(
                f"Não foi possível enviar o transcript para <@{user}>!\n**Privado bloqueado**.")

        await interaction.channel.send("Apagando o ticket em 3 Segundos!")
        await asyncio.sleep(3)
        await interaction.channel.delete()
    else:
        if interaction.response.is_done():
            await interaction.followup.send("Apenas admins podem fechar o ticket. peça-os para fechar.", ephemeral=True)
        else:
            await interaction.response.send_message("Apenas admins podem fechar o ticket. peça-os para fechar.", ephemeral=True)


class CloseButton(View):
    def __init__(self):
        super().__init__(timeout=None)

    @button(label="Fechar (admins)", style=discord.ButtonStyle.red, emoji=closeemoji, custom_id="trash")
    async def callback(self, interaction: discord.Interaction, button: Button):
        await interaction.response.defer(ephemeral=True)
        await trash(interaction)

async def check_ticket_message(bot):
    channel_id = ChannelIDs.TICKET_PANEL
    if not channel_id:
        return

    channel = bot.get_channel(channel_id)
    if not channel:
        return

    async for message in channel.history(limit=10):
        if message.author == bot.user and message.embeds:
            if message.embeds[0].description and "Clique no botão abaixo para abrir um ticket" in message.embeds[0].description:
                embed = message.embeds[0]
                embed.description = "🇧🇷・Clique no botão abaixo para abrir um ticket e receber suporte de nossos administradores.\n**Abra o ticket para retirar dúvidas relacionadas ao servidor ou a mods apenas.**\n\n🇺🇸・Click the button below to open a ticket and receive support from our administrators.\n**Open a ticket for questions regarding the server or mods only.**\n\n🇪🇸・Haga clic en el botón de abajo para abrir un ticket y recibir soporte de nuestros administradores.\n**Abra un ticket solo para dudas relacionadas con el servidor o mods.**"
                await message.edit(embed=embed, view=CreateButton())
                return

    embed = discord.Embed()
    icon_url = channel.guild.icon.url if channel.guild.icon else None
    embed.set_author(name="Support Privacyᵐᵒᵈˢ", icon_url=icon_url)
    embed.description = "🇧🇷・Clique no botão abaixo para abrir um ticket e receber suporte de nossos administradores.\n**Abra o ticket para retirar dúvidas relacionadas ao servidor ou a mods apenas.**\n\n🇺🇸・Click the button below to open a ticket and receive support from our administrators.\n**Open a ticket for questions regarding the server or mods only.**\n\n🇪🇸・Haga clic en el botón de abajo para abrir un ticket y recibir soporte de nuestros administradores.\n**Abra un ticket solo para dudas relacionadas con el servidor o mods.**"
    embed.set_image(url=imagenspainel.privacy_banner)
    embed.set_footer(text="© Privacyᵐᵒᵈˢ, 2026. All Rights Reserved.")
    embed.colour = 0xe6c200
    await channel.send(embed=embed, view=CreateButton())
