import discord
from settings import emojis
from settings import imagenspainel
from settings.ids import ChannelIDs, CategoryIDs, MessageIDs, UserIDs, RoleIDs, GithubConfig
from funcoes.components import upload_to_github
from dispie import ModalInput
from discord.ui import TextInput
import requests
import re
import zipfile
import os
import shutil
import tempfile
from PIL import Image
from io import BytesIO
import json
import time
import asyncio
from dotenv import load_dotenv
load_dotenv()

seta = emojis.arrow
embeds = {}
#embeddivedersa = discord.Embed(title="Divisores Animados", colour=0x2f3136)
embeddivederss = discord.Embed(title="Divisores Privacyᵐᵒᵈˢ", colour=0x2f3136)
#embeddivedersa.set_image(url="https://cdn.discordapp.com/attachments/976658493295710252/1131008895368826951/dividers_animated.gif")
embeddivederss.set_image(url=imagenspainel.divisores_privacy)
category_ids = CategoryIDs.POSTS
category_ids_threads = CategoryIDs.THREADS

async def enviar(user, arquivo):
    try:
        return await user.send(file=arquivo)
    except:
        asyncio.sleep(10)
        return await user.send(file=arquivo)

async def hubmods(interaction: discord.Interaction):
    await interaction.response.send_message("Aguarde...", ephemeral=True)
    embed = discord.Embed(title="╺╸POSTE SEUS MODS NO DISCORD", description="**TOTAL DE MODS PUBLICADOS**: __**0**__\n\n   Clique abaixo para começar o processo de envio do seu post em nosso discord.", colour=0x383d42)
    
    a = await interaction.channel.send(embed=embed, view=Post())

    with open("message_counts.json", "r") as f:
        data = json.load(f)

    data["mensagemid"] = a.id

    with open("message_counts.json", "w") as f:
        json.dump(data, f, indent=4)

    await interaction.edit_original_response(content="Pronto")

def embeddivisores(opção):
    with open("divisores.json", "r", encoding='utf-8') as f:
        data = json.load(f)

    embed = discord.Embed(title="EDITOR DE DIVISORES", color=0x2F3136)
    op = []
    n = 1

    if data != {}:
        for nomed, linkd in data.items():
            nomeembed = f"{nomed[:50]}{'...' if len(nomed) > 50 else ''}"
            embed.add_field(name=nomeembed.ljust(35, "ㅤ"), value=f"ID Divisor: {linkd}", inline=False)
            op.append(discord.SelectOption(value=n, label=nomed, description=f"ID Divisor: {linkd}"))
            n += 1

    return embed if opção == "embed" else op

async def adcdivisor(interaction: discord.Interaction, v=False):
    from settings.check import Bot as bot
    channel = bot.get_channel(ChannelIDs.DIVISORES)
    with open("divisores.json", "r", encoding='utf-8') as f:
        data = json.load(f)

    embed = embeddivisores("embed")

    class EditarDiv(discord.ui.View):
        def __init__(self, e, divisor=None):
            super().__init__(timeout=None)
            if e == "editar":
                if data != {}:
                    self.add_item(divisores())
                self.add_item(Adicionar())
                self.add_item(AdicionarPack())
                self.add_item(Salvar())
            else:
                self.add_item(Nome(divisor))
                self.add_item(Voltar())
                self.add_item(Apagar(divisor))
                
    def AlterarJson(modificação, divisor=None, alterar=None):
        with open("divisores.json", "r", encoding='utf-8') as f:
            data2 = json.load(f)
        
        if modificação == "apagar":
            del data2[divisor]
            
        if modificação == "nome":
            valor = data2[divisor]
            novo = {}

            for chave, valor_atual in data2.items():
                if chave == divisor:
                    novo[alterar] = valor
                else:
                    novo[chave] = valor_atual
            data2 = novo
        
        if modificação == "link":
            data2[divisor] = alterar
        
        if modificação == "adicionar":
            nome = alterar[0]
            if alterar[0] in data2:
                if f"{nome} [0]" in data2:
                    n = 0
                    for nomeindex in data2:
                        if nomeindex.replace(f" [{n}]") == nome:
                            n =+ 1

                    nome = f"{alterar[0]} [{n}]"
                else:
                    nome = f"{alterar[0]} [0]"

            data2[nome] = alterar[1]

        with open("divisores.json", "w", encoding='utf-8') as f:
            json.dump(data2, f, indent=4)

    class Salvar(discord.ui.Button):
        def __init__(self):
            super().__init__(label="Salvar",emoji=emojis.save, style=discord.ButtonStyle.gray)

        async def callback(self, interaction: discord.Interaction):
            await interaction.response.edit_message(content=f"{emojis.check} Divisores salvos com Sucesso!", embed=None, view=None)
            return
        
    class Apagar(discord.ui.Button):
        def __init__(self, divisor):
            super().__init__(emoji=emojis.trash, style=discord.ButtonStyle.gray)
            self.divisor = divisor

        async def callback(self, interaction: discord.Interaction):
            AlterarJson("apagar", self.divisor)
            await interaction.response.edit_message(embed=embeddivisores("embed"), view=EditarDiv("editar"))
            return

    class Nome(discord.ui.Button):
        def __init__(self, divisor):
            super().__init__(label="Altearar nome", emoji=emojis.ab, style=discord.ButtonStyle.gray)
            self.divisor = divisor

        async def callback(self, interaction: discord.Interaction):

            modal = ModalInput(title=f"DIGITE O NOVO NOME")
            modal.add_item(TextInput(label="NOME", placeholder=self.divisor,default=self.divisor,max_length=100, required=True))
            await interaction.response.send_modal(modal)
            await modal.wait()

            AlterarJson("nome", self.divisor, str(modal.children[0].value))
            embedD = discord.Embed(title=str(modal.children[0].value), color=0x2F3136)
            msg = await channel.fetch_message(data[str(modal.children[0].value)])
            embedD.set_image(url=msg.attachments[0].url)

            await interaction.edit_original_response(embed=embedD, view=EditarDiv("editare", str(modal.children[0].value)))

    class Voltar(discord.ui.Button):
        def __init__(self):
            super().__init__(label="Voltar", emoji=emojis.back, style=discord.ButtonStyle.gray)

        async def callback(self, interaction: discord.Interaction):
            await interaction.response.edit_message(embed=embeddivisores("embed"), view=EditarDiv("editar"))
            return

    class Adicionar(discord.ui.Button):
        def __init__(self):
            super().__init__(label="Adicionar divisor", emoji=emojis.adc, style=discord.ButtonStyle.green, disabled=False if len(data) < 20 else True)

        async def callback(self, interaction: discord.Interaction):
            await interaction.response.edit_message(content="")
            a = await interaction.followup.send("**Aguarde uns instantes...**", ephemeral=True)

            task = asyncio.create_task(bot.wait_for("message", check=lambda message: check_imagedivisor(message, interaction.user.id), timeout=300))
            class Cancelar(discord.ui.View):
                def __init__(self):
                    super().__init__(timeout=None)

                @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.gray)
                async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
                    task.cancel()

            msg = await channel.fetch_message(MessageIDs.DIVISOR_TEMPLATE)
            await interaction.followup.edit_message(a.id, content="Envie o divisor com o nome dele.\n**obs:** nome e divisor na mesma mensagem, ex:\n\nDivisor Exemplo", attachments=[await msg.attachments[0].to_file()], view=Cancelar())
            attachments = []
            try:
                if MessageIDs.DIVISOR_TEMPLATE:
                    msg = await channel.fetch_message(MessageIDs.DIVISOR_TEMPLATE)
                    if msg.attachments:
                        attachments = [await msg.attachments[0].to_file()]
            except (discord.NotFound, discord.HTTPException):
                pass

            await interaction.followup.edit_message(a.id, content="Envie o divisor com o nome dele.\n**obs:** nome e divisor na mesma mensagem, ex:\n\nDivisor Exemplo", attachments=attachments, view=Cancelar())

            try:
                messagedivisor = await task
                await messagedivisor.delete()
                await interaction.followup.edit_message(a.id, content="**Aguarde uns instantes...**", view=None, attachments=[])
            except asyncio.exceptions.CancelledError:
                await interaction.followup.edit_message(a.id, content="Ok, cancelei a adição do divisor pra você", view=None, attachments=[])
                return
            except discord.errors.HTTPException:
                await interaction.followup.edit_message(a.id, content="Não foi possivel adicionar o seu divisor pois ele é muito grande", view=None, attachments=[])
                return
            except Exception as e:
                await interaction.followup.edit_message(a.id, content=f"Não foi possivel adicionar o seu divisor, erro:\n```python\n{e}\n```", view=None, attachments=[])
                return

            msgid = await channel.send(content=messagedivisor.content[:100],file=await messagedivisor.attachments[0].to_file())
            AlterarJson(modificação="adicionar", alterar=[messagedivisor.content[:100], msgid.id])
            await interaction.edit_original_response(embed=embeddivisores("embed"), view=EditarDiv("editar"))
            await interaction.followup.edit_message(a.id, content=f"{emojis.check} Pronto, seu divisor foi adicionado com sucesso!")

    class AdicionarPack(discord.ui.Button):
        def __init__(self):
            super().__init__(label="Adicionar Pack (4)", emoji=emojis.adc, style=discord.ButtonStyle.blurple, disabled=False if len(data) < 17 else True)

        async def callback(self, interaction: discord.Interaction):
            await interaction.response.edit_message(content="")
            a = await interaction.followup.send("**Aguarde uns instantes...**", ephemeral=True)

            task = asyncio.create_task(bot.wait_for("message", check=lambda message: check_imagedivisor(message, interaction.user.id), timeout=300))
            class Cancelar(discord.ui.View):
                def __init__(self):
                    super().__init__(timeout=None)

                @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.gray)
                async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
                    task.cancel()

            attachments = []
            try:
                if MessageIDs.DIVISOR_TEMPLATE:
                    msg = await channel.fetch_message(MessageIDs.DIVISOR_TEMPLATE)
                    if msg.attachments:
                        attachments = [await msg.attachments[0].to_file()]
            except (discord.NotFound, discord.HTTPException):
                pass

            await interaction.followup.edit_message(a.id, content="Envie a imagem contendo os 4 divisores e o nome base.\n**obs:** nome e imagem na mesma mensagem. A imagem será dividida em 4 partes iguais verticalmente.", attachments=attachments, view=Cancelar())

            try:
                messagedivisor = await task
                image_data = await messagedivisor.attachments[0].read()
                await messagedivisor.delete()
                await interaction.followup.edit_message(a.id, content="**Processando imagem...**", view=None, attachments=[])
            except asyncio.exceptions.CancelledError:
                await interaction.followup.edit_message(a.id, content="Ok, cancelei a adição do pack para você", view=None, attachments=[])
                return
            except Exception as e:
                await interaction.followup.edit_message(a.id, content=f"Erro: {e}", view=None, attachments=[])
                return

            try:
                img = Image.open(BytesIO(image_data))
                w, h = img.size
                ph = h // 4
                base = messagedivisor.content[:90]
                
                for i in range(4):
                    crop = img.crop((0, i*ph, w, (i+1)*ph))
                    with BytesIO() as output:
                        crop.save(output, format="PNG")
                        output.seek(0)
                        msgid = await channel.send(content=f"{base} {i+1}", file=discord.File(output, filename=f"div_{i}.png"))
                        AlterarJson(modificação="adicionar", alterar=[f"{base} {i+1}", msgid.id])
                
                await interaction.edit_original_response(embed=embeddivisores("embed"), view=EditarDiv("editar"))
                await interaction.followup.edit_message(a.id, content=f"{emojis.check} Pack de divisores adicionado com sucesso!")
            except Exception as e:
                await interaction.followup.edit_message(a.id, content=f"Erro ao processar: {e}")

    class divisores(discord.ui.Select):
        def __init__(self):
            super().__init__(
                placeholder="Selecione uma opção para editar...",
                min_values=1,
                max_values=1,
                options=embeddivisores("op"),
                )

        async def callback(self, interaction: discord.Interaction):
            embed = embeddivisores("embed")
            msg = await channel.fetch_message(embed.fields[int(self.values[0]) - 1].value.replace("ID Divisor: ", ""))
            embedD = discord.Embed(title=embed.fields[int(self.values[0])  - 1].name, color=0x2F3136)
            embedD.set_image(url=msg.attachments[0].url)
            await interaction.response.edit_message(embed=embedD, view=EditarDiv("editare", embed.fields[int(self.values[0]) - 1].name.replace("ㅤ", "")))

    await interaction.response.send_message(embed=embed, view=EditarDiv("editar"), ephemeral=True)

class DLButton2(discord.ui.View):
    def __init__(self, link, tipo):
        super().__init__(timeout=None)
        self.add_item(discord.ui.Button(label=tipo, url=link))

class DLButton(discord.ui.View):
    def __init__(self, txd, dff, zip):
        super().__init__(timeout=None)
        if zip is None:
            self.add_item(discord.ui.Button(label="TXD", url=txd))
            self.add_item(discord.ui.Button(label="DFF", url=dff))
        else:
            self.add_item(discord.ui.Button(label="ZIP", url=zip))

class StaticOrAnimatedMenu(discord.ui.Select):
    with open("divisores.json", "r", encoding='utf-8') as f:
        data = json.load(f)
        
    OPTIONS = data
    def __init__(self, txd, dff, zip, private_user, messageimagem, nomeaba, thread, ver, selected, file):
        options = [
            discord.SelectOption(value=key, label=key) for key in self.OPTIONS.keys()
        ]
        if ver:
            options.append(discord.SelectOption(value="voltar", label="Voltar", emoji=emojis.back))
        super().__init__(
            placeholder="Selecione uma opção...",
            min_values=1,
            max_values=1,
            options=options,
        )

        self.txd = txd
        self.dff = dff
        self.zip = zip
        
        self.private_user = private_user
        self.messageimagem = messageimagem
        self.nomeaba = nomeaba
        self.thread = thread
        self.ver = ver
        self.selected = selected
        self.file = file

    async def callback(self, interaction: discord.Interaction):
        from settings.check import Bot as bot
        channel = bot.get_channel(ChannelIDs.DIVISORES)

        txd = self.txd
        dff = self.dff
        zip = self.zip
        
        private_user = self.private_user
        messageimagem = self.messageimagem
        nomeaba = self.nomeaba
        thread = self.thread
        ver = self.ver
        selected = self.selected
        file = self.file

        iduser = int(interaction.user.id)
        embedselected = embeds[iduser]["embedselected"]
        embedpost = embeds[iduser]["embedpost"]

        if self.values[0] == "voltar":
            await interaction.response.edit_message(embeds=[embedpost, embedselected], view=EditView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))
            return
        else:
            msg = await channel.fetch_message(self.OPTIONS.get(self.values[0]))
            embedselected.set_image(url=msg.attachments[0].url)
            embeds[iduser] = {"embedpost": embedpost, "embedselected": embedselected, "file": msg}
            file = msg

            if ver == False:
                await interaction.response.edit_message(content=f"**ESCOLHIDO {selected}!**\nDeseja visualizar um preview do seu post?", view=Preview(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected), embeds=[])
            if ver == True:
                iduser = int(interaction.user.id)
                await interaction.response.edit_message(embeds=[embedpost, embedselected], view=EditView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))
                await interaction.followup.send("**DIVISOR** editado!", ephemeral=True)
        
class StaticOrAnimated(discord.ui.View):
    def __init__(self, txd, dff, zip, private_user, messageimagem, nomeaba, thread, ver, selected, file):
        super().__init__(timeout=None)

        self.add_item(StaticOrAnimatedMenu(txd, dff, zip, private_user, messageimagem, nomeaba, thread, ver, selected, file))

class ConfirmEnvio(discord.ui.Button):
    def __init__(self, txd, dff, zip, thread, file):
        super().__init__(label="Enviar (postar)", style=discord.ButtonStyle.green, row=2)
        self.txd = txd
        self.dff = dff
        self.zip = zip
        self.thread = thread
        self.file = file

    async def callback(self, interaction: discord.Interaction):
        txd = self.txd
        dff = self.dff
        zip = self.zip
        thread = self.thread
        file = self.file
        
        iduser = int(interaction.user.id)
        embedpost = embeds[iduser]["embedpost"]
        await interaction.response.edit_message(content="**Aguarde uns instantes...**", embeds=[], view=None)

        await thread.send(embed=embedpost, view=DLButton(txd, dff, zip))
        a = await thread.send(file=await file.attachments[0].to_file())
        await atualizarjson("adc")

        class Ir(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(label="Ir para o post", url=a.jump_url))

        await interaction.edit_original_response(content="Pronto, seu post foi publicado! :)", view=Ir())
        embeds[iduser] = {}
        
class Edit(discord.ui.Button):
    def __init__(self, txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected):
        super().__init__(label="Editar", style=discord.ButtonStyle.gray, row=2)
        self.txd = txd
        self.dff = dff
        self.zip = zip
        
        self.private_user = private_user
        self.messageimagem = messageimagem
        self.nomeaba = nomeaba
        self.thread = thread
        self.file = file
        self.selected = selected

    async def callback(self, interaction: discord.Interaction):

        txd = self.txd
        dff = self.dff
        zip = self.zip
        
        private_user = self.private_user
        messageimagem = self.messageimagem
        nomeaba = self.nomeaba
        thread = self.thread
        file = self.file
        selected = self.selected
        iduser = int(interaction.user.id)

        await interaction.response.edit_message(view=EditView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))

class PreviewView(discord.ui.View):
    def __init__(self, txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected):
        super().__init__(timeout=None)
        self.add_item(ConfirmEnvio(txd, dff, zip, thread, file))
        self.add_item(Edit(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected))
        if zip is None:
            self.add_item(discord.ui.Button(label="TXD", url=txd, row=1))
            self.add_item(discord.ui.Button(label="DFF", url=dff, row=1))
        else:
            self.add_item(discord.ui.Button(label="ZIP", url=zip, row=1))
        
class Preview(discord.ui.View):
    def __init__(self, txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected):
        super().__init__(timeout=None)

        self.txd = txd
        self.dff = dff
        self.zip = zip
        
        self.private_user = private_user
        self.messageimagem = messageimagem
        self.nomeaba = nomeaba
        self.thread = thread
        self.file = file
        self.selected = selected
    
    @discord.ui.button(label="Sim (editar)", style=discord.ButtonStyle.gray)
    async def SimPreview(self, interaction: discord.Interaction, button: discord.ui.Button):

        txd = self.txd
        dff = self.dff
        zip = self.zip
        
        private_user = self.private_user
        messageimagem = self.messageimagem
        nomeaba = self.nomeaba
        thread = self.thread
        file = self.file
        selected = self.selected
        iduser = int(interaction.user.id)
        embedselected = embeds[iduser]["embedselected"]
        embedpost = embeds[iduser]["embedpost"]

        await interaction.response.edit_message(content="Este é um preview do seu post", embeds=[embedpost, embedselected], view=PreviewView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected))

    @discord.ui.button(label="Não (enviar)", style=discord.ButtonStyle.gray)
    async def NãoPreview(self, interaction: discord.Interaction, button: discord.ui.Button):
        from settings.check import Bot
        bot = Bot

        txd = self.txd
        dff = self.dff
        zip = self.zip
        thread = self.thread
        file = self.file
        
        iduser = int(interaction.user.id)
        embedpost = embeds[iduser]["embedpost"]
        await interaction.response.edit_message(content="**Aguarde uns instantes...**", embeds=[], view=None)

        await thread.send(embed=embedpost, view=DLButton(txd, dff, zip))
        a = await thread.send(file=await file.attachments[0].to_file())
        await atualizarjson("adc")

        class Ir(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(label="Ir para o post", url=a.jump_url))

        await interaction.edit_original_response(content="Pronto, seu post foi publicado! :)", view=Ir())
        embeds[iduser] = {}

class EditMenu(discord.ui.Select):
    def __init__(self, txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser):
        embedpost = embeds[iduser]["embedpost"]
        desc = str(embedpost.description)
        select = selected
        options = [
            discord.SelectOption(value="creditos",label="Créditos", description=desc or "Adicione ou remova os créditos"),
            discord.SelectOption(value="txd e dff",label="TXD e DFF", description=f"TXD e DFF da {str(nomeaba)}"),
            discord.SelectOption(value="imagem",label="Imagem", description=f"Imagem da {str(nomeaba)}"),
            discord.SelectOption(value="divider",label="Divisor", description=f"{select}"),
            discord.SelectOption(value="voltar",label="Voltar", emoji=emojis.back),
        ]
        super().__init__(
            placeholder="Selecione uma opção...",
            min_values=1,
            max_values=1,
            options=options,
            row=2
        )

        self.txd = txd
        self.dff = dff
        self.zip = zip
        
        self.private_user = private_user
        self.messageimagem = messageimagem
        self.nomeaba = nomeaba
        self.thread = thread
        self.file = file
        self.selected = selected

    async def callback(self, interaction: discord.Interaction):
        from settings.check import Bot
        bot = Bot

        txd = self.txd
        dff = self.dff
        zip = self.zip
        
        private_user = self.private_user
        messageimagem = self.messageimagem
        nomeaba = self.nomeaba
        thread = self.thread
        file = self.file
        selected = self.selected

        iduser = int(interaction.user.id)
        embedselected = embeds[iduser]["embedselected"]
        embedpost = embeds[iduser]["embedpost"]

        iduser = int(interaction.user.id)
        task1 = asyncio.create_task(bot.wait_for("message", check=lambda message: dfftxdcheck(message, iduser)))
        task2 = asyncio.create_task(bot.wait_for("message", check=lambda message: check_image(message, iduser), timeout=300))

        class CancelarA(discord.ui.View):
            def __init__(self, vertxdorimage):
                super().__init__(timeout=None)
                self.vertxdorimage = vertxdorimage

            @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.gray)
            async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
                vertxdorimage = self.vertxdorimage

                if vertxdorimage == "txd":
                    task1.cancel()
                if vertxdorimage == "image":
                    task2.cancel()


        if self.values[0] == "creditos":
            dft = str(embedpost.description).replace("**・CRÉDITOS:**", "")
            modalC = ModalInput(title=f"EDITE OS CRÉDITOS DO POST")
            modalC.add_item(TextInput(label="EDITE OS CRÉDITOS", placeholder="Para quem vai os créditos da criação do mod?", default=dft or "" , max_length=100, required=False))
            await interaction.response.send_modal(modalC)
            await modalC.wait()
            embedselected = embeds[iduser]["embedselected"]
            embedpost = embeds[iduser]["embedpost"]

            if str(modalC.children[0]) == "":
                embedpost.description = ""
            else:
                embedpost.description = f"**・CRÉDITOS:** {str(modalC.children[0])}"

            await interaction.edit_original_response(embeds=[embedpost, embedselected], view=EditView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))
            await interaction.followup.send("Créditos editados!", ephemeral=True)
        
        if self.values[0] == "txd e dff":
            
            await interaction.response.edit_message(embeds=[embedpost, embedselected], view=EditView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))
            vertxdorimage = "txd"
            a = await interaction.followup.send(f"Me envie aqui o **TXD** e **DFF** ou o arquivo **ZIP** da **{str(nomeaba)}**\n**obs**: txd e dff em apenas uma mensagem (tudo junto)\n**obs²**: o zip deve conter apenas o txd e o dff\n**obs³**: o limite máximo do arquivo deve ser de 25mb", view=CancelarA(vertxdorimage), ephemeral=True)
            
            try:
                messagetxdedff = await task1
                await messagetxdedff.delete()
                await interaction.followup.edit_message(a.id, content="**Aguarde uns instantes...**", view=None)
            except asyncio.exceptions.CancelledError:
                await interaction.followup.edit_message(a.id, content="Ok, cancelei a edição do **TXD** e **DFF** para você.", view=None)
                await interaction.edit_original_response(embeds=[embedpost, embedselected], view=EditView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))
                return
            
            txd_link = None
            dff_link = None
            zip_link = None

            if messagetxdedff.attachments[0].filename.endswith(".zip"):
                bot_dir = os.path.dirname(os.path.abspath("funcoes"))
                with tempfile.TemporaryDirectory(dir=bot_dir) as tmpdir:
                    file_path = os.path.join(bot_dir, messagetxdedff.attachments[0].filename)
                    await messagetxdedff.attachments[0].save(file_path)
                    with zipfile.ZipFile(file_path) as zip_file:
                        file_list = zip_file.namelist()
                        if len(file_list) == 2:
                            ext1 = os.path.splitext(file_list[0])[1][1:]
                            ext2 = os.path.splitext(file_list[1])[1][1:]
                            dff_file = None
                            txd_file = None
                            if ext1 == 'dff' and ext2 == 'txd' or ext1 == 'txd' and ext2 == 'dff':
                                user_folder_path = os.path.join(bot_dir, str(interaction.user.id))
                                os.makedirs(user_folder_path, exist_ok=True)
                                zip_file.extractall(path=user_folder_path)
                                zip_file.close()
                                for file_name in file_list:
                                    if file_name.endswith('.dff'):
                                        dff_file = os.path.join(user_folder_path, file_name)
                                    elif file_name.endswith('.txd'):
                                        txd_file = os.path.join(user_folder_path, file_name)
                                try:
                                    with open(dff_file, "rb") as f: dff_bytes = f.read()
                                    with open(txd_file, "rb") as f: txd_bytes = f.read()
                                    dff_link = await upload_to_github(dff_bytes, f"{int(time.time())}_{iduser}_mod.dff", "mods/dff", interaction)
                                    txd_link = await upload_to_github(txd_bytes, f"{int(time.time())}_{iduser}_mod.txd", "mods/txd", interaction)
                                except:
                                    with open(file_path, "rb") as f: zip_bytes = f.read()
                                    zip_link = await upload_to_github(zip_bytes, f"{int(time.time())}_{iduser}_mod.zip", "mods/zips", interaction)

                                shutil.rmtree(user_folder_path)
                                os.remove(file_path)
                            else:
                                await interaction.followup.edit_message(a.id, content=f"Este arquivo **ZIP** contém algo errado. Tente novamente.\n**obs:** envie apenas os arquivos **txd e dff** dentro do **zip**")
                                os.remove(file_path)
                                return
                        else:
                            await interaction.followup.edit_message(a.id, content=f"Este arquivo **ZIP** contém algo errado. Tente novamente.\n**obs:** envie apenas os arquivos **txd e dff** dentro do **zip**")
                            os.remove(file_path)
                            return
						
            
            else:
                txd_attachment = None
                dff_attachment = None
                for attachment in messagetxdedff.attachments:
                    if attachment.filename.endswith(".txd"):
                        txd_attachment = attachment
                    elif attachment.filename.endswith(".dff"):
                        dff_attachment = attachment

                txd_bytes = await txd_attachment.read()
                dff_bytes = await dff_attachment.read()
                
                txd_link = await upload_to_github(txd_bytes, f"{int(time.time())}_{iduser}_mod.txd", "mods/txd", interaction)
                dff_link = await upload_to_github(dff_bytes, f"{int(time.time())}_{iduser}_mod.dff", "mods/dff", interaction)

            txd = txd_link
            dff = dff_link
            zip = zip_link
            
            await interaction.edit_original_response(embeds=[embedpost, embedselected], view=EditView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))
            await interaction.followup.edit_message(a.id, content="**TXD** e **DFF** editados!", view=None)

        if self.values[0] == "imagem":
            await interaction.response.edit_message(embeds=[embedpost, embedselected], view=EditView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))
            vertxdorimage = "image"
            a = await interaction.followup.send(content=f"Me envie agora a **IMAGEM** da **{str(nomeaba)}**\n**obs**: apenas imagens png ou jpg", view=CancelarA(vertxdorimage), ephemeral=True)
            
            try:
                messageimagem = await task2
                image_data = await messageimagem.attachments[0].read()
                filename = messageimagem.attachments[0].filename
                await messageimagem.delete()
            except asyncio.exceptions.CancelledError:
                await interaction.followup.edit_message(a.id, content="Ok, cancelei a edição da **IMAGEM** para você.", view=None)
                await interaction.edit_original_response(embeds=[embedpost, embedselected], view=EditView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))
                return
            
            imagem_url = await upload_to_github(image_data, f"{int(time.time())}_{iduser}_preview.png", "mods/previews", interaction)
            embedpost.set_image(url=imagem_url)

            await interaction.edit_original_response(embeds=[embedpost, embedselected], view=EditView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))
            await interaction.followup.edit_message(a.id, content="**IMAGEM** editada!", view=None)

        if self.values[0] == "divider":
            ver = True
            await interaction.response.edit_message(embeds=[embeddivederss], view=StaticOrAnimated(txd, dff, zip, private_user, messageimagem, nomeaba, thread, ver, selected, file))

        if self.values[0] == "voltar":
            await interaction.response.edit_message(view=PreviewView(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected))

class EditView(discord.ui.View):
    def __init__(self, txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser):
        super().__init__(timeout=None)

        self.add_item(EditMenu(txd, dff, zip, private_user, messageimagem, nomeaba, thread, file, selected, iduser))
        if zip is None:
            self.add_item(discord.ui.Button(label="TXD", url=txd, row=1))
            self.add_item(discord.ui.Button(label="DFF", url=dff, row=1))
        else:
            self.add_item(discord.ui.Button(label="ZIP", url=zip, row=1))

class Post(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(CriarPost())

class CriarPost(discord.ui.Button):
    def __init__(self):
        super().__init__(emoji=emojis.plus,label="・Realizar Post", style=discord.ButtonStyle.green, custom_id="CriarPost")

    async def callback(self, interaction: discord.Interaction):
        role_postador = interaction.guild.get_role(RoleIDs.POSTADOR)
        
        if not role_postador:
             await interaction.response.send_message("O cargo de postador não está configurado corretamente no servidor.", ephemeral=True)
             return
             
        if role_postador not in interaction.user.roles:
            await interaction.response.send_message(f"Você precisa do cargo {role_postador.mention} para realizar posts.", ephemeral=True)
            return

        view = DropdownView(interaction.guild)
        # Verifica se o menu está desativado (significa que nenhum canal foi encontrado)
        select_menu = view.children[0]
        if select_menu.disabled:
             await interaction.response.send_message(f"⚠️ **Erro de Configuração**\nNão encontrei nenhum canal nas categorias configuradas.\nIDs procurados: `{CategoryIDs.POSTS}`\nVerifique se os IDs estão corretos e se o bot tem permissão de ver esses canais.", ephemeral=True)
             return

        await interaction.response.send_message(view=view, ephemeral=True)

class DropdownBack(discord.ui.Select):
    def __init__(self, guild):
        channels = []
        # Usa CategoryIDs.POSTS diretamente para garantir que está pegando os valores mais recentes
        current_category_ids = CategoryIDs.POSTS
        
        if guild:
            for category_id in current_category_ids:
                channel_or_category = guild.get_channel(category_id)
                if channel_or_category:
                    if isinstance(channel_or_category, discord.CategoryChannel):
                        channels.extend(channel_or_category.channels)
                    elif isinstance(channel_or_category, (discord.TextChannel, discord.ForumChannel)):
                        channels.append(channel_or_category)

        filtered_channels = [channel for channel in channels if channel.id != ChannelIDs.POST_IGNORED]
        # Limita a 25 opções (limite do Discord) e corta nomes longos
        opções = [discord.SelectOption(label=channel.name[:100], value=str(channel.id)) for channel in filtered_channels[:25]]
        
        if not opções:
            opções = [discord.SelectOption(label="Nenhum canal encontrado", value="none")]

        super().__init__(
            placeholder="Selecione um Canal...",
            min_values=1,
            max_values=1,
            options=opções,
            disabled=True if opções[0].value == "none" else False
        )
    async def callback(self, interaction: discord.Interaction):
        if self.values[0] == "none":
            return

        select = interaction.guild.get_channel(int(self.values[0]))
        iduser = int(interaction.user.id)
        if select.category_id in category_ids_threads and select.id not in [ChannelIDs.POST_SPECIAL_3, ChannelIDs.POST_SOUND_SPECIAL]:
            threads = []
            threads_menu = [select.threads]
            for thread in threads_menu:
                threads.extend(thread)
            options = [discord.SelectOption(label=thread.name, value=str(thread.id)) for thread in threads]
            options.append(discord.SelectOption(label="Voltar", value="back", emoji=emojis.back))
            await interaction.response.edit_message(view=selectchannelview(options))
            return

        else:
            embedselected = discord.Embed(colour=0x2f3136)
            if select.id == ChannelIDs.POST_FIST_SPECIAL:
                ver = "fist false"
                embeds[iduser] = {"embedpost": "", "thread": select, "buttons": "", "embedselected": embedselected, "file": None, "ver": ver}
                await fistpost(interaction)
                return
            if select.id == ChannelIDs.POST_SOUND_SPECIAL:
                ver = "sound false"
                embeds[iduser] = {"thread": select, "ver": ver, "sound1": "", "sound2": "", "file": None, "selected": "", "embedselected": embedselected, "creditossound": "False"}
                await soundpost(interaction)
                return
            else:
                nomeaba = str(select.name)
                ver = False
                embeds[iduser] = {"embedpost": "", "embedselected": "", "linkdl": "", "tipolink": "", "selected": "", "nomeaba": "", "thread": select, "tipod":  "", "créditos": "", "demonstração": "", "senha": "", "infosadc": ""}
                tipod = creditosd = linkdd = senhad = ""
                await infospost(interaction, nomeaba, ver, tipod, creditosd, linkdd, senhad)
                return

class DropdownView(discord.ui.View):
    def __init__(self, guild):
        super().__init__(timeout=None)

        self.add_item(DropdownBack(guild))

class selectchannel(discord.ui.Select):
    def __init__(self, options):
        super().__init__(
            placeholder="Selecione uma Thread...",
            options=options,
            min_values=1,
            max_values=1
        )

    async def callback(self, interaction: discord.Interaction):
        from settings.check import Bot
        bot = Bot
        if self.values[0] == "back":
            await interaction.response.edit_message(view=DropdownView(interaction.guild))

        else:
            private_user = await bot.fetch_user(UserIDs.FIST_RECEIVER)
            thread = interaction.guild.get_thread(int(self.values[0]))
            if thread.category_id == CategoryIDs.SOUNDS:
                nomeaba = thread.name.replace("⠂", "")
                task = asyncio.create_task(bot.wait_for("message", check=lambda message: dfftxdcheck(message, iduser), timeout=300))
                class CancelarA(discord.ui.View):
                    def __init__(self):
                        super().__init__(timeout=None)

                    @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.gray)
                    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
                        task.cancel()
                
                await interaction.response.edit_message(content=f"Me envie aqui o **TXD** e **DFF** ou o arquivo **ZIP** da **{str(nomeaba)}**\n**obs**: txd e dff em apenas uma mensagem (tudo junto)\n**obs²**: o zip deve conter apenas o txd e o dff\n**obs³**: o limite máximo do arquivo deve ser de 25mb", view=CancelarA())

                iduser=int(interaction.user.id)
                
                try:
                    messagetxdedff = await task
                    await messagetxdedff.delete()
                    await interaction.edit_original_response(content=f"**Aguarde uns instantes...**", view=None)
                except asyncio.TimeoutError:
                    await interaction.edit_original_response(content=f"Tempo limite excedido. Tente novamente.", view=DropdownView(interaction.guild))
                    return
                except asyncio.exceptions.CancelledError:
                    await interaction.edit_original_response(content="Ok, cancelei o **post** para você.", view=None)
                    embeds[iduser] = {}
                    return
                except:
                    return

                txd_link = None
                dff_link = None
                zip_link = None

                if messagetxdedff.attachments[0].filename.endswith(".zip"):
                    bot_dir = os.path.dirname(os.path.abspath("funcoes"))
                    with tempfile.TemporaryDirectory(dir=bot_dir) as tmpdir:
                        file_path = os.path.join(bot_dir, messagetxdedff.attachments[0].filename)
                        await messagetxdedff.attachments[0].save(file_path)
                        with zipfile.ZipFile(file_path) as zip_file:
                            file_list = zip_file.namelist()
                            if len(file_list) == 2:
                                ext1 = os.path.splitext(file_list[0])[1][1:]
                                ext2 = os.path.splitext(file_list[1])[1][1:]
                                dff_file = None
                                txd_file = None
                                if ext1 == 'dff' and ext2 == 'txd' or ext1 == 'txd' and ext2 == 'dff':
                                    user_folder_path = os.path.join(bot_dir, str(interaction.user.id))
                                    os.makedirs(user_folder_path, exist_ok=True)
                                    zip_file.extractall(path=user_folder_path)
                                    zip_file.close()
                                    for file_name in file_list:
                                        if file_name.endswith('.dff'):
                                            dff_file = os.path.join(user_folder_path, file_name)
                                        elif file_name.endswith('.txd'):
                                            txd_file = os.path.join(user_folder_path, file_name)
                                    try:
                                        with open(dff_file, "rb") as f: dff_bytes = f.read()
                                        with open(txd_file, "rb") as f: txd_bytes = f.read()
                                        dff_link = await upload_to_github(dff_bytes, f"{int(time.time())}_{iduser}_mod.dff", "mods/dff", interaction)
                                        txd_link = await upload_to_github(txd_bytes, f"{int(time.time())}_{iduser}_mod.txd", "mods/txd", interaction)
                                    except:
                                        with open(file_path, "rb") as f: zip_bytes = f.read()
                                        zip_link = await upload_to_github(zip_bytes, f"{int(time.time())}_{iduser}_mod.zip", "mods/zips", interaction)

                                    shutil.rmtree(user_folder_path)
                                    os.remove(file_path)
                                else:
                                    await interaction.edit_original_response(content=f"Este arquivo **ZIP** contém algo errado. Tente novamente.\n**obs:** envie apenas os arquivos **txd e dff** dentro do **zip**")
                                    os.remove(file_path)
                                    return
                            else:
                                await interaction.edit_original_response(content=f"Este arquivo **ZIP** contém algo errado. Tente novamente.\n**obs:** envie apenas os arquivos **txd e dff** dentro do **zip**")
                                os.remove(file_path)
                                return
                
                else:
                    txd_attachment = None
                    dff_attachment = None
                    for attachment in messagetxdedff.attachments:
                        if attachment.filename.endswith(".txd"):
                            txd_attachment = attachment
                        elif attachment.filename.endswith(".dff"):
                            dff_attachment = attachment

                    txd_bytes = await txd_attachment.read()
                    dff_bytes = await dff_attachment.read()
                    
                    txd_link = await upload_to_github(txd_bytes, f"{int(time.time())}_{iduser}_mod.txd", "mods/txd", interaction)
                    dff_link = await upload_to_github(dff_bytes, f"{int(time.time())}_{iduser}_mod.dff", "mods/dff", interaction)

                txd = txd_link
                dff = dff_link
                zip = zip_link

                await interaction.edit_original_response(content=f"Me envie agora a **IMAGEM** da **{str(nomeaba)}**\n**obs**: apenas imagens png ou jpg", view=CancelarA())

                task = asyncio.create_task(bot.wait_for("message", check=lambda message: check_image(message, iduser), timeout=300))
                try:
                    messageimagem = await task
                    image_data = await messageimagem.attachments[0].read()
                    filename = messageimagem.attachments[0].filename
                    await messageimagem.delete()
                    await interaction.edit_original_response(content=f"**Aguarde uns instantes...**", view=None)
                except asyncio.TimeoutError:
                    await interaction.edit_original_response(content=f"Tempo limite excedido. Tente novamente.", view=DropdownView(interaction.guild))
                    return
                except asyncio.exceptions.CancelledError:
                    await interaction.edit_original_response(content="Ok, cancelei o **post** para você.", view=None)
                    embeds[iduser] = {}
                    return
                except:
                    return

                imagem_url = await upload_to_github(image_data, f"{int(time.time())}_{iduser}_preview.png", "mods/previews", interaction)

                embedpost = discord.Embed(colour=0x383d42)
                embedselected = discord.Embed(colour=0x2f3136)
                embedpost.set_image(url=imagem_url)
                embedpost.set_footer(text=f"{interaction.user.id}")
                embeds[iduser] = {"embedpost": embedpost, "embedselected": embedselected}
                
                weapon_urls = imagenspainel.weapons

                arma = weapon_urls.get(nomeaba, None)
                if arma is not None:
                    embedpost.set_thumbnail(url=arma)
                try:
                    embedpost.set_author(name=f"{interaction.user.name}", icon_url=f"{interaction.user.avatar.url}")
                except:
                    embedpost.set_author(name=f"{interaction.user.name}", icon_url=imagenspainel.author_icon_default)
                        
                class Sim(discord.ui.View):
                    def __init__(self):
                        super().__init__(timeout=None)

                    @discord.ui.button(label="Sim, adicionar créditos", style=discord.ButtonStyle.gray, emoji=emojis.sim)
                    async def Sim(self, interaction: discord.Interaction, button: discord.ui.Button):
                        modal = ModalInput(title=f"CRÉDITOS DA {nomeaba}")
                        modal.add_item(TextInput(label="CRÉDITOS", placeholder="De quem é os créditos da criação do mod?", max_length=100, required=True))
                        await interaction.response.send_modal(modal)
                        await modal.wait()

                        iduser = int(interaction.user.id)
                        embed = embeds[iduser]["embedpost"]

                        embed.description= f"**・CRÉDITOS:** {str(modal.children[0])}"
                        ver = False
                        selected = ""
                        file = ""
                        await interaction.edit_original_response(content="**Adicionado!**\nAgora escolha o divisor abaixo:", embeds=[embeddivederss], view=StaticOrAnimated(txd, dff, zip, private_user, messageimagem, nomeaba, thread, ver, selected, file))
                    
                    @discord.ui.button(label="Não", style=discord.ButtonStyle.gray, emoji=emojis.nao)
                    async def Não(self, interaction: discord.Interaction, button: discord.ui.Button):
                        ver = False
                        embedpost.description = ""
                        selected = ""
                        file = ""
                        await interaction.response.edit_message(content="Ok, Escolha um divisor abaixo:", embeds=[embeddivederss], view=StaticOrAnimated(txd, dff, zip, private_user, messageimagem, nomeaba, thread, ver, selected, file))

                await interaction.edit_original_response(content=f"**Tudo certo!**\nQuer adicionar créditos da {str(nomeaba).lower()}?", view=Sim())
                
            else:   
                nomeaba = thread.name.replace("⠂", "")
                ver = False
                iduser = int(interaction.user.id)
                embeds[iduser] = {"embedpost": "", "embedselected": "", "linkdl": "", "tipolink": "", "selected": "", "nomeaba": "", "thread": thread, "tipod":  "", "créditos": "", "demonstração": "", "senha": "", "infosadc": ""}
                tipod = creditosd = linkdd = senhad = ""
                await infospost(interaction, nomeaba, ver, tipod, creditosd, linkdd, senhad)


async def arquivos(interaction: discord.Interaction, ver):
    from settings.check import Bot
    bot = Bot
    iduser = int(interaction.user.id)
    task = asyncio.create_task(bot.wait_for("message", check=lambda message: check_zip(message, iduser), timeout=300))
    tipo, select, embedselected, embedpost = [embeds[iduser]["tipolink"], embeds[iduser]["selected"], embeds[iduser]["embedselected"], embeds[iduser]["embedpost"]]
    
    class Cancelar(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=None)

        @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.gray)
        async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
            task.cancel()

    if ver == False:
        await interaction.response.edit_message(content="Me envie agora o **ARQUIVO ZIPADO** ou o **LINK** para download\n**obs links**: só aceito links do **Google Drive** ou **Mediafire**.\n**obs arquivo zipado**: só aceito arquivos com menos de **25MB**", view=Cancelar())
    else:
        a = await interaction.followup.send("Me envie agora o **ARQUIVO ZIPADO** ou o **LINK** para download\n**obs links**: só aceito links do **Google Drive** ou **Mediafire**.\n**obs arquivo zipado**: só aceito arquivos com menos de **25MB**", view=Cancelar(), ephemeral=True)
    
    try:
        messagezip = await task
        zip_data = None
        zip_filename = None
        if messagezip.attachments:
            zip_data = await messagezip.attachments[0].read()
            zip_filename = messagezip.attachments[0].filename
        
        zip_content = messagezip.content
        await messagezip.delete()
        if ver == False:
            await interaction.edit_original_response(content=f"**Aguarde uns instantes...**", view=None)
        else:
            await interaction.followup.edit_message(a.id, content=f"**Aguarde uns instantes...**", view=None)
    except asyncio.TimeoutError:
        if ver == False:
            await interaction.edit_original_response(content=f"Tempo limite excedido. Tente novamente.", view=DropdownView(interaction.guild))
        else:
            await interaction.followup.edit_message(a.id, content=f"Tempo limite excedido. Tente novamente.", view=None)
            await interaction.edit_original_response(view=EditView2(link, tipo, select), embeds=[embedpost, embedselected])
        return
    except asyncio.exceptions.CancelledError:
        if ver == True:
            await interaction.followup.edit_message(a.id, content="Ok, cancelei a edição do **DOWNLOAD** para você.", view=None)
            await interaction.edit_original_response(view=EditView2(link, tipo, select), embeds=[embedpost, embedselected])
            return
        else:
            await interaction.edit_original_response(content="Ok, cancelei o **post** para você.", view=None)
            embeds[iduser] = {}
            return
    except:
        return
    
    private_user = await bot.fetch_user(UserIDs.FIST_RECEIVER)
    zip_link = None
    
    try:
        if zip_data:
            zip_link = await upload_to_github(zip_data, f"{int(time.time())}_{iduser}_download.zip", "mods/zips", interaction)
            tipo = "DOWNLOAD"
        else:
            raise Exception
    except:
        zip_link =  zip_content
        if re.search('drive\\.google\\.com', zip_link):
            tipo = "DOWNLOAD (Google Drive)"
        else:
            tipo = "DOWNLOAD (Mediafire)"

    embeds[iduser]["linkdl"] = zip_link
    embeds[iduser]["tipolink"] = tipo

    if ver == False:
        await interaction.edit_original_response(content="Quer adicionar alguma informação adicional a este post? **(como utilizar, oque tem no post, etc...)**", view=Info())
    else:
        link = embeds[iduser]["linkdl"]
        tipo = embeds[iduser]["tipolink"]
        await interaction.edit_original_response(embeds=[embedpost, embedselected], view=EditView2(link, tipo, select))
        await interaction.followup.edit_message(a.id, content="**DOWNLOAD** editado!")

async def infospost(interaction: discord.Interaction, nomeaba, ver, tipod, creditosd, linkdd, senhad):

    class Modal(discord.ui.Modal, title=f"DETALHES DE SEU POST NA ABA {nomeaba}"):
                
        tipo = TextInput(label="TIPO", placeholder="ex: APK, DATA ANTI LAG, CLEO, NOME DO GTA...", default=tipod, max_length=100, required=True)
        creditos = TextInput(label="CRÉDITOS", placeholder="De quem é os créditos? (opcional)", default=creditosd, style=discord.TextStyle.short, required=False)
        linkd = TextInput(label="LINK DE DEMONSTRAÇÃO", placeholder="Link de um vídeo demonstrativo (opcional)", default=linkdd, style=discord.TextStyle.short, required=False)
        senha = TextInput(label="SENHA", placeholder="Caso o tenha senha, coloque-a aqui (opcional)", default=senhad, style=discord.TextStyle.short, required=False)

        async def on_submit(self, interaction: discord.Interaction):
            
            iduser = int(interaction.user.id)
            if ver == True:
                embedpost = embeds[iduser]["embedpost"]
            else:
                embedpost = discord.Embed(colour=0x383d42)

            desc = f"{seta}**{str(self.tipo.value).upper()}**"
            embeds[iduser]["tipod"] = f"{str(self.tipo.value)}"

            valores = {
                "créditos": self.creditos.value or "",
                "demonstração": self.linkd.value or "",
                "senha": self.senha.value or ""
            }
            for chave, valor in valores.items():
                if valor:
                    desc += f"\n**ㅤ・{chave.upper():}:** {str(valor)}"
                embeds[iduser][chave] = str(valor)

            embedpost.description = desc
            embedpost.set_footer(text=f"{interaction.user.id}")

            try:
                embedpost.set_author(name=f"{interaction.user.name}", icon_url=f"{interaction.user.avatar.url}")
            except:
                embedpost.set_author(name=f"{interaction.user.name}", icon_url=imagenspainel.author_icon_default)

            if ver == False:
                embedselected = discord.Embed(colour=0x2f3136)
                embeds[iduser]["embedpost"], embeds[iduser]["embedselected"], embeds[iduser]["nomeaba"] = [embedpost, embedselected, nomeaba]
                await arquivos(interaction, ver)   
            else:
                link, tipo, select, embedselected, embedpost = [embeds[iduser]["linkdl"], embeds[iduser]["tipolink"], embeds[iduser]["selected"], embeds[iduser]["embedselected"], embeds[iduser]["embedpost"]]
                await interaction.response.edit_message(view=EditView2(link, tipo, select), embeds=[embedpost, embedselected])
                await interaction.followup.send("**INFORMAÇÕES** editadas!", ephemeral=True)
    try:
        await interaction.response.send_modal(Modal())
    except:
        return

class selectchannelview(discord.ui.View):
    def __init__(self, options):
        super().__init__(timeout=None)
        self.add_item(selectchannel(options))

class Img(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Sim", style=discord.ButtonStyle.gray, emoji=emojis.sim)
    async def Sim(self, interaction: discord.Interaction, button: discord.ui.Button):
        from settings.check import Bot
        bot = Bot
        iduser = int(interaction.user.id)

        task = asyncio.create_task(bot.wait_for("message", check=lambda message: check_image(message, iduser), timeout=300))
        class CancelarA(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)

            @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.gray)
            async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
                task.cancel()

        await interaction.response.edit_message(content=f"Me envie agora a **IMAGEM**\n**obs**: apenas imagens png ou jpg", view=CancelarA())
        
        try:
            messageimage = await task
            image_data = await messageimage.attachments[0].read()
            filename = messageimage.attachments[0].filename
            await messageimage.delete()
            await interaction.edit_original_response(content=f"**Aguarde uns instantes...**", view=None)
        except asyncio.TimeoutError:
            await interaction.edit_original_response(content=f"Tempo limite excedido. Tente novamente.", view=DropdownView(interaction.guild))
            return
        except asyncio.exceptions.CancelledError:
            await interaction.edit_original_response(content="Ok, cancelei o **post** para você.", view=None)
            embeds[iduser] = {}
            return
        
        private_user = await bot.fetch_user(int(os.getenv("USUARIO_FIST")))
        embed = embeds[iduser]["embedpost"]
        imagem_url = await upload_to_github(image_data, f"{int(time.time())}_{iduser}_demonstration.png", "mods/previews", interaction)
        embed.set_image(url=imagem_url)
        ver = False
        await interaction.edit_original_response(content="**Adicionado!**\nAgora escolha um divisor abaixo:", embeds=[embeddivederss], view=StaticOrAnimated2(ver))
    
    @discord.ui.button(label="Não", style=discord.ButtonStyle.gray, emoji=emojis.nao)
    async def Não(self, interaction: discord.Interaction, button: discord.ui.Button):
        ver = False
        await interaction.response.edit_message(content="Ok, escolha um divisor abaixo:", embeds=[embeddivederss], view=StaticOrAnimated2(ver))

class Info(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Sim, adicionar infos", style=discord.ButtonStyle.gray, emoji=emojis.sim)
    async def Sim(self, interaction: discord.Interaction, button: discord.ui.Button):
        iduser = int(interaction.user.id)
        nomeaba = embeds[iduser]["nomeaba"]

        modal = ModalInput(title=f"INFORMAÇÕES ADICIONAIS DO POST EM {nomeaba}")
        modal.add_item(TextInput(label="INFO. ADICIONAIS", placeholder="Coloque aqui as informações adicionais.", style=discord.TextStyle.paragraph, max_length=4000, required=True))
        await interaction.response.send_modal(modal)
        await modal.wait()

        embed = embeds[iduser]["embedpost"]
        embed.add_field(name="╺╸INFORMAÇÕES ADICIONAIS", value=str(modal.children[0]))
        embeds[iduser]["infosadc"] = str(modal.children[0])

        await interaction.edit_original_response(content="**Adicionado!**\nDeseja adicionar uma imagem para demonstração?", view=Img())
    
    @discord.ui.button(label="Não", style=discord.ButtonStyle.gray, emoji=emojis.nao)
    async def Não(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content="Ok, deseja adicionar uma imagem para demonstração?", view=Img())

class StaticOrAnimatedMenu2(discord.ui.Select):
    with open("divisores.json", "r", encoding='utf-8') as f:
        data = json.load(f)

    OPTIONS = data
    def __init__(self, ver):
        options = [
            discord.SelectOption(value=key, label=key) for key in self.OPTIONS.keys()
        ]
        if ver == True or ver == "fist true" or ver == "sound true":
            options.append(discord.SelectOption(value="voltar", label="Voltar", emoji=emojis.back))
        super().__init__(
            placeholder="Selecione uma opção...",
            min_values=1,
            max_values=1,
            options=options,
        )
        self.ver = ver

    async def callback(self, interaction: discord.Interaction):
        from settings.check import Bot as bot
        channel = bot.get_channel(ChannelIDs.DIVISORES)

        try:
            await interaction.response.edit_message(content="**Aguarde uns instantes...**", view=None, embeds=[])
            ed = interaction.edit_original_response
        except:
            await interaction.edit_original_response(content="**Aguarde uns instantes...**", view=None, embeds=[])
            ed = interaction.response.edit_message

        iduser = int(interaction.user.id)
        selected = self.values[0]
        ver = self.ver  
        if ver in ["sound false", "sound true", "fist false", "fist true"]:
            embedselected = embeds[iduser]["embedselected"]
        else:
            link, tipo, select, embedselected, embedpost = [embeds[iduser]["linkdl"], embeds[iduser]["tipolink"], embeds[iduser]["selected"], embeds[iduser]["embedselected"], embeds[iduser]["embedpost"]]

        if self.values[0] == "voltar":
            if ver in ["fist true", "sound true"]:
                sound1 = embeds[iduser]["sound1"]
                sound2 = embeds[iduser]["sound2"]
                sound1 = await sound1.to_file()
                sound2 = await sound2.to_file()
                embed = embeds[iduser]["embedselected"]
                selectedd = embeds[iduser]["selected"]
                await interaction.response.edit_message(content="**Aguarde uns instantes...**", embeds=[], view=None)
                creditos = embeds[iduser]["creditossound"]
                msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selectedd).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**"
                if creditos != "False":
                    msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selectedd).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**\n**ㅤ・CRÉDITOS:** {creditos}"

                await ed(content=msg, view=EditarSound(), attachments=[sound1, sound2], embed=embed)
                return
            else:
                await ed(embeds=[embedpost, embedselected], view=EditView2(link, tipo, select))
                return
        
        else:
            msg = await channel.fetch_message(self.OPTIONS.get(selected))
            embedselected = embeds[iduser]["embedselected"]
            embedselected.set_image(url=msg.attachments[0].url)
            embeds[iduser]["file"] = msg

            if ver in ["fist false", "fist true"]:
                await previewfist(interaction)
                if ver == "fist true":
                    await interaction.followup.send("**DIVISOR** editado!", ephemeral=True)
            if ver in ["sound false", "sound true"]:
                if ver == "sound false":
                    await ed(content="**Aguarde uns instantes...**", embeds=[], view=None)
                    await previewfist(interaction)
                if ver == "sound true":
                    await ed(content="**Aguarde uns instantes...**", embeds=[], view=None)
                    sound1 = embeds[iduser]["sound1"]
                    sound2 = embeds[iduser]["sound2"]
                    sound1 = await sound1.to_file()
                    sound2 = await sound2.to_file()
                    embed = embeds[iduser]["embedselected"]
                    creditos = embeds[iduser]["creditossound"]
                    selectedd = embeds[iduser]["selected"]
                    msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selectedd).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**"
                    if creditos != "False":
                        msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selectedd).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**\n**ㅤ・CRÉDITOS:** {creditos}"

                    await ed(content=msg, view=EditarSound(), attachments=[sound1, sound2], embed=embed)
                    await interaction.followup.send("**DIVISOR** editado!", ephemeral=True)
            else:
                embeds[iduser]["selected"] = selected
                if ver == False:
                    await ed(content=f"**ESCOLHIDO {selected}!**\nDeseja visualizar um preview do seu post?", view=Preview2(), embeds=[])
                
                if ver == True:
                    await ed(embeds=[embedpost, embedselected], view=EditView2(link, tipo, select))
                    await interaction.followup.send("**DIVISOR** editado!", ephemeral=True)

class StaticOrAnimated2(discord.ui.View):
    def __init__(self, ver):
        super().__init__(timeout=None)
        self.add_item(StaticOrAnimatedMenu2(ver))

class FistConfirm(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(editar())
        self.add_item(FistBanner())
        self.add_item(ConfirmEnvio2())

class FistBanner(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Editar divisor", style=discord.ButtonStyle.gray, row=3)

    async def callback(self, interaction: discord.Interaction):
        iduser = int(interaction.user.id)
        ver = embeds[iduser]["ver"]
        await interaction.response.edit_message(content="Escolha um divisor abaixo:", embeds=[embeddivederss], view=StaticOrAnimated2(ver))

class ConfirmEnvio2(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Enviar (postar)", style=discord.ButtonStyle.green, row=3)

    async def callback(self, interaction: discord.Interaction):
        iduser = int(interaction.user.id)
        thread = embeds[iduser]["thread"]
        embedpost = embeds[iduser]["embedpost"]
        file = embeds[iduser]["file"]
        
        if thread.id != ChannelIDs.POST_FIST_SPECIAL:
            link = embeds[iduser]["linkdl"]
            tipo = embeds[iduser]["tipolink"]
            view = DLButton2(link, tipo)
        else:
            buttons = embeds[iduser]["buttons"]
            if buttons:
                view = discord.ui.View()
                for button in buttons:
                    view.add_item(button)
            
        await interaction.response.edit_message(content="**Aguarde uns instantes...**", embeds=[], view=None)
        await thread.send(embed=embedpost, view=view)
        a = await thread.send(file=await file.attachments[0].to_file())
        await atualizarjson("adc")

        class Ir(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(label="Ir para o post", url=a.jump_url))

        await interaction.edit_original_response(content="Pronto, seu post foi publicado! :)", view=Ir())
        embeds[iduser] = {}

class EditMenu2(discord.ui.Select):
    def __init__(self, select):
        options = [
            discord.SelectOption(value="infopost",label="Detalhes", description=f'Detalhes do post'),
            discord.SelectOption(value="infoadc",label="Informações adicionais", description=f'Informações adicionais do post'),
            discord.SelectOption(value="dl",label="Download", description=f'Link ou arquivo de download'),
            discord.SelectOption(value="imagem",label="Imagem demonstrativa", description=f'Imagem demonstrativa do post'),
            discord.SelectOption(value="divider",label="Divisor", description=f"{select}"),
            discord.SelectOption(value="voltar",label="Voltar", emoji=emojis.back),
        ]
        super().__init__(
            placeholder="Selecione uma opção...",
            min_values=1,
            max_values=1,
            options=options,
            row=2
        )
    async def callback(self, interaction: discord.Interaction):

        from settings.check import Bot
        bot = Bot
        iduser = int(interaction.user.id)
        nomeaba = embeds[iduser]["nomeaba"]
        ver = True
        link, tipo, select, embedselected, embedpost = [embeds[iduser]["linkdl"], embeds[iduser]["tipolink"], embeds[iduser]["selected"], embeds[iduser]["embedselected"], embeds[iduser]["embedpost"]]

        if self.values[0] == "voltar":
            await interaction.response.edit_message(embeds=[embedpost, embedselected], view=PreviewView2(link, tipo))

        if self.values[0] == "infopost":
            tipod, creditosd, linkdd, senhad = [embeds[iduser]["tipod"], embeds[iduser]["créditos"], embeds[iduser]["demonstração"], embeds[iduser]["senha"]]
            
            await infospost(interaction, nomeaba, ver, tipod, creditosd, linkdd, senhad)

        if self.values[0] == "dl":
            await interaction.response.edit_message(view=EditView2(link, tipo, select), embeds=[embedpost, embedselected])
            await arquivos(interaction, ver)

        if self.values[0] == "divider":
            await interaction.response.edit_message(content="Escolha um divisor abaixo:", view=StaticOrAnimated2(ver), embeds=[embeddivederss])
        
        if self.values[0] == "infoadc":
            dft = embeds[iduser]["infosadc"]
            modal = ModalInput(title=f"INFORMAÇÕES ADICIONAIS DO POST EM {nomeaba}")
            modal.add_item(TextInput(label="INFO. ADICIONAIS", placeholder="Coloque aqui as informações adicionais.", default=dft, style=discord.TextStyle.paragraph, max_length=4000, required=False))
            await interaction.response.send_modal(modal)
            await modal.wait()
            
            if str(modal.children[0]) != "":
                embedpost.set_field_at(index=0, name="╺╸INFORMAÇÕES ADICIONAIS", value=str(modal.children[0]))
                embeds[iduser]["infosadc"] = str(modal.children[0])
            else:
                embeds[iduser]["infosadc"] = ""
                embedpost.remove_field(0)

            await interaction.edit_original_response(view=EditView2(link, tipo, select), embeds=[embedpost, embedselected])
            await interaction.followup.send("**INFORMAÇÕES ADICIONAIS** editadas!", ephemeral=True)
        
        if self.values[0] == "imagem":
            
            await interaction.response.edit_message(view=EditView2(link, tipo, select), embeds=[embedpost, embedselected])
            task = asyncio.create_task(bot.wait_for("message", check=lambda message: check_image(message, iduser), timeout=300))

            class Cancelar(discord.ui.View):
                def __init__(self):
                    super().__init__(timeout=None)

                @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.gray)
                async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
                    task.cancel()

            a = await interaction.followup.send("Me envie agora a **IMAGEM**\n**obs**: apenas imagens png ou jpg", view=Cancelar(), ephemeral=True)

            try:
                messageimage = await task
                image_data = await messageimage.attachments[0].read()
                filename = messageimage.attachments[0].filename
                await messageimage.delete()
                await interaction.followup.edit_message(a.id, content=f"**Aguarde uns instantes...**", view=None)
            except asyncio.TimeoutError:
                await interaction.followup.edit_message(a.id, content=f"Tempo limite excedido. Tente novamente.", view=None)
                await interaction.edit_original_response(view=EditView2(link, tipo, select), embeds=[embedpost, embedselected])
                return
            except asyncio.exceptions.CancelledError:
                await interaction.followup.edit_message(a.id, content="Ok, cancelei a edição da **IMAGEM** para você.", view=None)
                await interaction.edit_original_response(view=EditView2(link, tipo, select), embeds=[embedpost, embedselected])
                return
            except:
                return
            
            private_user = await bot.fetch_user(UserIDs.FIST_RECEIVER)
            imagem_url = await upload_to_github(image_data, f"{int(time.time())}_{iduser}_preview.png", "mods/previews", interaction)
            embedpost.set_image(url=imagem_url)

            await interaction.edit_original_response(view=EditView2(link, tipo, select), embeds=[embedpost, embedselected])
            await interaction.followup.edit_message(a.id, content="**IMAGEM** editada!")

class EditView2(discord.ui.View):
    def __init__(self, link, tipo, select):
        super().__init__(timeout=None)

        self.add_item(EditMenu2(select))
        self.add_item(discord.ui.Button(label=tipo, url=link, row=1))

class Edit2(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Editar", style=discord.ButtonStyle.gray, row=2)

    async def callback(self, interaction: discord.Interaction):

        iduser = int(interaction.user.id)
        link, tipo, select = [embeds[iduser]["linkdl"], embeds[iduser]["tipolink"], embeds[iduser]["selected"]]

        await interaction.response.edit_message(view=EditView2(link, tipo, select))

class PreviewView2(discord.ui.View):
    def __init__(self, link, tipo):
        super().__init__(timeout=None)
        self.add_item(ConfirmEnvio2())
        self.add_item(Edit2())
        self.add_item(discord.ui.Button(label=tipo, url=link, row=1))
        
class Preview2(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Sim (editar)", style=discord.ButtonStyle.gray)
    async def SimPreview(self, interaction: discord.Interaction, button: discord.ui.Button):
        iduser = int(interaction.user.id)
        link, tipo, embedselected, embedpost = [embeds[iduser]["linkdl"], embeds[iduser]["tipolink"], embeds[iduser]["embedselected"], embeds[iduser]["embedpost"]]

        await interaction.response.edit_message(content="Este é um preview do seu post", embeds=[embedpost, embedselected], view=PreviewView2(link, tipo))

    @discord.ui.button(label="Não (enviar)", style=discord.ButtonStyle.gray)
    async def NãoPreview(self, interaction: discord.Interaction, button: discord.ui.Button):

        iduser = int(interaction.user.id)
        embedpost = embeds[iduser]["embedpost"]
        thread = embeds[iduser]["thread"]
        file = embeds[iduser]["file"]
        link = embeds[iduser]["linkdl"]
        tipo = embeds[iduser]["tipolink"]

        await interaction.response.edit_message(content="**Aguarde uns instantes...**", embeds=[], view=None)

        await thread.send(embed=embedpost, view=DLButton2(link, tipo))
        a = await thread.send(file=await file.attachments[0].to_file())
        await atualizarjson("adc")

        class Ir(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(label="Ir para o post", url=a.jump_url))

        await interaction.edit_original_response(content="Pronto, seu post foi publicado! :)", view=Ir())
        embeds[iduser] = {}

class editar(discord.ui.Button):
    def __init__(self):
        super().__init__(label="Editar (enviar as imagens novamente)", style=discord.ButtonStyle.gray, row=3)

    async def callback(self, interaction: discord.Interaction):
        await fistpost(interaction)

async def fistpost(interaction: discord.Interaction):
    from settings.check import Bot
    iduser = int(interaction.user.id)
    bot = Bot
    user = await bot.fetch_user(UserIDs.FIST_RECEIVER)
    
    task = asyncio.create_task(bot.wait_for("message", check=lambda message: check_fist(message, iduser), timeout=300))
    class CancelarA(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=None)

        @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.gray)
        async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
            task.cancel()
    ver = embeds[iduser]["ver"]
    if ver == "fist true":
        await previewfist(interaction)
        a = await interaction.followup.send("Me envie as fists que você quer postar (**10 Imagens no máximo**, **envie todas em uma só mensagem**)\n**obs:** todas as imagens devem ser **png** e devem ter o tamanho menor que **25 mb** (**todas juntas**)\n**obs²**: as fists devem estar nas resoluções **256x256** ou **512x512** ", view=CancelarA(), embed=None, ephemeral=True)
    else:
        await interaction.response.edit_message(content="Me envie as fists que você quer postar (**10 Imagens no máximo**, **envie todas em uma só mensagem**)\n**obs:** todas as imagens devem ser **png** e devem ter o tamanho menor que **25 mb** (**todas juntas**)", view=CancelarA(), embed=None)
    
    try:
        messagefist = await task
        await messagefist.delete()
        if ver == "fist true":
            await interaction.followup.edit_message(a.id, content=f"**Aguarde uns instantes...**", view=None)
        else:
            await interaction.edit_original_response(content=f"**Aguarde uns instantes...**", view=None)
    except asyncio.TimeoutError:
        if ver == "fist true":
            await interaction.followup.edit_message(a.id, content=f"Tempo limite excedido. Tente novamente.", view=None)
        else:
            await interaction.edit_original_response(content=f"Tempo limite excedido. Tente novamente.", view=DropdownView(interaction.guild))
        return
    except asyncio.exceptions.CancelledError:
        if ver == "fist true":
            await interaction.followup.edit_message(a.id, content=f"Ok, cancelei a edição das **fists** para você.", view=None)
            return
        else:
            await interaction.edit_original_response(content="Ok, cancelei o **post** para você.", view=None)
            embeds[iduser] = {}
        return
    
    png_attachments = []
    for attachment in messagefist.attachments:
        if attachment.filename.split(".")[-1] == "png":
            png_attachments.append(attachment)
    
    if png_attachments:
        filedata = []
        links = []
        timestamp = int(time.time())
        for attachment in png_attachments:
            filebytes = await attachment.read()
            url = await upload_to_github(filebytes, f"{timestamp}_{iduser}_fist_{attachment.filename}", "fists/raw_static", interaction)
            if url: links.append(url)

        if len(links) == 1:
            button_text = "Fist"
        else:
            button_text = "Fist ({})"

        buttons = []
        for i, link in enumerate(links):
            if button_text == "Fist":
                label = button_text
            else:
                label = button_text.format(i+1)
            button = discord.ui.Button(label=label, url=link, emoji=emojis.download)
            buttons.append(button)

        size = (300, 300)
        rows = 2
        cols = min(len(png_attachments[:10]), 5)
        canvas = Image.new('RGBA', (cols * size[0], rows * size[1]), (0, 0, 0, 0))
        
        for i, attachment in enumerate(png_attachments[:10]):
            image_bytes = await attachment.read()
            with Image.open(BytesIO(image_bytes)) as image:
                image.thumbnail(size, Image.Resampling.LANCZOS)
                
                x = (i % cols) * size[0]
                y = (i // cols) * size[1]
                
                paste_img = Image.new('RGBA', size, (0,0,0,0))
                paste_img.paste(image, ((size[0] - image.width) // 2, (size[1] - image.height) // 2))
                canvas.paste(paste_img, (x, y))
        
        bbox = canvas.getbbox()
        canvas = canvas.crop(bbox)
        
        buffer = BytesIO()
        canvas.save(buffer, format="PNG")
        buffer.seek(0)
        
        embed = discord.Embed(color=0x383d42)
        embed.set_author(name=str(interaction.user.name), icon_url=interaction.user.avatar.url)
        
        collage_bytes = buffer.getvalue()
        collage_url = await upload_to_github(collage_bytes, f"{timestamp}_{iduser}_fist_collage.png", "fists/previews", interaction)

        embed.set_footer(text=str(interaction.user.id))
        embed.set_image(url=collage_url)
        embeds[iduser]["embedpost"] = embed
        embeds[iduser]["buttons"] = buttons
        if ver == "fist true":
            await previewfist(interaction)
            await interaction.followup.edit_message(a.id, content=f"**FISTS** editadas!", view=None)
        else:
            await interaction.edit_original_response(content="Escolha um divisor abaixo:", embeds=[embeddivederss], view=StaticOrAnimated2(ver))

class EditarSoundSelect(discord.ui.Select):
    def __init__(self):
        options = [
        discord.SelectOption(value="wav",label="Editar os arquivos wav"),
        discord.SelectOption(value="arma",label="Editar a arma pertencentes a os sounds"),
        discord.SelectOption(value="divisor",label="Editar o divisor"),
        discord.SelectOption(value="back",label="Voltar", emoji=emojis.back),
        ]
        super().__init__(
            placeholder="Selecione uma opção...",
            min_values=1,
            max_values=1,
            options=options,
        )
    async def callback(self, interaction: discord.Interaction):
        iduser = int(interaction.user.id)
        ver = embeds[iduser]["ver"]

        if self.values[0] == "wav":
            await soundpost(interaction)
        if self.values[0] == "arma":
            await interaction.response.edit_message(content="De qual arma é este sound?", view=EditarSoundNome(ver), attachments=[], embed=None)
        if self.values[0] == "divisor":
            await interaction.response.edit_message(content=f"Escolha um divisor abaixo:", embeds=[embeddivederss], view=StaticOrAnimated2(ver), attachments=[])
        if self.values[0] == "back":
            await interaction.response.edit_message(view=Enviar())

class EditarSound(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(EditarSoundSelect())

class EditarNomeSound(discord.ui.Select):
    def __init__(self, ver):
        options = [
        discord.SelectOption(value="m4",label="M4", emoji=emojis.m4),
        discord.SelectOption(value="ak47",label="AK47", emoji=emojis.ak47),
        discord.SelectOption(value="cutgun",label="CUTGUN", emoji=emojis.cutgun),
        discord.SelectOption(value="sniper",label="SNIPER", emoji=emojis.sniper),
        discord.SelectOption(value="mp5",label="MP5", emoji=emojis.mp5),
        discord.SelectOption(value="mac10",label="MAC10", emoji=emojis.mac10),
        discord.SelectOption(value="tec9",label="TEC9", emoji=emojis.tec9),
        discord.SelectOption(value="shotgun",label="SHOTGUN", emoji=emojis.shotgun),
        discord.SelectOption(value="combat",label="COMBAT", emoji=emojis.combat),
        discord.SelectOption(value="desert",label="DESERT", emoji=emojis.desert),
        discord.SelectOption(value="silenced",label="SILENCED", emoji=emojis.silenced),
        discord.SelectOption(value="9mm",label="9MM", emoji=emojis.nine_mm)
        ]
        if ver == "sound true":
            options.append(discord.SelectOption(value="back",label="Voltar", emoji=emojis.back))
        super().__init__(
            placeholder="Selecione uma arma...",
            min_values=1,
            max_values=1,
            options=options,
        )
    async def callback(self, interaction: discord.Interaction):
        iduser = int(interaction.user.id)
        ver = embeds[iduser]["ver"]
        embeds[iduser]["selected"] = self.values[0]

        if ver == "sound false":
            await interaction.response.edit_message(content=f"**SELECIONADO {str(self.values[0]).upper()}**\nEscolha um divisor abaixo:", embeds=[embeddivederss], view=StaticOrAnimated2(ver))
        if ver == "sound true":
            sound1 = embeds[iduser]["sound1"]
            sound2 = embeds[iduser]["sound2"]
            sound1 = await sound1.to_file()
            sound2 = await sound2.to_file()
            embed = embeds[iduser]["embedselected"]
            creditos = embeds[iduser]["creditossound"]
            msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(self.values[0]).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**"
            if creditos != "False":
                msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(self.values[0]).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**\n**ㅤ・CRÉDITOS:** {creditos}"

            if self.values[0] == "back":
                await interaction.response.edit_message(content="**Aguarde uns instantes...**", view=None)
                await interaction.edit_original_response(content=msg, view=EditarSound(), attachments=[sound1, sound2], embed=embed)
            else:
                await interaction.response.edit_message(content="**Aguarde uns instantes...**", view=None)
                await interaction.edit_original_response(content=msg, view=EditarSound(), attachments=[sound1, sound2], embed=embed)
                await interaction.followup.send(f"**ARMA** editada!", ephemeral=True)

class EditarSoundNome(discord.ui.View):
    def __init__(self, ver):
        super().__init__(timeout=None)

        self.add_item(EditarNomeSound(ver))

class Enviar(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Enviar", style=discord.ButtonStyle.green)
    async def enviar(self, interaction: discord.Interaction, button: discord.ui.Button):

        iduser = int(interaction.user.id)
        thread = embeds[iduser]["thread"]
        file = embeds[iduser]["file"]
        sound1 = embeds[iduser]["sound1"]
        sound2 = embeds[iduser]["sound2"]
        sound1 = await sound1.to_file()
        sound2 = await sound2.to_file()
        selected = embeds[iduser]["selected"]
        creditos = embeds[iduser]["creditossound"]

        msg = f"**{seta}{str(selected).upper()}**\nㅤ**・By [{interaction.user.name}](<https://discord.com/users/{interaction.user.id}>)**"
        if creditos != "False":
            msg = f"**{seta}{str(selected).upper()}**\nㅤ**・By [{interaction.user.name}](<https://discord.com/users/{interaction.user.id}>)**\n**ㅤ・CRÉDITOS:** {creditos}"

        await interaction.response.edit_message(content="**Aguarde uns instantes...**", view=None, embed=None, attachments=[])

        await thread.send(msg, files=[sound1, sound2])
        a = await thread.send(file=await file.attachments[0].to_file())
        await atualizarjson("adc")
        embeds[iduser] = {}

        class Ir(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=None)
                self.add_item(discord.ui.Button(label="Ir para o post", url=a.jump_url))

        await interaction.edit_original_response(content="Pronto, seu post foi publicado! :)", view=Ir())

    @discord.ui.button(label="Editar", style=discord.ButtonStyle.gray)
    async def edit(self, interaction: discord.Interaction, button: discord.ui.Button):
        iduser = int(interaction.user.id)
        embeds[iduser]["ver"] = "sound true"
        await interaction.response.edit_message(view=EditarSound())
    
    @discord.ui.button(label="Adicionar/Editar Créditos", style=discord.ButtonStyle.gray)
    async def creditos(self, interaction: discord.Interaction, button: discord.ui.Button):
        iduser = int(interaction.user.id)
        dft = embeds[iduser]["creditossound"]
        if dft == "False":
            dft = ""

        modal = ModalInput(title=f"CRÉDITOS DOS SOUNDS")
        modal.add_item(TextInput(label="CRÉDITOS", placeholder="De quem é os créditos da criação do mod?", max_length=100, required=False, default=dft))
        await interaction.response.send_modal(modal)
        await modal.wait()
        
        sound1 = embeds[iduser]["sound1"]
        sound2 = embeds[iduser]["sound2"]
        sound1 = await sound1.to_file()
        sound2 = await sound2.to_file()
        selected = embeds[iduser]["selected"]
        embed = embeds[iduser]["embedselected"]

        if str(modal.children[0]) != "":
            embeds[iduser]["creditossound"] = f"{str(modal.children[0])}"
            await interaction.edit_original_response(content=f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selected).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**\n**ㅤ・CRÉDITOS:** {str(modal.children[0])}", view=Enviar(), attachments=[sound1, sound2], embed=embed)
            await interaction.followup.send(f"**CRÉDITOS** adicionados a **{str(modal.children[0])}**!", ephemeral=True)
        else:
            embeds[iduser]["creditossound"] = "False"
            await interaction.edit_original_response(content=f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selected).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**", view=Enviar(), attachments=[sound1, sound2], embed=embed)
            await interaction.followup.send("**CRÉDITOS** removidos!", ephemeral=True)

async def previewfist(interaction: discord.Interaction):
    iduser = int(interaction.user.id)
    thread = embeds[iduser]["thread"]

    if thread.id != ChannelIDs.POST_SOUND_SPECIAL:
        embed = embeds[iduser]["embedpost"]
        embedselected = embeds[iduser]["embedselected"]
        buttons = embeds[iduser]["buttons"]
        ver = "fist true"
        embeds[iduser]["ver"] = ver

        if buttons:
            view = FistConfirm()
            for button in buttons:
                view.add_item(button)
        try:
            await interaction.response.edit_message(content="Este é um preview do seu post", embeds=[embed, embedselected], view=view)
        except:
            await interaction.edit_original_response(content="Este é um preview do seu post", embeds=[embed, embedselected], view=view)
    else:
        creditos = embeds[iduser]["creditossound"]
        sound1 = embeds[iduser]["sound1"]
        sound2 = embeds[iduser]["sound2"]
        sound1 = await sound1.to_file()
        sound2 = await sound2.to_file()
        selected = embeds[iduser]["selected"]
        embed = embeds[iduser]["embedselected"]
        msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selected).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**"
        if creditos != "False":
            msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selected).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**\n**ㅤ・CRÉDITOS:** {creditos}"
        try:
            await interaction.edit_original_response(content=msg, view=Enviar(), attachments=[sound1, sound2], embed=embed)
        except:
            await interaction.edit_original_response(content=msg, view=Enviar(), attachments=[sound1, sound2], embed=embed)

async def soundpost(interaction: discord.Interaction):
    from settings.check import Bot
    bot = Bot
    iduser = int(interaction.user.id)
    ver = embeds[iduser]["ver"]
    task = asyncio.create_task(bot.wait_for("message", check=lambda message: check_sound(message, iduser), timeout=300))
    
    class Cancelar(discord.ui.View):
        def __init__(self):
            super().__init__(timeout=None)

        @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.gray)
        async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
            task.cancel()
            if ver == "sound true":
                await interaction.response.edit_message(content="**Aguarde uns instantes...**", view=None)
                sound1 = embeds[iduser]["sound1"]
                sound2 = embeds[iduser]["sound2"]
                sound1 = await sound1.to_file()
                sound2 = await sound2.to_file()
                selected = embeds[iduser]["selected"]
                embed = embeds[iduser]["embedselected"]
                creditos = embeds[iduser]["creditossound"]
                msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selected).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**"
                if creditos != "False":
                    msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selected).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**\n**ㅤ・CRÉDITOS:** {creditos}"

                await interaction.edit_original_response(content=msg, view=EditarSound(), attachments=[sound1, sound2], embed=embed)
                await interaction.followup.send("**EDIÇÃO** cancelada.", ephemeral=True)
            return

    if ver == "sound false":
        await interaction.response.edit_message(content="Me envie agora os **SOUNDS** para download (**os dois juntos na mesma mensagem**)\n**obs**: só aceito dois arquivos **.wav** e pesando menos que **25MBs**", view=Cancelar())
    else:
        await interaction.response.edit_message(content="Me envie agora os **SOUNDS** para download (**os dois juntos na mesma mensagem**)\n**obs**: só aceito dois arquivos **.wav** e pesando menos que **25MBs**", view=Cancelar(), attachments=[], embed=None)

    try:
        messagesound = await task
        await messagesound.delete()
        await interaction.edit_original_response(content=f"**Aguarde uns instantes...**", view=None)
    except asyncio.TimeoutError:
        if ver == "sound false":
            await interaction.edit_original_response(content=f"Tempo limite excedido. Tente novamente.", view=DropdownView(interaction.guild))
            return
        else:
            sound1 = embeds[iduser]["sound1"]
            sound2 = embeds[iduser]["sound2"]
            sound1 = await sound1.to_file()
            sound2 = await sound2.to_file()
            selected = embeds[iduser]["selected"]
            embed = embeds[iduser]["embedselected"]
            creditos = embeds[iduser]["creditossound"]
            msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selected).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**"
            if creditos != "False":
                msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selected).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**\n**ㅤ・CRÉDITOS:** {creditos}"

            await interaction.edit_original_response(content=msg, view=EditarSound(), attachments=[sound1, sound2], embed=embed)
            await interaction.followup.send("Tempo limite excedido. Tente novamente.", ephemeral=True)
            return
    except asyncio.exceptions.CancelledError:
        if ver == "sound false":
            await interaction.edit_original_response(content="Ok, cancelei o **post** para você.", view=None)
            embeds[iduser] = {}
        return
    
    sound1 = messagesound.attachments[0]
    sound2 = messagesound.attachments[1]

    embeds[iduser]["sound1"] = sound1
    embeds[iduser]["sound2"] = sound2
    selected = embeds[iduser]["selected"]
    embed = embeds[iduser]["embedselected"]
    creditos = embeds[iduser]["creditossound"]
    msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selected).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**"
    if creditos != "False":
        msg = f"Este é um preview do seu post, confirmar envio?\n\n**{seta}{str(selected).upper()}**\nㅤ**・By __[{interaction.user.name}](https://discord.com/users/{interaction.user.id})__**\n**ㅤ・CRÉDITOS:** {creditos}"
    if ver == "sound false":
        await interaction.edit_original_response(content="De qual arma é este sound?", view=EditarSoundNome(ver))
    if ver == "sound true":
        sound1 = await sound1.to_file()
        sound2 = await sound2.to_file()
        await interaction.edit_original_response(content=msg, view=EditarSound(), attachments=[sound1, sound2], embed=embed)
        await interaction.followup.send("**SOUNDS** editados!", ephemeral=True)

def dfftxdcheck(message: discord.Message, iduser):

    iduser2 = int(message.author.id)

    if iduser != iduser2:
        return False

    if not message.attachments:
        return False
    
    if len(message.attachments) > 2:
        return False
		
    if len(message.attachments) == 2:
        arquivos = []
        for attachment in message.attachments:
            if attachment.filename.split(".")[-1] not in ["txd", "dff"]:
                return False
            if attachment.size * 1e-6 > 25:
                return False
            arquivos.append(attachment)
            
        total_size = sum(attachment.size for attachment in arquivos)
        if total_size * 1e-6 > 25:
            return False
        
        return True

    compact = [attachment.filename.split(".")[-1].lower() for attachment in message.attachments]
    if "zip" in compact:
        if message.attachments[0].size * 1e-6 > 25:
            return False
        return True
    
    extensions = [attachment.filename.split(".")[-1].lower() for attachment in message.attachments]
    if "dff" not in extensions or "txd" not in extensions:
        return False

    return True

def check_image(message: discord.Message, iduser):
    
    iduser2 = int(message.author.id)

    if iduser != iduser2:
        return False
    
    if not message.attachments:
        return False
    
    if len(message.attachments) != 1:
        return False

    extension = message.attachments[0].filename.split(".")[-1]
    if extension not in ["png", "jpg", "jpeg"]:
        return False
    
    return True

def check_imagedivisor(message: discord.Message, iduser):
    
    iduser2 = int(message.author.id)

    if iduser != iduser2:
        return False
    
    if not message.attachments:
        return False
    
    if len(message.attachments) != 1:
        return False

    extension = message.attachments[0].filename.split(".")[-1]
    if extension not in ["png", "jpg", "jpeg", "gif"]:
        return False
    
    if not message.content:
        return False
    
    return True

def check_zip(message: discord.Message, iduser):
    
    iduser2 = int(message.author.id)

    if iduser != iduser2:
        return False
    
    padrao = r'(https?://\S+)'
    resultado = re.search(padrao, message.content)
    
    if resultado:
        if len(message.content.strip()) == len(resultado.group(1)):

            if re.search('drive\\.google\\.com', message.content):
                return True
        
            elif re.search('www\\.mediafire\\.com', message.content):
                return True

            else:
                return False
            
    if len(message.attachments) != 1:
        return False

    attachment = message.attachments[0]
    extension = message.attachments[0].filename.split(".")[-1]
    if extension not in ["zip", "rar", "dat", "csa", "cs", "lua", "luac", "cleo", "csi", "fxt", "asi", "sf", "json", "ttf", "ide", "txd", "dff", "so", "ini", "txt"]:
        return False
    
    if attachment.size * 1e-6 > 25:
        return False
    
    return True
    
def check_sound(message: discord.Message, iduser):
    
    iduser2 = int(message.author.id)

    if iduser != iduser2:
        return False
    
    if len(message.attachments) == 2:

        sounds = []
        for attachment in message.attachments:
            if attachment.filename.split(".")[-1] != "wav":
                return False
            if attachment.size * 1e-6 > 25:
                return False
            
            sounds.append(attachment)
            
        total_size = sum(attachment.size for attachment in sounds)
        if total_size > 25 * 1024 * 1024:
            return False
        
        return True

def check_fist(message: discord.Message, iduser):
    
    iduser2 = int(message.author.id)

    if iduser != iduser2:
        return False
    
    if not message.attachments:
        return False

    png_attachments = []
    for attachment in message.attachments:
            
        if attachment.filename.split(".")[-1] != "png":
            return False
        
        png_attachments.append(attachment)

    total_size = sum(attachment.size for attachment in png_attachments)
    if total_size > 25 * 1024 * 1024:
        return False
    
    return True

async def atualizarjson(adcorremove):
    from settings.check import Bot as bot
    server = bot.get_guild(int(os.getenv("SERVER_ID")))
    channel = server.get_channel(int(os.getenv("HUB_ID")))
    with open("message_counts.json", "r") as f:
        data = json.load(f)

    if adcorremove == "adc":
        data["totalmsg"] += 1
    if adcorremove == "remove":
        if data["totalmsg"] != 0:
            data["totalmsg"] -= 1

    with open("message_counts.json", "w") as f:
        json.dump(data, f, indent=4)

    with open("message_counts.json", "r") as f:
        data = json.load(f)

    msg = await channel.fetch_message(data["mensagemid"])
    new_embed = discord.Embed(title="╺╸POSTE SEUS MODS NO DISCORD", description=f"**TOTAL DE MODS PUBLICADOS**: __**{data['totalmsg']}**__\n\n   Clique abaixo para começar o processo de envio do seu post em nosso discord.", colour=0x383d42)
    new_embed.set_image(url=imagenspainel.poste_seus_mods)
    if server.icon:
        new_embed.set_thumbnail(url=server.icon.url)
    
    await msg.edit(embed=new_embed)

async def check_hub_message(bot):
    channel_id = ChannelIDs.HUB
    if not channel_id:
        return
    
    channel = bot.get_channel(channel_id)
    if not channel:
        return

    with open("message_counts.json", "r") as f:
        data = json.load(f)
    
    msg_id = data.get("mensagemid")
    
    try:
        if msg_id:
            msg = await channel.fetch_message(msg_id)
            new_embed = discord.Embed(title="╺╸POSTE SEUS MODS NO DISCORD", description=f"**TOTAL DE MODS PUBLICADOS**: __**{data['totalmsg']}**__\n\n   Clique abaixo para começar o processo de envio do seu post em nosso discord.", colour=0x383d42)
            new_embed.set_image(url=imagenspainel.poste_seus_mods)
            if channel.guild.icon:
                new_embed.set_thumbnail(url=channel.guild.icon.url)
            await msg.edit(embed=new_embed, view=Post())
            return
    except discord.NotFound:
        pass
    
    embed = discord.Embed(title="╺╸POSTE SEUS MODS NO DISCORD", description=f"**TOTAL DE MODS PUBLICADOS**: __**{data.get('totalmsg', 0)}**__\n\n   Clique abaixo para começar o processo de envio do seu post em nosso discord.", colour=0x383d42)
    embed.set_image(url=imagenspainel.poste_seus_mods)
    if channel.guild.icon:
        embed.set_thumbnail(url=channel.guild.icon.url)
    
    msg = await channel.send(embed=embed, view=Post())
    data["mensagemid"] = msg.id
    with open("message_counts.json", "w") as f:
        json.dump(data, f, indent=4)
