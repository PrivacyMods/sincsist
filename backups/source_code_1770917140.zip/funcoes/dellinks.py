from settings.check import Bot
from funcoes import hub
from settings.ids import ChannelIDs, RoleIDs, UserIDs, CategoryIDs
import discord
import re
import os
from dotenv import load_dotenv
load_dotenv()

whitelisted_links = ["https://discord.gg/UDKjp4gfay"]

async def on_message_links(message):
    if message.author == Bot.user:
        return

    # Proteção Global contra Convites do Discord
    invite_regex = r"(https?://)?(www\.)?(discord\.(gg|io|me|li)|discordapp\.com/invite|discord\.com/invite)/[a-zA-Z0-9]+"
    
    if re.search(invite_regex, message.content):
        # Verifica se o canal está na whitelist (Canais de Posts/Hud)
        is_whitelisted = False
        if message.channel.id == ChannelIDs.FIST:
            is_whitelisted = True
        elif message.channel.category_id in CategoryIDs.POSTS:
            is_whitelisted = True
        elif message.author.guild_permissions.administrator:
            is_whitelisted = True
            
        if not is_whitelisted:
            await message.delete()
            
            # Punição para o cargo Postador (Youtuber)
            role_youtuber = message.guild.get_role(RoleIDs.YOUTUBER)
            if role_youtuber and role_youtuber in message.author.roles:
                try:
                    await message.author.remove_roles(role_youtuber)
                    await message.channel.send(f"{message.author.mention} ⚠️ **ADVERTÊNCIA:** Você tentou divulgar outro servidor! Seu cargo de {role_youtuber.mention} foi removido.", delete_after=15)
                except Exception as e:
                    print(f"Erro ao remover cargo: {e}")
            else:
                await message.channel.send(f"{message.author.mention} 🚫 **É proibido divulgar outros servidores aqui!**", delete_after=5)
            return

    # (Lógica antiga de MONITORED_LINKS removida ou mantida se necessária, mas o pedido foca na proteção global)

async def on_message_delete(message: discord.Message):
    if str(message.channel.category_id) in os.getenv("CATEGORY_IDS_POSTS") and message.channel.id != ChannelIDs.FIST:
        if message.embeds:
            embed = message.embeds[0]
            if embed.footer:
                if re.match("^[0-9]+$", embed.footer.text):
                    await hub.atualizarjson("remove")
                    return
        if message.attachments and message.attachments[0].filename.split(".")[-1] not in ["png", "jpg", "jpeg", "gif"] and not message.embeds:
            await hub.atualizarjson("remove")
            return
            