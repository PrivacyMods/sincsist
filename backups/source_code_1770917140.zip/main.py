from settings import check
from funcoes import dellinks, notificacao, traducao
from dotenv import load_dotenv
load_dotenv()

import os
import sys

Bot = check.Bot
sys.path.append(os.path.abspath('funcoes'))

@Bot.event
async def on_message(message):
    await dellinks.on_message_links(message)
    await notificacao.on_message_channel(message)
    await notificacao.on_message_channel_fist(message)
    await notificacao.on_message_link_dc(message)
    await traducao.on_message(message)


@Bot.event
async def on_message_delete(message):
    await dellinks.on_message_delete(message)


@Bot.event
async def on_member_join(member):
    await notificacao.membros()


@Bot.event
async def on_member_remove(member):
    await notificacao.membros()


check.diagnose()
check.Bot.run(os.getenv("TOKEN"))
