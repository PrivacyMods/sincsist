import sys
import io
from types import ModuleType

if "cgi" not in sys.modules:
    cgi_shim = ModuleType("cgi")
    def parse_header(line):
        import email.message
        m = email.message.Message()
        m['content-type'] = line
        p = m.get_params()
        return m.get_content_type(), dict(p) if p else {}
    cgi_shim.parse_header = parse_header
    sys.modules["cgi"] = cgi_shim

from funcoes.notificacao import check_last_message, check_last_message_fist, roleadcc
from discord.ext import commands
from funcoes import notificacao, hub, ticket, components, traducao, youtube, dashboard
import discord
import os
from settings.ids import ChannelIDs, ServerIDs, CategoryIDs, RoleIDs, UserIDs
from dotenv import load_dotenv  
import re
import settings.emojis
import requests
import json
load_dotenv()

class Tee(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            try:
                f.write(obj)
                if hasattr(f, 'flush'):
                    f.flush()
            except: pass
    def flush(self):
        for f in self.files:
            try:
                if hasattr(f, 'flush'):
                    f.flush()
            except: pass

def diagnose():
    print("\n" + "█"*60)
    print("█  VERIFICAÇÃO DE SISTEMA - PRIVACY MODS BOT")
    print("█" + "─"*58)
    
    all_ok = True
    
    # 1. ENV VARS
    print("█  [1] Variáveis de Ambiente (.env)")
    required_vars = ["TOKEN", "GTOKEN", "SERVER_ID"]
    for var in required_vars:
        val = os.getenv(var)
        if val:
            print(f"█    ✅ {var} encontrado.")
        else:
            print(f"█    ❌ {var} NÃO ENCONTRADO!")
            all_ok = False

    # 2. ARQUIVOS
    print("█  [2] Arquivos de Dados (JSON)")
    files = ["message_counts.json", "divisores.json", "last_ticket_number.json"]
    for f in files:
        if os.path.exists(f):
            try:
                with open(f, 'r') as file:
                    json.load(file)
                print(f"█    ✅ {f} (Válido)")
            except:
                print(f"█    ❌ {f} (Corrompido)")
                all_ok = False
        else:
            print(f"█    ⚠️ {f} (Ausente - Será criado)")
    
    # 3. CONFIGURAÇÃO DE IDs
    print("█  [3] Configuração de IDs (settings/ids.py)")
    
    def check_ids(cls, name):
        missing = []
        for attr in dir(cls):
            if not attr.startswith("__"):
                val = getattr(cls, attr)
                if isinstance(val, int) and val == 0:
                    missing.append(attr)
                elif isinstance(val, list) and not val:
                    missing.append(attr)
        if missing:
            print(f"█    ⚠️ {name}: {len(missing)} IDs não configurados/zerados ({', '.join(missing[:3])}...)")
        else:
            print(f"█    ✅ {name}: Configuração OK")

    # 4. BIBLIOTECAS
    print("█  [4] Bibliotecas Externas")
    libs = ["deep_translator", "langdetect", "discord", "psutil"]
    for lib in libs:
        try:
            __import__(lib)
            print(f"█    ✅ {lib} instalada.")
        except ImportError:
            print(f"█    ❌ {lib} NÃO ENCONTRADA!")
            all_ok = False

    # 5. DIRETÓRIOS
    print("█  [5] Diretórios")
    if os.path.exists("assets/emojis"):
        print("█    ✅ assets/emojis encontrado.")
    else:
        print("█    ⚠️ assets/emojis não encontrado (Emojis podem falhar).")

    check_ids(ServerIDs, "ServerIDs")
    check_ids(ChannelIDs, "ChannelIDs")
    check_ids(CategoryIDs, "CategoryIDs")
    check_ids(RoleIDs, "RoleIDs")
    check_ids(UserIDs, "UserIDs")

    print("█" + "─"*58)
    if all_ok:
        print("█  STATUS: SISTEMA PRONTO PARA INICIAR")
    else:
        print("█  STATUS: ERROS ENCONTRADOS (Verifique acima)")
    print("█"*60 + "\n")

class Bot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True
        intents.presences = True
        intents.message_content = True
        intents.voice_states = True
        
        super().__init__(command_prefix="[]", intents=intents)
        self.synced = False
        self.log_buffer = io.StringIO()
        sys.stdout = Tee(sys.stdout, self.log_buffer)
        sys.stderr = Tee(sys.stderr, self.log_buffer)

    async def setup_hook(self) -> None:
        self.add_view(roleadcc())
        self.add_view(ticket.CreateButton())
        self.add_view(ticket.CloseButton())
        self.add_view(components.FavoriteShare())
        self.add_view(components.ConfirmNSFW())
        self.add_view(hub.Post())
        self.add_view(traducao.Traduzir())
        self.add_view(youtube.YoutubeView())
        await dashboard.start_dashboard(self)

    async def on_ready(self):
        print(f"Entramos como {self.user}.")
        channela = self.get_channel(ChannelIDs.ANUNCIO)
        channelb = self.get_channel(ChannelIDs.FIST)
        await notificacao.membros()
        notificacao.start_status_task()
        await check_last_message(channela)
        await check_last_message_fist(channelb)
        await hub.check_hub_message(self)
        await ticket.check_ticket_message(self)

        self.tree.clear_commands(guild=None)
        try:
            await self.load_extension("funcoes.commands")
            await self.load_extension("funcoes.welcome")
        except commands.ExtensionAlreadyLoaded:
            await self.reload_extension("funcoes.commands")
            await self.reload_extension("funcoes.welcome")

        await self.check_emojis()
        await self.wait_until_ready()
        await self.tree.sync()
        self.synced = True

    async def on_interaction(self, interaction: discord.Interaction):
        try:
            locale = str(interaction.locale)
            user_id = str(interaction.user.id)
            
            data = {}
            if os.path.exists("user_locales.json"):
                with open("user_locales.json", "r") as f:
                    try: data = json.load(f)
                    except: pass
            
            if data.get(user_id) != locale:
                data[user_id] = locale
                with open("user_locales.json", "w") as f:
                    json.dump(data, f)
        except:
            pass

    async def check_emojis(self):
        guild_id = ServerIDs.GUILD_ID
        if not guild_id:
            print("SERVER_ID não encontrado no .env")
            return

        guild = self.get_guild(int(guild_id))
        if not guild:
            print(f"Servidor {guild_id} não encontrado")
            return

        assets_dir = "assets/emojis"
        if not os.path.exists(assets_dir):
            os.makedirs(assets_dir, exist_ok=True)
            print(f"Diretório {assets_dir} criado. Coloque as imagens dos emojis lá para que sejam enviadas.")

        file_path = "settings/emojis.py"
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
        except FileNotFoundError:
            print(f"{file_path} não encontrado.")
            return

        changes = False
        existing_emojis = {e.name: e for e in guild.emojis}

        for attr in dir(settings.emojis):
            if attr.startswith("__"): continue
            value = getattr(settings.emojis, attr)

            if isinstance(value, str):
                match = re.search(r"<:(.+):(\d+)>", value)
                if match:
                    emoji_name = match.group(1)
                    old_id = match.group(2)
                    emoji = existing_emojis.get(emoji_name)

                    if not os.path.exists(os.path.join(assets_dir, f"{emoji_name}.png")):
                        try:
                            response = requests.get(f"https://cdn.discordapp.com/emojis/{old_id}.png")
                            if response.status_code == 200:
                                with open(os.path.join(assets_dir, f"{emoji_name}.png"), "wb") as f:
                                    f.write(response.content)
                                print(f"Emoji {emoji_name} baixado com sucesso.")
                        except:
                            print(f"Erro ao baixar o emoji {emoji_name}.")

                    if not emoji:
                        for ext in ["png", "jpg", "jpeg", "gif"]:
                            img_path = os.path.join(assets_dir, f"{emoji_name}.{ext}")
                            if os.path.exists(img_path):
                                with open(img_path, "rb") as img_f:
                                    emoji = await guild.create_custom_emoji(name=emoji_name, image=img_f.read())
                                    print(f"Emoji criado: {emoji_name}")
                                    existing_emojis[emoji_name] = emoji
                                break
                    
                    if emoji and str(emoji.id) != old_id:
                        pattern = rf'({attr}\s*=\s*[\'"])<:{re.escape(emoji_name)}:\d+>(["\'])'
                        if re.search(pattern, content):
                            content = re.sub(pattern, rf'\g<1><:{emoji.name}:{emoji.id}>\g<2>', content)
                            changes = True
                            print(f"ID do emoji {attr} atualizado: {old_id} -> {emoji.id}")

        if changes:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
            print("Arquivo settings/emojis.py atualizado com novos IDs.")


Bot = Bot()
