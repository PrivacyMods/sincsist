import os
from dotenv import load_dotenv

load_dotenv()

def get_list(key):
    val = os.getenv(key, "")
    if val:
        return [int(x.strip()) for x in val.split(",") if x.strip().isdigit()]
    return []

class ServerIDs:
    """
    IDs relacionados ao Servidor.
    """
    # ID do Servidor Principal
    GUILD_ID = int(os.getenv("SERVER_ID", 0))

class ChannelIDs:
    """
    IDs dos Canais de Texto e Voz.
    """
    # Canal de Anúncios
    ANUNCIO = int(os.getenv("CANAL_ANUNCIO", 0))
    
    # Canal de Fists (Posts)
    FIST = int(os.getenv("CANAL_FIST", 0))
    
    # Canal de Logs de Tickets
    TICKET_LOGS = int(os.getenv("CANAL_TICKET_LOGS", 0))
    
    # Canal de Voz para contagem de membros
    MEMBER_COUNT = int(os.getenv("CALL_ID", 0))
    
    # Canal HUB (Menu Principal)
    HUB = int(os.getenv("HUB_ID", 0))
    
    # Canal NSFW
    NSFW = int(os.getenv("NSFW_CHAT", 0))
    
    # Canal de Armazenamento/Edição de Divisores
    DIVISORES = int(os.getenv("CANAL_DIVISORES", 0))
    
    # Canal de Testes (usado no comando ts)
    TESTES = int(os.getenv("CANAL_TESTES", 0))
    
    # Canal específico para Say (verificação)
    SAY_VERIFY = int(os.getenv("CANAL_SAY_VERIFY", 0))

    # Canal de Status do Bot
    STATUS_BOT = int(os.getenv("CANAL_STATUS_BOT", 0))

    # Canal de Painel de Tickets
    TICKET_PANEL = int(os.getenv("CANAL_TICKET_PANEL", 0))

    # Canais Especiais de Postagem (Fist, Sound, etc)
    POST_FIST_SPECIAL = int(os.getenv("CANAL_POST_FIST_SPECIAL", 0))
    POST_SOUND_SPECIAL = int(os.getenv("CANAL_POST_SOUND_SPECIAL", 0))
    POST_IGNORED = int(os.getenv("CANAL_POST_IGNORED", 0))
    POST_SPECIAL_3 = int(os.getenv("CANAL_POST_SPECIAL_3", 0))

    # Canais monitorados para links (dellinks.py)
    MONITORED_LINKS = get_list("MONITORED_LINKS")

    # Canal para posts do YouTube
    YOUTUBE_POSTS = int(os.getenv("CANAL_YOUTUBE_POSTS", 0))

    # Canal de Logs de Saída
    EXIT_LOGS = int(os.getenv("CANAL_EXIT_LOGS", 1469687213024346142))

    # Canal de Boas Vindas
    WELCOME = int(os.getenv("CANAL_WELCOME", 0))

class CategoryIDs:
    """
    IDs das Categorias de Canais.
    """
    # Categoria de Tickets (Abertura)
    TICKET_OPEN = int(os.getenv("TICKET_CATEGORY", 0))
    
    # Categoria de Tickets (Fechamento/Arquivo)
    TICKET_CLOSE = int(os.getenv("CATEGORY_TICKET_CLOSE", 0))
    
    # Categorias onde os posts são permitidos/gerenciados
    POSTS = get_list("CATEGORY_IDS_POSTS")
    
    # Categorias que utilizam Threads
    THREADS = get_list("CATEGORY_IDS_THREADS")
    
    # Categoria específica de Sounds (usada em verificações)
    SOUNDS = int(os.getenv("CATEGORY_SOUNDS", 0))

class RoleIDs:
    """
    IDs dos Cargos (Roles).
    """
    # Cargo de Administrador
    ADMIN = int(os.getenv("ADMIN_ID_ROLE", 0))
    
    # Cargo de Suporte
    SUPORTE = int(os.getenv("SUPORTE_ID_ROLE", 0))
    
    # Cargo de Postador (Notificações)
    POSTADOR = int(os.getenv("POSTADOR_ID", 0))
    
    # Cargo de Booster
    BOOSTER = int(os.getenv("BOOSTER_ID", 0))
    
    # Cargo monitorado para links
    LINK_MONITOR = int(os.getenv("ROLE_LINK_MONITOR", 0))

    # Cargo Postador (YouTube)
    YOUTUBER = 1470818674465181706

class UserIDs:
    """
    IDs de Usuários.
    """
    # ID do Bot
    BOT = int(os.getenv("BOT_ID", 0))
    
    # Usuário que recebe os arquivos de Fist (DM)
    FIST_RECEIVER = int(os.getenv("USUARIO_FIST", 0))
    
    # Desenvolvedor/Admin Principal (Oceans)
    DEV_OCEANS = int(os.getenv("USER_DEV_OCEANS", 0))
    
    # Usuário monitorado para links
    LINK_MONITOR = int(os.getenv("USER_LINK_MONITOR", 0))

class GithubConfig:
    """
    Configurações do GitHub.
    """
    # Repositório para backup de Fists (formato: usuario/repo)
    FIST_REPO = os.getenv("FIST_REPO", "")
    
    # Branch do repositório de Fists
    FIST_REPO_BRANCH = os.getenv("FIST_REPO_BRANCH", "main")

class MessageIDs:
    """
    IDs de Mensagens Específicas.
    """
    # Mensagem base para adicionar divisores
    DIVISOR_TEMPLATE = int(os.getenv("MSG_DIVISOR_TEMPLATE", 0))
    
    # Mensagem de teste
    TEST_MSG = int(os.getenv("MSG_TEST_MSG", 0))