# Hub
divisores_privacy = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/dividers_privacy.png?raw=true"
poste_seus_mods = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/privacyhub.png?raw=true"
author_icon_default = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/privacyhub.png?raw=true"

# Ticket
privacy_banner = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/privacy.png?raw=true"

# Traducao
translate_author_icon = "https://cdn.discordapp.com/attachments/976658493295710252/1116902473194541156/1.png"

# Weapons (Hub)
weapons = {
    "M4": "https://cdn.discordapp.com/attachments/1130290520640471060/1130614829116305511/M4.png",
    "AK47": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617609142943876/AK47.png",
    "CUTGUN": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617609679806524/CUTGUN.png",
    "SNIPER": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617632849137825/SNIPER.png",
    "COMBAT": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617609386196993/COMBAT.png",
    "SHOTGUN": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617611391074314/SHOTGUN.png",
    "SAWN": "https://cdn.discordapp.com/attachments/1130290520640471060/1130618458871185600/SAWN.png",
    "TEC9": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617632538767392/TEC9.png",
    "MAC10": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617610518659104/MAC10.png",
    "MP5": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617610841628775/MP5.png",
    "DESERT": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617610090856550/DESERT.png",
    "SILENCED": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617608589279352/SILENCED.png",
    "9MM": "https://cdn.discordapp.com/attachments/1130290520640471060/1130617608853528746/9MM.png",
}

# Components (Assets)
frame_without_shadow = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/FrameWithoutShadow.png?raw=true"
frame_square = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/FrameSquare.png?raw=true"
frame_with_shadow = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/FrameWithShadow.png?raw=true"
frame_default_round = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/aaaaaaaaaaaaaaaa.png?raw=true"
frame_default_square = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/fist.png?raw=true"
frame_default_static = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/fist.png?raw=true"

txd_deddosouru_round = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/deddosouru.txd"
txd_deddosouru_square = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/deddosouru.txd"
txd_default_round = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/deddosouru.txd"
txd_default_square = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/deddosouru.txd"

fist_png = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/fist.png?raw=true"
settings_ini = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/deddosouru_animated_fist_settings.ini"
aniframe_fix_luac = "https://raw.githubusercontent.com/PrivacyMods/arquivos/refs/heads/main/aniframe_fix.luac"